Attribute VB_Name = "DExcelAssistExtra"

Option Explicit

' DExcelAssist change-history event state.
' Module-level declarations must be placed before all procedures.
Private gDxaEvents As DExcelAssistAppEvents
Private gDxaSessionId As String



' DExcelAssist v108

' �����A�b�v�f�[�g�@�\�͊܂߂Ă��܂���B

' �ǉ��@�\��Excel��VBA�Ƃ��Ď��s���܂��B



Public Sub DxaCreateHolidaySheet(ByVal control As Object)

    On Error GoTo EH

    Dim yText As String

    yText = InputBox("�x���ꗗ���쐬����N����͂��Ă��������B", "�x���V�[�g�쐬", CStr(Year(Date)))

    If Len(Trim$(yText)) = 0 Then Exit Sub

    If Not IsNumeric(yText) Then

        MsgBox "�N�͐��l�œ��͂��Ă��������B", vbExclamation, "DExcelAssist"

        Exit Sub

    End If



    Dim y As Long

    y = CLng(yText)

    If y < 1900 Or y > 2100 Then

        MsgBox "1900�`2100�͈̔͂œ��͂��Ă��������B", vbExclamation, "DExcelAssist"

        Exit Sub

    End If



    Dim wb As Workbook

    Set wb = ActiveWorkbook

    If wb Is Nothing Then Exit Sub



    Dim sheetName As String

    sheetName = "�x��" & CStr(y)



    Application.ScreenUpdating = False

    Application.DisplayAlerts = False

    Dim ws As Worksheet

    On Error Resume Next

    Set ws = wb.Worksheets(sheetName)

    On Error GoTo EH

    If Not ws Is Nothing Then ws.Delete

    Application.DisplayAlerts = True



    Set ws = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))

    ws.Name = sheetName



    Dim items As Object

    Set items = CreateObject("Scripting.Dictionary")

    AddJapaneseHolidays y, items



    ws.Range("A1:C1").Value = Array("���t", "�j��", "�x����")

    ws.Range("A1:C1").Font.Bold = True



    Dim keys As Variant

    keys = items.Keys

    SortDateKeys keys



    Dim r As Long, k As Variant

    r = 2

    For Each k In keys

        ws.Cells(r, 1).Value = CDate(k)

        ws.Cells(r, 2).Value = JapaneseWeekday(CDate(k))

        ws.Cells(r, 3).Value = items(k)

        r = r + 1

    Next



    ws.Columns("A:A").NumberFormatLocal = "yyyy/mm/dd"

    ws.Columns("A:C").AutoFit

    ws.Range("A1:C1").AutoFilter

    ws.Activate

    ws.Range("A1").Select

    Application.ScreenUpdating = True

    MsgBox CStr(y) & "�N�̋x���ꗗ���쐬���܂����B", vbInformation, "DExcelAssist"

    Exit Sub

EH:

    Application.DisplayAlerts = True

    Application.ScreenUpdating = True

    MsgBox "�x���V�[�g�쐬�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DExcelAssist"

End Sub



Public Sub DxaAllSheetsZoom100(ByVal control As Object)

    On Error GoTo EH

    Dim wb As Workbook

    Set wb = ActiveWorkbook

    If wb Is Nothing Then Exit Sub



    Dim activeName As String

    activeName = ActiveSheet.Name

    Dim ws As Worksheet

    Application.ScreenUpdating = False

    For Each ws In wb.Worksheets

        If ws.Visible = xlSheetVisible Then

            ws.Activate

            ActiveWindow.Zoom = 100

        End If

    Next

    wb.Worksheets(activeName).Activate

    Application.ScreenUpdating = True

    MsgBox "�S�V�[�g�̔{����100%�ɂ��܂����B", vbInformation, "DExcelAssist"

    Exit Sub

EH:

    Application.ScreenUpdating = True

    MsgBox "�S�V�[�g�{��100%�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DExcelAssist"

End Sub



Public Sub DxaHalfToFull(ByVal control As Object)

    ConvertSelectionAscii True

End Sub



Public Sub DxaFullToHalf(ByVal control As Object)

    ConvertSelectionAscii False

End Sub



Public Sub DxaAutoFitActiveSheetColumns(ByVal control As Object)

    On Error GoTo EH

    Dim ws As Worksheet

    Set ws = ActiveSheet

    If ws Is Nothing Then Exit Sub

    Application.ScreenUpdating = False

    If Application.WorksheetFunction.CountA(ws.Cells) = 0 Then

        ws.Columns.AutoFit

    Else

        ws.UsedRange.Columns.AutoFit

    End If

    Application.ScreenUpdating = True

    MsgBox "���s�V�[�g�̗񕝂������������܂����B", vbInformation, "DExcelAssist"

    Exit Sub

EH:

    Application.ScreenUpdating = True

    MsgBox "�񕝎��������ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DExcelAssist"

End Sub



Public Sub DxaAutoFitActiveSheetRows(ByVal control As Object)

    On Error GoTo EH

    Dim ws As Worksheet

    Set ws = ActiveSheet

    If ws Is Nothing Then Exit Sub



    Application.ScreenUpdating = False

    If Application.WorksheetFunction.CountA(ws.Cells) = 0 Then

        ws.Rows.AutoFit

    Else

        ws.UsedRange.Rows.AutoFit

    End If

    Application.ScreenUpdating = True

    MsgBox "���s�V�[�g�̍s�����������������܂����B", vbInformation, "DExcelAssist"

    Exit Sub

EH:

    Application.ScreenUpdating = True

    MsgBox "�s�������������ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DExcelAssist"

End Sub



Private Sub ConvertSelectionAscii(ByVal halfToFull As Boolean)

    On Error GoTo EH

    If TypeName(Selection) = "Nothing" Then Exit Sub

    Application.ScreenUpdating = False



    Dim rng As Range, c As Range

    On Error Resume Next

    Set rng = Selection.SpecialCells(xlCellTypeConstants)

    On Error GoTo EH

    If Not rng Is Nothing Then

        For Each c In rng.Cells

            If Not IsError(c.Value) Then

                c.Value = ConvertAsciiText(CStr(c.Value), halfToFull)

            End If

        Next

    End If



    Dim sr As ShapeRange, shp As Shape

    On Error Resume Next

    Set sr = Selection.ShapeRange

    On Error GoTo EH

    If Not sr Is Nothing Then

        For Each shp In sr

            ConvertShapeText shp, halfToFull

        Next

    End If



    Application.ScreenUpdating = True

    If halfToFull Then

        MsgBox "�I��͈͂̔��p�p������S�p�ɕϊ����܂����B", vbInformation, "DExcelAssist"

    Else

        MsgBox "�I��͈͂̑S�p�p�����𔼊p�ɕϊ����܂����B", vbInformation, "DExcelAssist"

    End If

    Exit Sub

EH:

    Application.ScreenUpdating = True

    MsgBox "�����ϊ��ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DExcelAssist"

End Sub



Private Sub ConvertShapeText(ByVal shp As Shape, ByVal halfToFull As Boolean)

    On Error Resume Next

    If shp.TextFrame2.HasText Then shp.TextFrame2.TextRange.Text = ConvertAsciiText(shp.TextFrame2.TextRange.Text, halfToFull)

    If shp.TextFrame.Characters.Count > 0 Then shp.TextFrame.Characters.Text = ConvertAsciiText(shp.TextFrame.Characters.Text, halfToFull)

End Sub



Private Function ConvertAsciiText(ByVal s As String, ByVal halfToFull As Boolean) As String

    Dim i As Long, code As Long, ch As String, out As String

    For i = 1 To Len(s)

        ch = Mid$(s, i, 1)

        code = AscW(ch)

        If halfToFull Then

            If (code >= 48 And code <= 57) Or (code >= 65 And code <= 90) Or (code >= 97 And code <= 122) Then

                out = out & ChrW$(code + &HFEE0)

            Else

                out = out & ch

            End If

        Else

            If (code >= &HFF10 And code <= &HFF19) Or (code >= &HFF21 And code <= &HFF3A) Or (code >= &HFF41 And code <= &HFF5A) Then

                out = out & ChrW$(code - &HFEE0)

            Else

                out = out & ch

            End If

        End If

    Next

    ConvertAsciiText = out

End Function



Private Sub AddJapaneseHolidays(ByVal y As Long, ByVal d As Object)

    AddHoliday d, DateSerial(y, 1, 1), "����"

    AddHoliday d, NthMonday(y, 1, 2), "���l�̓�"

    AddHoliday d, DateSerial(y, 2, 11), "�����L�O�̓�"

    If y >= 2020 Then AddHoliday d, DateSerial(y, 2, 23), "�V�c�a����"

    AddHoliday d, VernalEquinox(y), "�t���̓�"

    AddHoliday d, DateSerial(y, 4, 29), "���a�̓�"

    AddHoliday d, DateSerial(y, 5, 3), "���@�L�O��"

    AddHoliday d, DateSerial(y, 5, 4), "�݂ǂ�̓�"

    AddHoliday d, DateSerial(y, 5, 5), "���ǂ��̓�"

    AddHoliday d, NthMonday(y, 7, 3), "�C�̓�"

    AddHoliday d, DateSerial(y, 8, 11), "�R�̓�"

    AddHoliday d, NthMonday(y, 9, 3), "�h�V�̓�"

    AddHoliday d, AutumnalEquinox(y), "�H���̓�"

    AddHoliday d, NthMonday(y, 10, 2), "�X�|�[�c�̓�"

    AddHoliday d, DateSerial(y, 11, 3), "�����̓�"

    AddHoliday d, DateSerial(y, 11, 23), "�ΘJ���ӂ̓�"

    AddSubstituteHolidays y, d

    AddCitizensHolidays y, d

End Sub



Private Sub AddHoliday(ByVal d As Object, ByVal dt As Date, ByVal name As String)

    Dim key As String

    key = Format$(dt, "yyyy/mm/dd")

    If d.Exists(key) Then

        If InStr(1, d(key), name, vbTextCompare) = 0 Then d(key) = d(key) & " / " & name

    Else

        d.Add key, name

    End If

End Sub



Private Sub AddSubstituteHolidays(ByVal y As Long, ByVal d As Object)

    Dim keys As Variant, k As Variant, dt As Date, subDt As Date

    keys = d.Keys

    For Each k In keys

        dt = CDate(k)

        If Year(dt) = y And Weekday(dt, vbSunday) = vbSunday Then

            subDt = DateAdd("d", 1, dt)

            Do While d.Exists(Format$(subDt, "yyyy/mm/dd"))

                subDt = DateAdd("d", 1, subDt)

            Loop

            If Year(subDt) = y Then AddHoliday d, subDt, "�U�֋x��"

        End If

    Next

End Sub



Private Sub AddCitizensHolidays(ByVal y As Long, ByVal d As Object)

    Dim dt As Date

    For dt = DateSerial(y, 1, 2) To DateSerial(y, 12, 30)

        If Not d.Exists(Format$(dt, "yyyy/mm/dd")) Then

            If d.Exists(Format$(DateAdd("d", -1, dt), "yyyy/mm/dd")) And d.Exists(Format$(DateAdd("d", 1, dt), "yyyy/mm/dd")) Then

                If Weekday(dt, vbSunday) <> vbSunday Then AddHoliday d, dt, "�����̋x��"

            End If

        End If

    Next

End Sub



Private Function NthMonday(ByVal y As Long, ByVal m As Long, ByVal n As Long) As Date

    Dim dt As Date

    dt = DateSerial(y, m, 1)

    Do While Weekday(dt, vbMonday) <> 1

        dt = DateAdd("d", 1, dt)

    Loop

    NthMonday = DateAdd("d", (n - 1) * 7, dt)

End Function



Private Function VernalEquinox(ByVal y As Long) As Date

    Dim dayNum As Long

    If y <= 2099 Then

        dayNum = Int(20.8431 + 0.242194 * (y - 1980) - Int((y - 1980) / 4))

    Else

        dayNum = Int(21.851 + 0.242194 * (y - 1980) - Int((y - 1980) / 4))

    End If

    VernalEquinox = DateSerial(y, 3, dayNum)

End Function



Private Function AutumnalEquinox(ByVal y As Long) As Date

    Dim dayNum As Long

    If y <= 2099 Then

        dayNum = Int(23.2488 + 0.242194 * (y - 1980) - Int((y - 1980) / 4))

    Else

        dayNum = Int(24.2488 + 0.242194 * (y - 1980) - Int((y - 1980) / 4))

    End If

    AutumnalEquinox = DateSerial(y, 9, dayNum)

End Function



Private Function JapaneseWeekday(ByVal dt As Date) As String

    JapaneseWeekday = Choose(Weekday(dt, vbSunday), "��", "��", "��", "��", "��", "��", "�y")

End Function



Private Sub SortDateKeys(ByRef keys As Variant)

    Dim i As Long, j As Long, tmp As Variant

    For i = LBound(keys) To UBound(keys) - 1

        For j = i + 1 To UBound(keys)

            If CDate(keys(i)) > CDate(keys(j)) Then

                tmp = keys(i)

                keys(i) = keys(j)

                keys(j) = tmp

            End If

        Next

    Next

End Sub





'============================================================

' v95 �ǉ��@�\

'============================================================

Public Sub DxaCreateSheetIndex(ByVal control As Object)

    On Error GoTo EH

    Dim wb As Workbook
    Set wb = ActiveWorkbook
    If wb Is Nothing Then Exit Sub

    Dim indexName As String
    indexName = "�V�[�g�ꗗ"

    Application.ScreenUpdating = False
    Application.DisplayAlerts = False

    Dim wsIndex As Worksheet
    On Error Resume Next
    Set wsIndex = wb.Worksheets(indexName)
    On Error GoTo EH
    If Not wsIndex Is Nothing Then wsIndex.Delete

    Application.DisplayAlerts = True

    Set wsIndex = wb.Worksheets.Add(Before:=wb.Worksheets(1))
    wsIndex.Name = indexName

    wsIndex.Range("A1:C1").Value = Array("No", "�V�[�g��", "�\�����")
    wsIndex.Range("A1:C1").Font.Bold = True
    wsIndex.Range("A1:C1").Interior.Color = RGB(221, 235, 247)

    Dim r As Long
    r = 2

    Dim ws As Worksheet
    For Each ws In wb.Worksheets
        If ws.Name <> wsIndex.Name Then
            wsIndex.Cells(r, 1).Value = r - 1
            wsIndex.Cells(r, 2).Value = ws.Name
            wsIndex.Hyperlinks.Add Anchor:=wsIndex.Cells(r, 2), Address:="", SubAddress:="'" & Replace(ws.Name, "'", "''") & "'!A1", TextToDisplay:=ws.Name
            Select Case ws.Visible
                Case xlSheetVisible
                    wsIndex.Cells(r, 3).Value = "�\��"
                Case xlSheetHidden
                    wsIndex.Cells(r, 3).Value = "��\��"
                Case xlSheetVeryHidden
                    wsIndex.Cells(r, 3).Value = "VeryHidden"
                Case Else
                    wsIndex.Cells(r, 3).Value = CStr(ws.Visible)
            End Select
            r = r + 1
        End If
    Next ws

    wsIndex.Columns("A:C").AutoFit
    wsIndex.Range("A1:C1").AutoFilter
    wsIndex.Activate
    wsIndex.Range("A1").Select

    Application.ScreenUpdating = True
    MsgBox "�V�[�g�ꗗ���쐬���܂����B", vbInformation, "DExcelAssist"
    Exit Sub
EH:
    Application.DisplayAlerts = True
    Application.ScreenUpdating = True
    MsgBox "�V�[�g�ꗗ�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DExcelAssist"
End Sub

Public Sub DxaBacklogGroupByParent(ByVal control As Object)
    DxaBacklogGroupByParentCore
End Sub

Private Sub DxaBacklogGroupByParentCore()
    On Error GoTo EH

    Dim wb As Workbook
    Dim wsTarget As Worksheet
    Dim wsParent As Worksheet
    Dim parentDict As Object
    Dim lastRowTarget As Long
    Dim lastRowParent As Long
    Dim rowIndex As Long
    Dim cellValue As String
    Dim parentSource As String

    Set wb = ActiveWorkbook
    If wb Is Nothing Then
        MsgBox "�Ώۃu�b�N���J���Ă�����s���Ă��������B", vbExclamation, "DExcelAssist"
        Exit Sub
    End If

    Set wsTarget = ActiveSheet
    If wsTarget Is Nothing Then
        MsgBox "�ΏۃV�[�g��I�����Ă�����s���Ă��������B", vbExclamation, "DExcelAssist"
        Exit Sub
    End If

    Set parentDict = CreateObject("Scripting.Dictionary")
    Set wsParent = DxaFindWorksheetInWorkbook(wb, "�e�ۑ�ꗗ")

    If Not wsParent Is Nothing Then
        lastRowParent = wsParent.Cells(wsParent.Rows.Count, "A").End(xlUp).Row
        For rowIndex = 1 To lastRowParent
            cellValue = DxaBacklogIssueKeyText(wsParent.Cells(rowIndex, "A"))
            If Len(cellValue) > 0 Then parentDict(cellValue) = True
        Next rowIndex
        parentSource = "�e�ۑ�ꗗ"
    Else
        DxaCollectBacklogParentCandidates wsTarget, parentDict
        parentSource = "�K���g�V�[�g��������"
    End If

    If parentDict.Count = 0 Then
        MsgBox "�e�ۑ肪������܂���ł����B" & vbCrLf & _
               "�e�ۑ�ꗗ�V�[�g���쐬���邩�ABacklog�K���g�o�̓V�[�g��I�����Ă�����s���Ă��������B", _
               vbExclamation, "DExcelAssist"
        Exit Sub
    End If

    lastRowTarget = wsTarget.Cells(wsTarget.Rows.Count, "A").End(xlUp).Row
    If lastRowTarget < 5 Then
        MsgBox "�O���[�v���Ώۂ̍s��������܂���ł����B", vbExclamation, "DExcelAssist"
        Exit Sub
    End If

    Application.ScreenUpdating = False

    On Error Resume Next
    wsTarget.Rows.ClearOutline
    On Error GoTo EH

    wsTarget.Range("A5:A" & lastRowTarget).IndentLevel = 0

    rowIndex = 5
    Do While rowIndex <= lastRowTarget
        cellValue = DxaBacklogIssueKeyText(wsTarget.Cells(rowIndex, "A"))

        If parentDict.Exists(cellValue) Then
            rowIndex = DxaGroupOneBacklogParent(wsTarget, parentDict, rowIndex, lastRowTarget)
        Else
            rowIndex = rowIndex + 1
        End If
    Loop

    Application.ScreenUpdating = True
    MsgBox "�e�ۑ�ŃO���[�v�����܂����B" & vbCrLf & "�e�ۑ�̔�����@: " & parentSource, vbInformation, "DExcelAssist"
    Exit Sub

EH:
    Application.ScreenUpdating = True
    MsgBox "�e�ۑ�ŃO���[�v�����ɃG���[���������܂����B" & vbCrLf & _
           "�Ώۃu�b�N�E�ΏۃV�[�g�E�e�ۑ�ꗗ�V�[�g���m�F���Ă��������B" & vbCrLf & _
           Err.Description, vbExclamation, "DExcelAssist"
End Sub

Private Function DxaGroupOneBacklogParent(ByVal wsTarget As Worksheet, ByVal parentDict As Object, ByVal parentRow As Long, ByVal lastRowTarget As Long) As Long
    Dim nextParentRow As Long
    Dim searchRow As Long
    Dim startChild As Long
    Dim endChild As Long
    Dim i As Long
    Dim keyText As String

    nextParentRow = 0

    With wsTarget.Cells(parentRow, "A").Font
        .Bold = True
        .Size = Application.Max(8, .Size + 4)
    End With

    With wsTarget.Cells(parentRow, "C").Font
        .Bold = True
        .Size = Application.Max(8, .Size + 4)
    End With

    For searchRow = parentRow + 1 To lastRowTarget
        keyText = DxaBacklogIssueKeyText(wsTarget.Cells(searchRow, "A"))
        If parentDict.Exists(keyText) Then
            nextParentRow = searchRow
            Exit For
        End If
    Next searchRow

    startChild = parentRow + 1
    If nextParentRow > 0 Then
        endChild = nextParentRow - 1
    Else
        endChild = lastRowTarget
    End If

    If startChild <= endChild Then
        wsTarget.Rows(startChild & ":" & endChild).Group
        For i = startChild To endChild
            wsTarget.Cells(i, "A").IndentLevel = wsTarget.Cells(i, "A").IndentLevel + 1
        Next i
    End If

    If nextParentRow > 0 Then
        DxaGroupOneBacklogParent = nextParentRow
    Else
        DxaGroupOneBacklogParent = lastRowTarget + 1
    End If
End Function

Private Sub DxaCollectBacklogParentCandidates(ByVal ws As Worksheet, ByVal parentDict As Object)
    Dim headerRow As Long
    Dim firstDataRow As Long
    Dim lastRow As Long
    Dim r As Long
    Dim keyText As String

    headerRow = DxaBacklogFindHeaderRow(ws)
    If headerRow = 0 Then headerRow = 4
    firstDataRow = headerRow + 1
    lastRow = ws.Cells(ws.Rows.Count, "A").End(xlUp).Row

    For r = firstDataRow To lastRow
        keyText = DxaBacklogIssueKeyText(ws.Cells(r, "A"))
        If Len(keyText) > 0 Then
            If DxaLooksLikeBacklogParentRow(ws, r, firstDataRow, lastRow) Then
                parentDict(keyText) = True
            End If
        End If
    Next r
End Sub

Private Function DxaLooksLikeBacklogParentRow(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal firstDataRow As Long, ByVal lastRow As Long) As Boolean
    Dim assigneeText As String
    Dim plannedText As String
    Dim actualText As String
    Dim startValue As Variant
    Dim dueValue As Variant
    Dim durationDays As Long

    assigneeText = Trim$(CStr(ws.Cells(rowNo, "G").Value))
    plannedText = Trim$(CStr(ws.Cells(rowNo, "J").Value))
    actualText = Trim$(CStr(ws.Cells(rowNo, "K").Value))
    startValue = ws.Cells(rowNo, "H").Value
    dueValue = ws.Cells(rowNo, "I").Value

    If Len(assigneeText) > 0 Then Exit Function
    If Len(plannedText) > 0 Or Len(actualText) > 0 Then Exit Function

    If IsDate(startValue) And IsDate(dueValue) Then
        durationDays = CLng(CDate(dueValue) - CDate(startValue))
        If durationDays >= 2 Then
            DxaLooksLikeBacklogParentRow = True
            Exit Function
        End If
    End If

    If DxaNextRowsLookLikeChildren(ws, rowNo, lastRow) Then
        DxaLooksLikeBacklogParentRow = True
    End If
End Function

Private Function DxaNextRowsLookLikeChildren(ByVal ws As Worksheet, ByVal parentRow As Long, ByVal lastRow As Long) As Boolean
    Dim r As Long
    Dim checkLimit As Long
    Dim childCount As Long

    checkLimit = parentRow + 5
    If checkLimit > lastRow Then checkLimit = lastRow

    For r = parentRow + 1 To checkLimit
        If Len(DxaBacklogIssueKeyText(ws.Cells(r, "A"))) > 0 Then
            If Len(Trim$(CStr(ws.Cells(r, "G").Value))) > 0 Or Len(Trim$(CStr(ws.Cells(r, "J").Value))) > 0 Or Len(Trim$(CStr(ws.Cells(r, "K").Value))) > 0 Then
                childCount = childCount + 1
            End If
        End If
    Next r

    DxaNextRowsLookLikeChildren = (childCount >= 1)
End Function

Private Function DxaBacklogIssueKeyText(ByVal cell As Range) As String
    On Error Resume Next
    If cell.Hyperlinks.Count > 0 Then
        DxaBacklogIssueKeyText = Trim$(CStr(cell.Hyperlinks(1).TextToDisplay))
    ElseIf cell.HasFormula Then
        DxaBacklogIssueKeyText = Trim$(CStr(cell.Text))
    Else
        DxaBacklogIssueKeyText = Trim$(CStr(cell.Value))
    End If
End Function

Private Function DxaBacklogFindHeaderRow(ByVal ws As Worksheet) As Long
    Dim r As Long
    For r = 1 To 20
        If Trim$(CStr(ws.Cells(r, "A").Value)) = "�L�[" _
           And Trim$(CStr(ws.Cells(r, "C").Value)) = "����" Then
            DxaBacklogFindHeaderRow = r
            Exit Function
        End If
    Next r
    DxaBacklogFindHeaderRow = 0
End Function

Private Function DxaFindWorksheetInWorkbook(ByVal wb As Workbook, ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set DxaFindWorksheetInWorkbook = wb.Worksheets(sheetName)
    On Error GoTo 0
End Function

' �t�H���_�c���[�쐬�F�I�������t�H���_�z���̃t�H���_/�t�@�C���\�����A���݂̃V�[�g�֕�����x�[�X�ő}�����܂��B
' �Q�l����FRelaxApps�́u�t�H���_�[ �c���[�쐬�v���l�A�t�H���_��I�����Ď擾���AExcel��Ƀc���[��\��t���܂��B
Public Sub DxaCreateFolderTreeWithFolderPicker(ByVal control As Object)
    On Error GoTo ErrHandler

    Dim rootFolder As String
    rootFolder = DxaPickSourceFolder("�c���[���쐬����t�H���_��I�����Ă�������")
    If Len(rootFolder) = 0 Then Exit Sub

    Dim includeFilesAnswer As VbMsgBoxResult
    includeFilesAnswer = MsgBox("�t�@�C�����c���[�Ɋ܂߂܂����H" & vbCrLf & _
                                "�͂�: �t�H���_�{�t�@�C�����o��" & vbCrLf & _
                                "������: �t�H���_�̂ݏo��", _
                                vbQuestion + vbYesNoCancel, "�t�H���_�c���[")
    If includeFilesAnswer = vbCancel Then Exit Sub

    Dim includeFiles As Boolean
    includeFiles = (includeFilesAnswer = vbYes)

    Dim fso As Object
    Set fso = CreateObject("Scripting.FileSystemObject")
    If Not fso.FolderExists(rootFolder) Then
        MsgBox "�I�������t�H���_��������܂���B" & vbCrLf & rootFolder, vbExclamation, "�t�H���_�c���["
        Exit Sub
    End If

    Dim wb As Workbook
    Set wb = ActiveWorkbook
    If wb Is Nothing Then Exit Sub

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.DisplayAlerts = False

    Dim ws As Worksheet
    On Error Resume Next
    Set ws = wb.Worksheets("�t�H���_�c���[")
    On Error GoTo ErrHandler
    If Not ws Is Nothing Then ws.Delete

    Application.DisplayAlerts = True

    Set ws = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))
    ws.Name = "�t�H���_�c���["

    Dim rowNo As Long
    rowNo = 1

    Dim colTree As Long
    Dim colType As Long
    Dim colPath As Long
    Dim colModified As Long
    Dim colSize As Long
    colTree = 1
    colType = 2
    colPath = 3
    colModified = 4
    colSize = 5

    ws.Cells(rowNo, colTree).Value = "�c���["
    ws.Cells(rowNo, colType).Value = "���"
    ws.Cells(rowNo, colPath).Value = "�p�X"
    ws.Cells(rowNo, colModified).Value = "�X�V����"
    ws.Cells(rowNo, colSize).Value = "�T�C�Y(KB)"
    ws.Range(ws.Cells(rowNo, colTree), ws.Cells(rowNo, colSize)).Font.Bold = True
    ws.Range(ws.Cells(rowNo, colTree), ws.Cells(rowNo, colSize)).Interior.Color = RGB(221, 235, 247)
    rowNo = rowNo + 1

    Dim root As Object
    Set root = fso.GetFolder(rootFolder)

    DxaWriteTreeLine ws, rowNo, colTree, colType, colPath, colModified, colSize, _
                     "�� " & root.Name, "�t�H���_", root.Path, root.DateLastModified, "", root.Path
    rowNo = rowNo + 1

    Dim folderCount As Long
    Dim fileCount As Long
    folderCount = 1
    fileCount = 0

    DxaOutputFolderTree ws, rowNo, colTree, colType, colPath, colModified, colSize, root, "", includeFiles, folderCount, fileCount

    ws.Range(ws.Cells(1, colTree), ws.Cells(rowNo - 1, colSize)).Columns.AutoFit
    ws.Range("A1:E1").AutoFilter
    ws.Activate
    ws.Range("A1").Select

    Application.DisplayAlerts = True
    Application.EnableEvents = True
    Application.ScreenUpdating = True

    MsgBox "�t�H���_�c���[���쐬���܂����B" & vbCrLf & _
           "�擾��: " & rootFolder & vbCrLf & _
           "�o�͐�: �t�H���_�c���[ �V�[�g" & vbCrLf & _
           "�t�H���_: " & folderCount & " ��" & vbCrLf & _
           "�t�@�C��: " & fileCount & " ��", vbInformation, "�t�H���_�c���["
    Exit Sub

ErrHandler:
    Application.DisplayAlerts = True
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    MsgBox "�t�H���_�c���[�쐬�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "�t�H���_�c���["
End Sub

Private Sub DxaOutputFolderTree(ByVal ws As Worksheet, ByRef rowNo As Long, _
                                ByVal colTree As Long, ByVal colType As Long, ByVal colPath As Long, ByVal colModified As Long, ByVal colSize As Long, _
                                ByVal folderObj As Object, ByVal prefix As String, ByVal includeFiles As Boolean, _
                                ByRef folderCount As Long, ByRef fileCount As Long)
    On Error GoTo AccessDenied

    Dim folderPaths As Variant
    Dim filePaths As Variant
    folderPaths = DxaSortedFolderPaths(folderObj)
    If includeFiles Then filePaths = DxaSortedFilePaths(folderObj)

    Dim folderTotal As Long
    Dim fileTotal As Long
    folderTotal = DxaVariantItemCount(folderPaths)
    If includeFiles Then fileTotal = DxaVariantItemCount(filePaths) Else fileTotal = 0

    Dim i As Long
    For i = 1 To folderTotal
        Dim fPath As String
        fPath = CStr(folderPaths(i))

        Dim childFolder As Object
        Set childFolder = CreateObject("Scripting.FileSystemObject").GetFolder(fPath)

        Dim isLastFolderItem As Boolean
        isLastFolderItem = (i = folderTotal And fileTotal = 0)

        Dim branch As String
        If isLastFolderItem Then branch = "���� " Else branch = "���� "

        DxaWriteTreeLine ws, rowNo, colTree, colType, colPath, colModified, colSize, _
                         prefix & branch & "�� " & childFolder.Name, "�t�H���_", childFolder.Path, childFolder.DateLastModified, "", childFolder.Path
        rowNo = rowNo + 1
        folderCount = folderCount + 1

        Dim nextPrefix As String
        If isLastFolderItem Then nextPrefix = prefix & "    " Else nextPrefix = prefix & "��  "
        DxaOutputFolderTree ws, rowNo, colTree, colType, colPath, colModified, colSize, childFolder, nextPrefix, includeFiles, folderCount, fileCount
    Next i

    If includeFiles Then
        For i = 1 To fileTotal
            Dim filePath As String
            filePath = CStr(filePaths(i))

            Dim fileObj As Object
            Set fileObj = CreateObject("Scripting.FileSystemObject").GetFile(filePath)

            Dim fileBranch As String
            If i = fileTotal Then fileBranch = "���� " Else fileBranch = "���� "

            DxaWriteTreeLine ws, rowNo, colTree, colType, colPath, colModified, colSize, _
                             prefix & fileBranch & "�E " & fileObj.Name, "�t�@�C��", fileObj.Path, fileObj.DateLastModified, DxaFormatKb(fileObj.Size), fileObj.Path
            rowNo = rowNo + 1
            fileCount = fileCount + 1
        Next i
    End If
    Exit Sub

AccessDenied:
    DxaWriteTreeLine ws, rowNo, colTree, colType, colPath, colModified, colSize, _
                     prefix & "���� [�A�N�Z�X�s��] " & folderObj.Name, "�G���[", folderObj.Path, "", "", folderObj.Path
    rowNo = rowNo + 1
End Sub

Private Sub DxaWriteTreeLine(ByVal ws As Worksheet, ByVal rowNo As Long, _
                             ByVal colTree As Long, ByVal colType As Long, ByVal colPath As Long, ByVal colModified As Long, ByVal colSize As Long, _
                             ByVal treeText As String, ByVal typeText As String, ByVal pathText As String, ByVal modifiedValue As Variant, ByVal sizeText As String, ByVal linkPath As String)
    ws.Cells(rowNo, colTree).Value = treeText
    ws.Cells(rowNo, colType).Value = typeText
    ws.Cells(rowNo, colPath).Value = pathText
    If Len(CStr(modifiedValue)) > 0 Then ws.Cells(rowNo, colModified).Value = modifiedValue
    ws.Cells(rowNo, colSize).Value = sizeText

    On Error Resume Next
    ws.Hyperlinks.Add Anchor:=ws.Cells(rowNo, colTree), Address:=linkPath, TextToDisplay:=treeText
    On Error GoTo 0
End Sub

Private Function DxaSortedFolderPaths(ByVal folderObj As Object) As Variant
    Dim col As Collection
    Set col = New Collection

    Dim f As Object
    For Each f In folderObj.SubFolders
        col.Add CStr(f.Path)
    Next f

    DxaSortedFolderPaths = DxaCollectionToSortedArray(col)
End Function

Private Function DxaSortedFilePaths(ByVal folderObj As Object) As Variant
    Dim col As Collection
    Set col = New Collection

    Dim f As Object
    For Each f In folderObj.Files
        col.Add CStr(f.Path)
    Next f

    DxaSortedFilePaths = DxaCollectionToSortedArray(col)
End Function

Private Function DxaCollectionToSortedArray(ByVal col As Collection) As Variant
    If col.Count = 0 Then
        DxaCollectionToSortedArray = Empty
        Exit Function
    End If

    Dim arr() As String
    ReDim arr(1 To col.Count)

    Dim i As Long
    For i = 1 To col.Count
        arr(i) = CStr(col(i))
    Next i

    DxaSortStringArray arr
    DxaCollectionToSortedArray = arr
End Function

Private Sub DxaSortStringArray(ByRef arr() As String)
    Dim i As Long
    Dim j As Long
    Dim tmp As String

    For i = LBound(arr) To UBound(arr) - 1
        For j = i + 1 To UBound(arr)
            If StrComp(arr(i), arr(j), vbTextCompare) > 0 Then
                tmp = arr(i)
                arr(i) = arr(j)
                arr(j) = tmp
            End If
        Next j
    Next i
End Sub

Private Function DxaVariantItemCount(ByVal values As Variant) As Long
    On Error GoTo EmptyValue
    If IsEmpty(values) Then
        DxaVariantItemCount = 0
    Else
        DxaVariantItemCount = UBound(values) - LBound(values) + 1
    End If
    Exit Function
EmptyValue:
    DxaVariantItemCount = 0
End Function

Private Function DxaFormatKb(ByVal bytes As Currency) As String
    DxaFormatKb = Format$(CDbl(bytes) / 1024#, "#,##0.0")
End Function

Private Function DxaPickSourceFolder(ByVal titleText As String) As String
    On Error GoTo Fallback
    Dim fd As FileDialog
    Set fd = Application.FileDialog(msoFileDialogFolderPicker)
    With fd
        .Title = titleText
        .AllowMultiSelect = False
        .InitialFileName = DxaDefaultFolder() & Application.PathSeparator
        If .Show <> -1 Then
            DxaPickSourceFolder = ""
        Else
            DxaPickSourceFolder = .SelectedItems(1)
        End If
    End With
    Exit Function
Fallback:
    DxaPickSourceFolder = InputBox(titleText & vbCrLf & "�t�H���_�̃p�X����͂��Ă��������B", "�t�H���_�I��", DxaDefaultFolder())
End Function

Public Sub DxaCreateFileList(ByVal control As Object)
    On Error GoTo ErrHandler

    Dim rootFolder As String
    rootFolder = DxaPickSourceFolder("�t�@�C���ꗗ���쐬����t�H���_��I�����Ă�������")
    If Len(rootFolder) = 0 Then Exit Sub

    Dim includeSubFoldersAnswer As VbMsgBoxResult
    includeSubFoldersAnswer = MsgBox("�T�u�t�H���_���̃t�@�C�����ꗗ�Ɋ܂߂܂����H" & vbCrLf & _
                                     "�͂�: �T�u�t�H���_���܂߂�" & vbCrLf & _
                                     "������: �I���t�H���_�����̂�", _
                                     vbQuestion + vbYesNoCancel, "�t�@�C���ꗗ")
    If includeSubFoldersAnswer = vbCancel Then Exit Sub

    Dim includeSubFolders As Boolean
    includeSubFolders = (includeSubFoldersAnswer = vbYes)

    Dim fso As Object
    Set fso = CreateObject("Scripting.FileSystemObject")
    If Not fso.FolderExists(rootFolder) Then
        MsgBox "�I�������t�H���_��������܂���B" & vbCrLf & rootFolder, vbExclamation, "�t�@�C���ꗗ"
        Exit Sub
    End If

    Dim wb As Workbook
    Set wb = ActiveWorkbook
    If wb Is Nothing Then Exit Sub

    Application.ScreenUpdating = False
    Application.DisplayAlerts = False

    Dim ws As Worksheet
    On Error Resume Next
    Set ws = wb.Worksheets("�t�@�C���ꗗ")
    On Error GoTo ErrHandler
    If Not ws Is Nothing Then ws.Delete

    Application.DisplayAlerts = True
    Set ws = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))
    ws.Name = "�t�@�C���ꗗ"

    ws.Range("A1:H1").Value = Array("No", "�t�@�C����", "�g���q", "�t�H���_", "�t���p�X", "�T�C�Y(KB)", "�X�V����", "�쐬����")
    ws.Range("A1:H1").Font.Bold = True
    ws.Range("A1:H1").Interior.Color = RGB(221, 235, 247)

    Dim rowNo As Long
    rowNo = 2

    Dim fileCount As Long
    fileCount = 0

    Dim root As Object
    Set root = fso.GetFolder(rootFolder)
    DxaOutputFileList ws, rowNo, root, includeSubFolders, fileCount

    ws.Columns("A:H").AutoFit
    ws.Range("A1:H1").AutoFilter
    ws.Activate
    ws.Range("A1").Select

    Application.DisplayAlerts = True
    Application.ScreenUpdating = True

    MsgBox "�t�@�C���ꗗ���쐬���܂����B" & vbCrLf & _
           "�Ώۃt�H���_: " & rootFolder & vbCrLf & _
           "�t�@�C����: " & fileCount & " ��", vbInformation, "�t�@�C���ꗗ"
    Exit Sub

ErrHandler:
    Application.DisplayAlerts = True
    Application.ScreenUpdating = True
    MsgBox "�t�@�C���ꗗ�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "�t�@�C���ꗗ"
End Sub

Private Sub DxaOutputFileList(ByVal ws As Worksheet, ByRef rowNo As Long, ByVal folderObj As Object, _
                              ByVal includeSubFolders As Boolean, ByRef fileCount As Long)
    On Error GoTo AccessDenied

    Dim filePaths As Variant
    filePaths = DxaSortedFilePaths(folderObj)

    Dim i As Long
    Dim fileObj As Object
    For i = 1 To DxaVariantItemCount(filePaths)
        Set fileObj = CreateObject("Scripting.FileSystemObject").GetFile(CStr(filePaths(i)))
        fileCount = fileCount + 1
        DxaWriteFileListLine ws, rowNo, fileCount, fileObj
        rowNo = rowNo + 1
    Next i

    If includeSubFolders Then
        Dim folderPaths As Variant
        folderPaths = DxaSortedFolderPaths(folderObj)
        For i = 1 To DxaVariantItemCount(folderPaths)
            DxaOutputFileList ws, rowNo, CreateObject("Scripting.FileSystemObject").GetFolder(CStr(folderPaths(i))), includeSubFolders, fileCount
        Next i
    End If

    Exit Sub
AccessDenied:
    ' �������Ȃ��t�H���_��ꎞ�I�ɎQ�Ƃł��Ȃ��t�@�C���͏������p�����܂��B
    Err.Clear
End Sub

Private Sub DxaWriteFileListLine(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal no As Long, ByVal fileObj As Object)
    On Error Resume Next

    ws.Cells(rowNo, 1).Value = no
    ws.Cells(rowNo, 2).Value = fileObj.Name
    ws.Hyperlinks.Add Anchor:=ws.Cells(rowNo, 2), Address:=fileObj.Path, TextToDisplay:=fileObj.Name
    ws.Cells(rowNo, 3).Value = DxaFileExtension(fileObj.Name)
    ws.Cells(rowNo, 4).Value = fileObj.ParentFolder.Path
    ws.Cells(rowNo, 5).Value = fileObj.Path
    ws.Hyperlinks.Add Anchor:=ws.Cells(rowNo, 5), Address:=fileObj.Path, TextToDisplay:=fileObj.Path
    ws.Cells(rowNo, 6).Value = Round(CDbl(fileObj.Size) / 1024, 1)
    ws.Cells(rowNo, 7).Value = fileObj.DateLastModified
    ws.Cells(rowNo, 8).Value = fileObj.DateCreated
End Sub

Private Function DxaFileExtension(ByVal fileName As String) As String
    Dim p As Long
    p = InStrRev(fileName, ".")
    If p > 0 And p < Len(fileName) Then
        DxaFileExtension = Mid$(fileName, p + 1)
    Else
        DxaFileExtension = ""
    End If
End Function

Public Sub DxaExportVbaWithFolderPicker(ByVal control As Object)

    On Error GoTo EH



    Dim wb As Workbook

    Set wb = ActiveWorkbook

    If wb Is Nothing Then Exit Sub



    Dim selectedFolder As String

    selectedFolder = DxaPickOutputFolder("VBA�G�N�X�|�[�g��t�H���_��I�����Ă�������")

    If Len(selectedFolder) = 0 Then Exit Sub



    Dim exportFolder As String

    exportFolder = selectedFolder & Application.PathSeparator & "VBAExport_" & DxaSafeFileName(DxaWorkbookBaseName(wb.Name)) & "_" & Format(Now, "yyyymmdd_hhnnss")

    If Dir(exportFolder, vbDirectory) = "" Then MkDir exportFolder



    Dim vbProj As Object

    Set vbProj = wb.VBProject



    Dim comp As Object

    Dim ext As String

    Dim exportPath As String

    Dim count As Long



    For Each comp In vbProj.VBComponents

        ext = DxaVbComponentExtension(CLng(comp.Type))

        exportPath = exportFolder & Application.PathSeparator & DxaSafeFileName(CStr(comp.Name)) & ext

        comp.Export exportPath

        count = count + 1

    Next comp



    MsgBox "VBA�\�[�X���G�N�X�|�[�g���܂����B" & vbCrLf & _

           "�o�͐�: " & exportFolder & vbCrLf & _

           "�o�͐�: " & CStr(count), vbInformation, "DExcelAssist"

    Exit Sub

EH:

    MsgBox "VBA�G�N�X�|�[�g�ŃG���[���������܂����B" & vbCrLf & _

           "Excel�́wVBA�v���W�F�N�g �I�u�W�F�N�g ���f���ւ̃A�N�Z�X��M������x���K�v�ł��B" & vbCrLf & _

           Err.Description, vbExclamation, "DExcelAssist"

End Sub



Private Function DxaPickOutputFolder(ByVal titleText As String) As String

    On Error GoTo Fallback

    Dim fd As FileDialog

    Set fd = Application.FileDialog(msoFileDialogFolderPicker)

    With fd

        .Title = titleText

        .AllowMultiSelect = False

        .InitialFileName = DxaDefaultFolder() & Application.PathSeparator

        If .Show <> -1 Then

            DxaPickOutputFolder = ""

        Else

            DxaPickOutputFolder = .SelectedItems(1)

        End If

    End With

    Exit Function

Fallback:

    DxaPickOutputFolder = InputBox(titleText & vbCrLf & "�t�H���_�̃p�X����͂��Ă��������B", "�t�H���_�I��", DxaDefaultFolder())

End Function



Private Function DxaDefaultFolder() As String

    On Error Resume Next

    If Len(ActiveWorkbook.Path) > 0 Then

        DxaDefaultFolder = ActiveWorkbook.Path

    Else

        DxaDefaultFolder = CreateObject("WScript.Shell").SpecialFolders("Desktop")

    End If

    If Len(DxaDefaultFolder) = 0 Then DxaDefaultFolder = CurDir$

End Function



Private Function DxaVbComponentExtension(ByVal componentType As Long) As String

    Select Case componentType

        Case 1

            DxaVbComponentExtension = ".bas"

        Case 2

            DxaVbComponentExtension = ".cls"

        Case 3

            DxaVbComponentExtension = ".frm"

        Case 100

            DxaVbComponentExtension = ".cls"

        Case Else

            DxaVbComponentExtension = ".txt"

    End Select

End Function



Private Function DxaWorkbookBaseName(ByVal fileName As String) As String

    Dim p As Long

    p = InStrRev(fileName, ".")

    If p > 1 Then

        DxaWorkbookBaseName = Left$(fileName, p - 1)

    Else

        DxaWorkbookBaseName = fileName

    End If

End Function



Private Function DxaSafeFileName(ByVal text As String) As String

    Dim s As String

    s = text

    s = Replace(s, "\", "_")

    s = Replace(s, "/", "_")

    s = Replace(s, ":", "_")

    s = Replace(s, "*", "_")

    s = Replace(s, "?", "_")

    s = Replace(s, """", "_")

    s = Replace(s, "<", "_")

    s = Replace(s, ">", "_")

    s = Replace(s, "|", "_")

    If Len(Trim$(s)) = 0 Then s = "Export"

    DxaSafeFileName = s

End Function



' ============================================================
' �ύX�����쐬�x��
' - ���u�b�N�ɂ̓V�[�g��ǉ����܂���B
' - �ύX�O��Ԃ͊O���ꎞ�t�@�C���֎����ۑ����܂��B
' - �ύX�����쐬�������A���̈ꎞ�t�@�C����ǂݍ���Ŕ�r���܂��B
' - �Ώۃu�b�N������Ƃ��A�܂���Excel�I�����Ɉꎞ�t�@�C�����폜���܂��B
' ============================================================

Public Sub Auto_Open()
    On Error Resume Next
    DxaInitChangeHistoryEvents
End Sub

Public Sub Auto_Close()
    On Error Resume Next
    DxaDeleteCurrentSessionSnapshots
End Sub

Public Sub DxaInitChangeHistoryEvents()
    On Error Resume Next
    If Len(gDxaSessionId) = 0 Then gDxaSessionId = Format$(Now, "yyyymmddhhnnss") & "_" & CStr(Int(Rnd() * 1000000))
    If gDxaEvents Is Nothing Then
        Set gDxaEvents = New DExcelAssistAppEvents
        gDxaEvents.Init Application
    End If

    DxaCleanupOldChangeSnapshots

    Dim wb As Workbook
    For Each wb In Application.Workbooks
        If Not DxaIsWorkbookExcluded(wb) Then
            DxaEnsureSnapshotForWorkbook wb
        End If
    Next
End Sub

Public Sub DxaEnsureSnapshotForWorkbook(ByVal wb As Workbook)
    On Error GoTo EH
    If wb Is Nothing Then Exit Sub
    If DxaIsWorkbookExcluded(wb) Then Exit Sub
    If Len(gDxaSessionId) = 0 Then DxaInitChangeHistoryEvents

    Dim path As String
    path = DxaSnapshotPathForWorkbook(wb)
    If Len(path) = 0 Then Exit Sub
    If DxaFileExists(path) Then Exit Sub

    Dim text As String
    text = DxaBuildSnapshotText(wb)
    DxaWriteTextUtf8 path, text
    Exit Sub
EH:
End Sub

Public Sub DxaDeleteSnapshotForWorkbook(ByVal wb As Workbook)
    On Error Resume Next
    If wb Is Nothing Then Exit Sub
    If Len(gDxaSessionId) = 0 Then Exit Sub
    Dim path As String
    path = DxaSnapshotPathForWorkbook(wb)
    If Len(path) > 0 Then
        If DxaFileExists(path) Then Kill path
    End If
End Sub

Public Sub DxaCreateChangeHistory(ByVal control As Object)
    On Error GoTo EH
    DxaInitChangeHistoryEvents

    Dim wb As Workbook
    Set wb = ActiveWorkbook
    If wb Is Nothing Then Exit Sub
    If DxaIsWorkbookExcluded(wb) Then
        MsgBox "�ύX�����쐬�̑Ώۃu�b�N���J���Ă�����s���Ă��������B", vbExclamation, "DExcelAssist"
        Exit Sub
    End If

    Dim snapshotPath As String
    snapshotPath = DxaSnapshotPathForWorkbook(wb)
    If Len(snapshotPath) = 0 Or Not DxaFileExists(snapshotPath) Then
        DxaEnsureSnapshotForWorkbook wb
        MsgBox "�ύX�O��Ԃ����쐬���������߁A���݂̏�Ԃ������ۑ����܂����B�ҏW��ɍēx�w�ύX�����쐬�x�����s���Ă��������B" & vbCrLf & vbCrLf & _
               "�����u�b�N�ɂ̓V�[�g��ǉ����Ă��܂���B", vbInformation, "DExcelAssist"
        Exit Sub
    End If

    Dim oldMap As Object
    Set oldMap = DxaReadSnapshotMap(snapshotPath)

    Dim curMap As Object
    Set curMap = DxaBuildSnapshotMap(wb)

    Dim details As Collection
    Set details = DxaCompareSnapshotMaps(oldMap, curMap)

    If details.Count = 0 Then
        MsgBox "�ύX�͌��o����܂���ł����B", vbInformation, "DExcelAssist"
        Exit Sub
    End If

    DxaOutputChangeHistoryWorkbook wb, details
    MsgBox "�ύX����\�t�p�u�b�N���쐬���܂����B" & vbCrLf & _
           "���u�b�N�ɂ̓V�[�g��ǉ����Ă��܂���B", vbInformation, "DExcelAssist"
    Exit Sub
EH:
    MsgBox "�ύX�����쐬�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DExcelAssist"
End Sub

Private Function DxaIsWorkbookExcluded(ByVal wb As Workbook) As Boolean
    On Error Resume Next
    If wb Is Nothing Then DxaIsWorkbookExcluded = True: Exit Function
    If wb.IsAddin Then DxaIsWorkbookExcluded = True: Exit Function
    If LCase$(wb.Name) = "dexcelassist.xlam" Then DxaIsWorkbookExcluded = True: Exit Function
    If LCase$(wb.Name) Like "�ύX�����o��_*" Then DxaIsWorkbookExcluded = True: Exit Function
    If LCase$(wb.Name) Like "book*" And wb.Path = "" Then
        ' �V�K�u�b�N���Ώۂɂ͂ł��܂����A�댟�m������邽�ߊJ��������̋�u�b�N�͏��O���܂��B
        If wb.Worksheets.Count = 1 And Application.WorksheetFunction.CountA(wb.Worksheets(1).Cells) = 0 Then
            DxaIsWorkbookExcluded = True
            Exit Function
        End If
    End If
End Function

Private Function DxaChangeSnapshotDir() As String
    Dim p As String
    p = Environ$("APPDATA") & "\DExcelAssist\ChangeSnapshots"
    DxaEnsureFolder p
    DxaChangeSnapshotDir = p
End Function

Private Function DxaSnapshotPathForWorkbook(ByVal wb As Workbook) As String
    If wb Is Nothing Then Exit Function
    If Len(gDxaSessionId) = 0 Then gDxaSessionId = Format$(Now, "yyyymmddhhnnss") & "_" & CStr(Int(Rnd() * 1000000))

    Dim keyText As String
    If Len(wb.FullName) > 0 Then
        keyText = wb.FullName
    Else
        keyText = wb.Name
    End If

    DxaSnapshotPathForWorkbook = DxaChangeSnapshotDir() & "\" & gDxaSessionId & "_" & DxaSafeFileName(DxaWorkbookBaseName(wb.Name)) & "_" & DxaSimpleHash(keyText) & ".tsv"
End Function

Private Function DxaBuildSnapshotText(ByVal wb As Workbook) As String
    Dim m As Object
    Set m = DxaBuildSnapshotMap(wb)

    Dim sb As String
    sb = "Key" & vbTab & "Sheet" & vbTab & "Address" & vbTab & "Row" & vbTab & "Column" & vbTab & "Header" & vbTab & "Item" & vbTab & "Formula" & vbTab & "Value" & vbTab & "Text" & vbTab & "Link" & vbTab & "Comment" & vbCrLf

    Dim k As Variant
    For Each k In m.Keys
        sb = sb & CStr(k) & vbTab & m(k) & vbCrLf
    Next

    DxaBuildSnapshotText = sb
End Function

Private Function DxaBuildSnapshotMap(ByVal wb As Workbook) As Object
    Dim dict As Object
    Set dict = CreateObject("Scripting.Dictionary")

    Dim ws As Worksheet
    For Each ws In wb.Worksheets
        If ws.Visible = xlSheetVisible Then
            DxaAddSheetSnapshot dict, ws
        End If
    Next

    Set DxaBuildSnapshotMap = dict
End Function

Private Sub DxaAddSheetSnapshot(ByVal dict As Object, ByVal ws As Worksheet)
    On Error GoTo EH
    Dim ur As Range
    Set ur = ws.UsedRange
    If ur Is Nothing Then Exit Sub

    Dim r1 As Long, c1 As Long, r2 As Long, c2 As Long
    r1 = ur.Row
    c1 = ur.Column
    r2 = ur.Row + ur.Rows.Count - 1
    c2 = ur.Column + ur.Columns.Count - 1

    Dim r As Long, c As Long
    Dim cell As Range
    For r = r1 To r2
        For c = c1 To c2
            Set cell = ws.Cells(r, c)
            If DxaCellHasSnapshotValue(cell) Then
                Dim key As String
                key = ws.Name & "!" & cell.Address(False, False)

                Dim headerText As String
                headerText = DxaGetHeaderText(ws, c)

                Dim itemText As String
                itemText = DxaGetRowItemText(ws, r)

                dict(key) = DxaJoinSnapshotFields(Array( _
                    DxaEsc(ws.Name), _
                    DxaEsc(cell.Address(False, False)), _
                    CStr(r), _
                    CStr(c), _
                    DxaEsc(headerText), _
                    DxaEsc(itemText), _
                    DxaEsc(DxaCellFormulaText(cell)), _
                    DxaEsc(DxaCellValueText(cell)), _
                    DxaEsc(DxaCellDisplayText(cell)), _
                    DxaEsc(DxaCellLinkText(cell)), _
                    DxaEsc(DxaCellCommentText(cell)) _
                ))
            End If
        Next c
    Next r
    Exit Sub
EH:
End Sub

Private Function DxaCellHasSnapshotValue(ByVal cell As Range) As Boolean
    On Error Resume Next
    If Len(DxaCellFormulaText(cell)) > 0 Then DxaCellHasSnapshotValue = True: Exit Function
    If Len(DxaCellValueText(cell)) > 0 Then DxaCellHasSnapshotValue = True: Exit Function
    If Len(DxaCellLinkText(cell)) > 0 Then DxaCellHasSnapshotValue = True: Exit Function
    If Len(DxaCellCommentText(cell)) > 0 Then DxaCellHasSnapshotValue = True: Exit Function
End Function

Private Function DxaCellFormulaText(ByVal cell As Range) As String
    On Error Resume Next
    If cell.HasFormula Then DxaCellFormulaText = CStr(cell.Formula)
End Function

Private Function DxaCellValueText(ByVal cell As Range) As String
    On Error Resume Next
    If IsError(cell.Value) Then
        DxaCellValueText = cell.Text
    Else
        DxaCellValueText = CStr(cell.Value)
    End If
End Function

Private Function DxaCellDisplayText(ByVal cell As Range) As String
    On Error Resume Next
    DxaCellDisplayText = CStr(cell.Text)
End Function

Private Function DxaCellLinkText(ByVal cell As Range) As String
    On Error Resume Next
    If cell.Hyperlinks.Count > 0 Then
        DxaCellLinkText = cell.Hyperlinks(1).Address
        If Len(cell.Hyperlinks(1).SubAddress) > 0 Then
            DxaCellLinkText = DxaCellLinkText & "#" & cell.Hyperlinks(1).SubAddress
        End If
    End If
End Function

Private Function DxaCellCommentText(ByVal cell As Range) As String
    On Error Resume Next
    If Not cell.Comment Is Nothing Then DxaCellCommentText = cell.Comment.Text
End Function

Private Function DxaGetHeaderText(ByVal ws As Worksheet, ByVal col As Long) As String
    On Error Resume Next
    Dim s As String
    s = Trim$(CStr(ws.Cells(1, col).Text))
    If Len(s) = 0 And col > 1 Then s = Trim$(CStr(ws.Cells(2, col).Text))
    If Len(s) = 0 Then s = DxaColumnLetter(col) & "��"
    DxaGetHeaderText = s
End Function

Private Function DxaGetRowItemText(ByVal ws As Worksheet, ByVal rowNo As Long) As String
    On Error Resume Next
    Dim s As String
    If rowNo > 1 Then
        s = Trim$(CStr(ws.Cells(rowNo, 1).Text))
        If Len(s) = 0 Then s = Trim$(CStr(ws.Cells(rowNo, 2).Text))
    End If
    If Len(s) = 0 Then s = CStr(rowNo) & "�s��"
    DxaGetRowItemText = s
End Function

Private Function DxaReadSnapshotMap(ByVal path As String) As Object
    Dim dict As Object
    Set dict = CreateObject("Scripting.Dictionary")

    Dim text As String
    text = DxaReadTextUtf8(path)

    Dim lines As Variant
    lines = Split(text, vbLf)

    Dim i As Long
    For i = LBound(lines) To UBound(lines)
        Dim lineText As String
        lineText = Replace(CStr(lines(i)), vbCr, "")
        If i > 0 And Len(lineText) > 0 Then
            Dim parts As Variant
            parts = Split(lineText, vbTab)
            If UBound(parts) >= 11 Then
                dict(parts(0)) = DxaJoinSnapshotFields(Array(parts(1), parts(2), parts(3), parts(4), parts(5), parts(6), parts(7), parts(8), parts(9), parts(10), parts(11)))
            End If
        End If
    Next

    Set DxaReadSnapshotMap = dict
End Function

Private Function DxaCompareSnapshotMaps(ByVal oldMap As Object, ByVal curMap As Object) As Collection
    Dim details As New Collection
    Dim k As Variant

    For Each k In oldMap.Keys
        If Not curMap.Exists(k) Then
            details.Add DxaBuildChangeDetail(CStr(k), "�폜", oldMap(k), "")
        ElseIf DxaSnapshotComparableText(oldMap(k)) <> DxaSnapshotComparableText(curMap(k)) Then
            details.Add DxaBuildChangeDetail(CStr(k), DxaDetectChangeType(oldMap(k), curMap(k)), oldMap(k), curMap(k))
        End If
    Next

    For Each k In curMap.Keys
        If Not oldMap.Exists(k) Then
            details.Add DxaBuildChangeDetail(CStr(k), "�ǉ�", "", curMap(k))
        End If
    Next

    Set DxaCompareSnapshotMaps = details
End Function

Private Function DxaSnapshotComparableText(ByVal recordText As String) As String
    Dim f As Variant
    f = DxaSplitSnapshotFields(recordText)
    If UBound(f) < 10 Then
        DxaSnapshotComparableText = recordText
    Else
        DxaSnapshotComparableText = f(6) & Chr$(30) & f(7) & Chr$(30) & f(9) & Chr$(30) & f(10)
    End If
End Function

Private Function DxaDetectChangeType(ByVal oldRecord As String, ByVal newRecord As String) As String
    Dim o As Variant, n As Variant
    o = DxaSplitSnapshotFields(oldRecord)
    n = DxaSplitSnapshotFields(newRecord)

    If UBound(o) >= 10 And UBound(n) >= 10 Then
        If o(6) <> n(6) Then DxaDetectChangeType = "�����ύX": Exit Function
        If o(7) <> n(7) Then DxaDetectChangeType = "�l�ύX": Exit Function
        If o(9) <> n(9) Then DxaDetectChangeType = "�����N�ύX": Exit Function
        If o(10) <> n(10) Then DxaDetectChangeType = "�R�����g�ύX": Exit Function
    End If
    DxaDetectChangeType = "�ύX"
End Function

Private Function DxaBuildChangeDetail(ByVal key As String, ByVal changeType As String, ByVal oldRecord As String, ByVal newRecord As String) As Variant
    Dim baseRecord As String
    If Len(newRecord) > 0 Then baseRecord = newRecord Else baseRecord = oldRecord

    Dim b As Variant, o As Variant, n As Variant
    b = DxaSplitSnapshotFields(baseRecord)
    If Len(oldRecord) > 0 Then o = DxaSplitSnapshotFields(oldRecord) Else o = DxaEmptySnapshotFields()
    If Len(newRecord) > 0 Then n = DxaSplitSnapshotFields(newRecord) Else n = DxaEmptySnapshotFields()

    Dim oldValue As String, newValue As String
    oldValue = DxaDisplayValueFromFields(o)
    newValue = DxaDisplayValueFromFields(n)

    DxaBuildChangeDetail = Array( _
        key, _
        changeType, _
        DxaUnesc(CStr(b(0))), _
        DxaUnesc(CStr(b(1))), _
        CLng(Val(b(2))), _
        CLng(Val(b(3))), _
        DxaUnesc(CStr(b(4))), _
        DxaUnesc(CStr(b(5))), _
        oldValue, _
        newValue _
    )
End Function

Private Function DxaEmptySnapshotFields() As Variant
    DxaEmptySnapshotFields = Array("", "", "0", "0", "", "", "", "", "", "", "")
End Function

Private Function DxaDisplayValueFromFields(ByVal f As Variant) As String
    If UBound(f) < 10 Then Exit Function
    If Len(DxaUnesc(CStr(f(6)))) > 0 Then
        DxaDisplayValueFromFields = DxaUnesc(CStr(f(6)))
    ElseIf Len(DxaUnesc(CStr(f(7)))) > 0 Then
        DxaDisplayValueFromFields = DxaUnesc(CStr(f(7)))
    ElseIf Len(DxaUnesc(CStr(f(9)))) > 0 Then
        DxaDisplayValueFromFields = DxaUnesc(CStr(f(9)))
    ElseIf Len(DxaUnesc(CStr(f(10)))) > 0 Then
        DxaDisplayValueFromFields = DxaUnesc(CStr(f(10)))
    End If
End Function

Private Sub DxaOutputChangeHistoryWorkbook(ByVal sourceWb As Workbook, ByVal details As Collection)
    Dim outWb As Workbook
    Set outWb = Workbooks.Add(xlWBATWorksheet)

    Dim wsSummary As Worksheet
    Set wsSummary = outWb.Worksheets(1)
    wsSummary.Name = "�ύX����\�t�p"

    Dim wsDetail As Worksheet
    Set wsDetail = outWb.Worksheets.Add(After:=wsSummary)
    wsDetail.Name = "�ύX�ڍ�"

    DxaWriteChangeDetailSheet sourceWb, wsDetail, details
    DxaWriteChangeSummarySheet wsSummary, details

    wsSummary.Activate
End Sub

Private Sub DxaWriteChangeDetailSheet(ByVal sourceWb As Workbook, ByVal ws As Worksheet, ByVal details As Collection)
    ws.Range("A1:J1").Value = Array("No", "�ΏۃV�[�g", "�Z��", "�s", "�񌩏o��", "�Ώ�", "�ύX���", "�ύX�O", "�ύX��", "�ύX���e")
    ws.Range("A1:J1").Font.Bold = True

    Dim i As Long
    For i = 1 To details.Count
        Dim d As Variant
        d = details(i)
        ws.Cells(i + 1, 1).Value = i
        ws.Cells(i + 1, 2).Value = d(2)
        ws.Cells(i + 1, 3).Value = d(3)
        ws.Cells(i + 1, 4).Value = d(4)
        ws.Cells(i + 1, 5).Value = d(6)
        ws.Cells(i + 1, 6).Value = d(7)
        ws.Cells(i + 1, 7).Value = d(1)
        ws.Cells(i + 1, 8).Value = d(8)
        ws.Cells(i + 1, 9).Value = d(9)
        ws.Cells(i + 1, 10).Value = DxaBuildDetailText(d)

        On Error Resume Next
        If Len(sourceWb.FullName) > 0 Then
            ws.Hyperlinks.Add Anchor:=ws.Cells(i + 1, 3), Address:=sourceWb.FullName, SubAddress:="'" & d(2) & "'!" & d(3), TextToDisplay:=d(3)
        End If
        On Error GoTo 0
    Next

    ws.Columns("A:J").AutoFit
    ws.Range("A1:J1").AutoFilter
End Sub

Private Sub DxaWriteChangeSummarySheet(ByVal ws As Worksheet, ByVal details As Collection)
    ws.Range("A1:E1").Value = Array("No", "�ύX��", "�ΏۃV�[�g", "�Ώ�", "�ύX���e")
    ws.Range("A1:E1").Font.Bold = True

    Dim groups As Object
    Set groups = CreateObject("Scripting.Dictionary")

    Dim i As Long
    For i = 1 To details.Count
        Dim d As Variant
        d = details(i)
        Dim gKey As String
        gKey = d(2) & "|" & CStr(d(4))
        If Not groups.Exists(gKey) Then
            groups(gKey) = DxaNewSummaryGroup(d)
        Else
            groups(gKey) = DxaAppendSummaryGroup(groups(gKey), d)
        End If
    Next

    Dim r As Long
    r = 2
    Dim k As Variant
    For Each k In groups.Keys
        Dim g As Variant
        g = Split(CStr(groups(k)), Chr$(31))
        ws.Cells(r, 1).Value = r - 1
        ws.Cells(r, 2).Value = Date
        ws.Cells(r, 3).Value = g(0)
        ws.Cells(r, 4).Value = g(2)
        ws.Cells(r, 5).Value = DxaBuildSummaryText(g)
        r = r + 1
    Next

    ws.Columns("A:E").AutoFit
    ws.Range("A1:E1").AutoFilter
End Sub

Private Function DxaNewSummaryGroup(ByVal d As Variant) As String
    DxaNewSummaryGroup = d(2) & Chr$(31) & CStr(d(4)) & Chr$(31) & d(7) & Chr$(31) & d(6) & Chr$(31) & d(1) & Chr$(31) & d(8) & Chr$(31) & d(9)
End Function

Private Function DxaAppendSummaryGroup(ByVal groupText As String, ByVal d As Variant) As String
    Dim g As Variant
    g = Split(groupText, Chr$(31))
    g(3) = DxaAppendUniqueText(CStr(g(3)), CStr(d(6)))
    g(4) = DxaAppendUniqueText(CStr(g(4)), CStr(d(1)))
    If Len(CStr(g(5))) = 0 Then g(5) = d(8)
    If Len(CStr(g(6))) = 0 Then g(6) = d(9)
    DxaAppendSummaryGroup = Join(g, Chr$(31))
End Function

Private Function DxaBuildSummaryText(ByVal g As Variant) As String
    Dim target As String
    target = CStr(g(2))
    If Len(Trim$(target)) = 0 Then target = CStr(g(1)) & "�s��"

    Dim headers As String
    headers = CStr(g(3))

    Dim types As String
    types = CStr(g(4))

    Dim oldSample As String
    oldSample = CStr(g(5))

    Dim newSample As String
    newSample = CStr(g(6))

    If InStr(types, "�ǉ�") > 0 And InStr(types, "�ύX") = 0 And InStr(types, "�폜") = 0 Then
        DxaBuildSummaryText = target & "�Ɂu" & DxaShortText(newSample) & "�v��ǉ��B"
    ElseIf InStr(types, "�폜") > 0 And InStr(types, "�ύX") = 0 And InStr(types, "�ǉ�") = 0 Then
        DxaBuildSummaryText = target & "�́u" & DxaShortText(oldSample) & "�v���폜�B"
    ElseIf DxaCountList(headers) = 1 And Len(oldSample) > 0 And Len(newSample) > 0 Then
        DxaBuildSummaryText = target & "��" & headers & "���u" & DxaShortText(oldSample) & "�v����u" & DxaShortText(newSample) & "�v�ɕύX�B"
    Else
        DxaBuildSummaryText = target & "��" & headers & "��ύX�B"
    End If
End Function

Private Function DxaBuildDetailText(ByVal d As Variant) As String
    Select Case CStr(d(1))
        Case "�ǉ�"
            DxaBuildDetailText = d(7) & "��" & d(6) & "�Ɂu" & DxaShortText(d(9)) & "�v��ǉ��B"
        Case "�폜"
            DxaBuildDetailText = d(7) & "��" & d(6) & "����u" & DxaShortText(d(8)) & "�v���폜�B"
        Case Else
            DxaBuildDetailText = d(7) & "��" & d(6) & "���u" & DxaShortText(d(8)) & "�v����u" & DxaShortText(d(9)) & "�v�ɕύX�B"
    End Select
End Function

Private Function DxaShortText(ByVal text As String) As String
    Dim s As String
    s = Replace(CStr(text), vbCr, " ")
    s = Replace(s, vbLf, " ")
    s = Trim$(s)
    If Len(s) > 80 Then s = Left$(s, 80) & "..."
    DxaShortText = s
End Function

Private Function DxaAppendUniqueText(ByVal baseText As String, ByVal addText As String) As String
    If Len(Trim$(addText)) = 0 Then
        DxaAppendUniqueText = baseText
    ElseIf Len(Trim$(baseText)) = 0 Then
        DxaAppendUniqueText = addText
    ElseIf InStr(1, "," & baseText & ",", "," & addText & ",", vbTextCompare) > 0 Then
        DxaAppendUniqueText = baseText
    Else
        DxaAppendUniqueText = baseText & "," & addText
    End If
End Function

Private Function DxaCountList(ByVal text As String) As Long
    If Len(Trim$(text)) = 0 Then Exit Function
    DxaCountList = UBound(Split(text, ",")) + 1
End Function

Private Function DxaJoinSnapshotFields(ByVal values As Variant) As String
    Dim i As Long
    Dim s As String
    For i = LBound(values) To UBound(values)
        If i > LBound(values) Then s = s & vbTab
        s = s & CStr(values(i))
    Next
    DxaJoinSnapshotFields = s
End Function

Private Function DxaSplitSnapshotFields(ByVal recordText As String) As Variant
    DxaSplitSnapshotFields = Split(CStr(recordText), vbTab)
End Function

Private Function DxaEsc(ByVal text As String) As String
    Dim s As String
    s = CStr(text)
    s = Replace(s, "\", "\\")
    s = Replace(s, vbCrLf, "\n")
    s = Replace(s, vbCr, "\n")
    s = Replace(s, vbLf, "\n")
    s = Replace(s, vbTab, "\t")
    s = Replace(s, Chr$(30), "\u001e")
    DxaEsc = s
End Function

Private Function DxaUnesc(ByVal text As String) As String
    Dim s As String
    s = CStr(text)

    Dim i As Long
    Dim ch As String
    Dim nx As String
    Dim result As String

    i = 1
    Do While i <= Len(s)
        ch = Mid$(s, i, 1)
        If ch = "\" And i < Len(s) Then
            nx = Mid$(s, i + 1, 1)
            Select Case nx
                Case "n"
                    result = result & vbLf
                    i = i + 2
                Case "t"
                    result = result & vbTab
                    i = i + 2
                Case "\"
                    result = result & "\"
                    i = i + 2
                Case "u"
                    If Mid$(s, i + 1, 5) = "u001e" Then
                        result = result & Chr$(30)
                        i = i + 6
                    Else
                        result = result & ch
                        i = i + 1
                    End If
                Case Else
                    result = result & ch
                    i = i + 1
            End Select
        Else
            result = result & ch
            i = i + 1
        End If
    Loop

    DxaUnesc = result
End Function

Private Sub DxaWriteTextUtf8(ByVal path As String, ByVal text As String)
    Dim stm As Object
    Set stm = CreateObject("ADODB.Stream")
    stm.Type = 2
    stm.Charset = "utf-8"
    stm.Open
    stm.WriteText text
    stm.SaveToFile path, 2
    stm.Close
End Sub

Private Function DxaReadTextUtf8(ByVal path As String) As String
    Dim stm As Object
    Set stm = CreateObject("ADODB.Stream")
    stm.Type = 2
    stm.Charset = "utf-8"
    stm.Open
    stm.LoadFromFile path
    DxaReadTextUtf8 = stm.ReadText
    stm.Close
End Function

Private Function DxaFileExists(ByVal path As String) As Boolean
    On Error Resume Next
    DxaFileExists = (Len(Dir$(path, vbNormal + vbHidden + vbSystem)) > 0)
End Function

Private Sub DxaEnsureFolder(ByVal folderPath As String)
    On Error Resume Next
    Dim fso As Object
    Set fso = CreateObject("Scripting.FileSystemObject")
    If Not fso.FolderExists(folderPath) Then fso.CreateFolder folderPath
End Sub

Private Sub DxaCleanupOldChangeSnapshots()
    On Error Resume Next
    Dim dirPath As String
    dirPath = DxaChangeSnapshotDir()
    Dim f As String
    f = Dir$(dirPath & "\*.tsv")
    Do While Len(f) > 0
        Dim p As String
        p = dirPath & "\" & f
        If DateDiff("d", FileDateTime(p), Now) >= 1 Then Kill p
        f = Dir$()
    Loop
End Sub

Private Sub DxaDeleteCurrentSessionSnapshots()
    On Error Resume Next
    If Len(gDxaSessionId) = 0 Then Exit Sub
    Dim dirPath As String
    dirPath = DxaChangeSnapshotDir()
    Dim f As String
    f = Dir$(dirPath & "\" & gDxaSessionId & "_*.tsv")
    Do While Len(f) > 0
        Kill dirPath & "\" & f
        f = Dir$()
    Loop
End Sub

Private Function DxaSimpleHash(ByVal text As String) As String
    Dim h As Double
    Dim i As Long
    Dim code As Long
    h = 5381
    For i = 1 To Len(text)
        code = AscW(Mid$(text, i, 1))
        If code < 0 Then code = code + 65536
        h = h * 33 + code
        h = h - Fix(h / 2147483647#) * 2147483647#
    Next
    DxaSimpleHash = Hex$(CLng(h))
End Function

Private Function DxaColumnLetter(ByVal col As Long) As String
    DxaColumnLetter = Split(Cells(1, col).Address(False, False), "1")(0)
End Function

'============================================================
' �\�L�h��`�F�b�N
'============================================================
Public Sub DxaCheckNotationVariants(ByVal control As Object)
    On Error GoTo EH

    Dim wb As Workbook
    Set wb = ActiveWorkbook
    If wb Is Nothing Then Exit Sub

    Dim groups As Object
    Set groups = DxaBuildNotationGroups()
    If groups.Count = 0 Then
        MsgBox "�\�L�h��`�F�b�N�p�̎�������ł��B", vbExclamation, "DExcelAssist"
        Exit Sub
    End If

    Application.ScreenUpdating = False
    Application.StatusBar = "DExcelAssist: �\�L�h����`�F�b�N���Ă��܂�..."

    Dim records As Collection
    Set records = New Collection

    Dim counts As Object
    Set counts = CreateObject("Scripting.Dictionary")

    Dim found As Object
    Set found = CreateObject("Scripting.Dictionary")

    Dim ws As Worksheet
    For Each ws In wb.Worksheets
        DxaScanNotationWorksheet ws, groups, records, counts, found
    Next

    Dim inconsistent As Object
    Set inconsistent = DxaBuildInconsistentNotationGroups(groups, found)

    DxaOutputNotationCheckWorkbook wb, groups, records, counts, inconsistent

    Application.StatusBar = False
    Application.ScreenUpdating = True

    If inconsistent.Count = 0 Then
        MsgBox "�\�L�h��͌��o����܂���ł����B���ʃu�b�N���쐬���܂����B", vbInformation, "DExcelAssist"
    Else
        MsgBox "�\�L�h��`�F�b�N���������܂����B���o�O���[�v��: " & inconsistent.Count, vbInformation, "DExcelAssist"
    End If
    Exit Sub
EH:
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "�\�L�h��`�F�b�N�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DExcelAssist"
End Sub

Private Function DxaBuildNotationGroups() As Object
    Dim groups As Object
    Set groups = CreateObject("Scripting.Dictionary")

    DxaAddNotationGroup groups, "server", "�T�[�o�[", "�T�[�o�[", "�T�[�o", "server", "Server", "SERVER"
    DxaAddNotationGroup groups, "user", "���[�U�[", "���[�U�[", "���[�U", "user", "User", "USER"
    DxaAddNotationGroup groups, "computer", "�R���s���[�^�[", "�R���s���[�^�[", "�R���s���[�^", "PC", "�p�\�R��"
    DxaAddNotationGroup groups, "printer", "�v�����^�[", "�v�����^�[", "�v�����^"
    DxaAddNotationGroup groups, "folder", "�t�H���_�[", "�t�H���_�[", "�t�H���_"
    DxaAddNotationGroup groups, "browser", "�u���E�U�[", "�u���E�U�[", "�u���E�U"
    DxaAddNotationGroup groups, "driver", "�h���C�o�[", "�h���C�o�[", "�h���C�o"
    DxaAddNotationGroup groups, "viewer", "�r���[�A�[", "�r���[�A�[", "�r���[�A"
    DxaAddNotationGroup groups, "parameter", "�p�����[�^�[", "�p�����[�^�[", "�p�����[�^"
    DxaAddNotationGroup groups, "member", "�����o�[", "�����o�[", "�����o"
    DxaAddNotationGroup groups, "data", "�f�[�^", "�f�[�^", "�f�[�^�["
    DxaAddNotationGroup groups, "database", "�f�[�^�x�[�X", "�f�[�^�x�[�X", "DB", "�c�a"
    DxaAddNotationGroup groups, "id", "ID", "ID", "�h�c", "Id", "id"
    DxaAddNotationGroup groups, "api", "API", "API", "�`�o�h", "Api", "api"
    DxaAddNotationGroup groups, "url", "URL", "URL", "�t�q�k", "Url", "url"
    DxaAddNotationGroup groups, "csv", "CSV", "CSV", "�b�r�u", "Csv", "csv"
    DxaAddNotationGroup groups, "pdf", "PDF", "PDF", "�o�c�e", "Pdf", "pdf"
    DxaAddNotationGroup groups, "excel", "Excel", "Excel", "EXCEL", "�G�N�Z��"
    DxaAddNotationGroup groups, "mail", "���[��", "���[��", "E���[��", "E-Mail", "e-mail", "Email", "email"
    DxaAddNotationGroup groups, "login", "���O�C��", "���O�C��", "���O�I��", "�T�C���C��"
    DxaAddNotationGroup groups, "logout", "���O�A�E�g", "���O�A�E�g", "���O�I�t", "�T�C���A�E�g"
    DxaAddNotationGroup groups, "password", "�p�X���[�h", "�p�X���[�h", "PW", "�o�v", "Password", "password"
    DxaAddNotationGroup groups, "message", "���b�Z�[�W", "���b�Z�[�W", "���b�Z�[�W�[", "MSG", "�l�r�f"
    DxaAddNotationGroup groups, "error", "�G���[", "�G���[", "�G���|", "ERROR", "Error", "error"
    DxaAddNotationGroup groups, "backup", "�o�b�N�A�b�v", "�o�b�N�A�b�v", "�o�b�NUP", "�o�b�N�A�b�v�f�[�^"
    DxaAddNotationGroup groups, "master", "�}�X�^�[", "�}�X�^�[", "�}�X�^"
    DxaAddNotationGroup groups, "manager", "�}�l�[�W���[", "�}�l�[�W���[", "�}�l�[�W��"
    DxaAddNotationGroup groups, "center", "�Z���^�[", "�Z���^�[", "�Z���^"
    DxaAddNotationGroup groups, "check", "�`�F�b�N", "�`�F�b�N", "�m�F"
    DxaAddNotationGroup groups, "delete", "�폜", "�폜", "����", "���"
    DxaAddNotationGroup groups, "update", "�X�V", "�X�V", "�A�b�v�f�[�g", "�C��"
    DxaAddNotationGroup groups, "create", "�쐬", "�쐬", "����", "���"
    DxaAddNotationGroup groups, "register", "�o�^", "�o�^", "�ǉ�"
    DxaAddNotationGroup groups, "output", "�o��", "�o��", "�G�N�X�|�[�g", "Export", "export"
    DxaAddNotationGroup groups, "input", "����", "����", "�C���|�[�g", "Import", "import"

    DxaLoadUserNotationDictionary groups
    Set DxaBuildNotationGroups = groups
End Function

Private Sub DxaAddNotationGroup(ByVal groups As Object, ByVal groupId As String, ByVal preferred As String, ParamArray variants() As Variant)
    Dim d As Object
    Set d = CreateObject("Scripting.Dictionary")
    d("preferred") = CStr(preferred)
    d("variants") = DxaSortVariantsByLength(variants)
    If groups.Exists(CStr(groupId)) Then
        Set groups(CStr(groupId)) = d
    Else
        groups.Add CStr(groupId), d
    End If
End Sub

Private Function DxaSortVariantsByLength(ByVal variants As Variant) As Variant
    Dim arr() As String
    Dim i As Long
    ReDim arr(LBound(variants) To UBound(variants))
    For i = LBound(variants) To UBound(variants)
        arr(i) = CStr(variants(i))
    Next

    Dim j As Long, tmp As String
    For i = LBound(arr) To UBound(arr) - 1
        For j = i + 1 To UBound(arr)
            If Len(arr(j)) > Len(arr(i)) Then
                tmp = arr(i): arr(i) = arr(j): arr(j) = tmp
            End If
        Next
    Next
    DxaSortVariantsByLength = arr
End Function

Private Sub DxaLoadUserNotationDictionary(ByVal groups As Object)
    On Error Resume Next
    Dim path As String
    path = DxaNotationDictionaryPath()
    If Len(Dir$(path)) = 0 Then Exit Sub

    Dim text As String
    text = DxaReadTextUtf8(path)
    If Len(text) = 0 Then Exit Sub

    Dim lines As Variant
    lines = Split(Replace(text, vbCrLf, vbLf), vbLf)

    Dim i As Long
    For i = LBound(lines) To UBound(lines)
        Dim line As String
        line = Trim$(CStr(lines(i)))
        If Len(line) = 0 Then GoTo ContinueLine
        If Left$(line, 1) = "#" Then GoTo ContinueLine

        Dim parts As Variant
        parts = Split(line, ",")
        If UBound(parts) >= 1 Then
            Dim preferred As String
            preferred = Trim$(CStr(parts(0)))
            If Len(preferred) > 0 Then
                Dim v() As Variant
                ReDim v(0 To UBound(parts))
                Dim j As Long
                v(0) = preferred
                For j = 1 To UBound(parts)
                    v(j) = Trim$(CStr(parts(j)))
                Next
                DxaAddNotationGroup groups, "user_" & CStr(i), preferred, v
            End If
        End If
ContinueLine:
    Next
End Sub

Private Function DxaNotationDictionaryPath() As String
    DxaNotationDictionaryPath = Environ$("APPDATA") & "\DExcelAssist\notation_variants.csv"
End Function

Private Sub DxaScanNotationWorksheet(ByVal ws As Worksheet, ByVal groups As Object, ByVal records As Collection, ByVal counts As Object, ByVal found As Object)
    On Error Resume Next
    If Application.WorksheetFunction.CountA(ws.Cells) > 0 Then
        Dim rng As Range
        Set rng = ws.UsedRange
        If Not rng Is Nothing Then
            Dim c As Range
            For Each c In rng.Cells
                If Not IsError(c.Value) Then
                    Dim text As String
                    text = CStr(c.Value)
                    If Len(text) > 0 Then DxaCollectNotationHits groups, records, counts, found, ws.Name, c.Address(False, False), "�Z��", text
                End If
            Next
        End If
    End If

    Dim shp As Shape
    For Each shp In ws.Shapes
        Dim s As String
        s = ""
        On Error Resume Next
        If shp.TextFrame2.HasText Then s = shp.TextFrame2.TextRange.Text
        If Len(s) = 0 Then
            If shp.TextFrame.HasText Then s = shp.TextFrame.Characters.Text
        End If
        On Error GoTo 0
        If Len(s) > 0 Then DxaCollectNotationHits groups, records, counts, found, ws.Name, shp.Name, "�}�`", s
    Next
End Sub

Private Sub DxaCollectNotationHits(ByVal groups As Object, ByVal records As Collection, ByVal counts As Object, ByVal found As Object, ByVal sheetName As String, ByVal location As String, ByVal kind As String, ByVal text As String)
    Dim gKey As Variant
    For Each gKey In groups.Keys
        Dim g As Object
        Set g = groups(gKey)
        Dim vars As Variant
        vars = g("variants")

        Dim i As Long
        For i = LBound(vars) To UBound(vars)
            Dim variantText As String
            variantText = CStr(vars(i))
            If Len(variantText) > 0 Then
                If DxaContainsNotationVariant(text, variantText) Then
                    Dim countKey As String
                    countKey = CStr(gKey) & Chr$(31) & variantText
                    If counts.Exists(countKey) Then counts(countKey) = CLng(counts(countKey)) + 1 Else counts(countKey) = 1
                    found(countKey) = True
                    records.Add Array(CStr(gKey), variantText, CStr(g("preferred")), sheetName, location, kind, DxaShortText(text))
                End If
            End If
        Next
    Next
End Sub

Private Function DxaContainsNotationVariant(ByVal text As String, ByVal variantText As String) As Boolean
    Dim pos As Long
    pos = 1
    Do
        pos = InStr(pos, text, variantText, vbTextCompare)
        If pos = 0 Then Exit Function
        If DxaIsValidNotationHit(text, variantText, pos) Then
            DxaContainsNotationVariant = True
            Exit Function
        End If
        pos = pos + Len(variantText)
    Loop
End Function

Private Function DxaIsValidNotationHit(ByVal text As String, ByVal variantText As String, ByVal pos As Long) As Boolean
    Dim beforeCh As String, afterCh As String
    beforeCh = "": afterCh = ""
    If pos > 1 Then beforeCh = Mid$(text, pos - 1, 1)
    If pos + Len(variantText) <= Len(text) Then afterCh = Mid$(text, pos + Len(variantText), 1)

    If DxaIsAsciiWord(variantText) Then
        If DxaIsAsciiWordChar(beforeCh) Then Exit Function
        If DxaIsAsciiWordChar(afterCh) Then Exit Function
    End If

    If Right$(variantText, 1) <> "�[" And Right$(variantText, 1) <> "�" Then
        If afterCh = "�[" Or afterCh = "�" Then Exit Function
    End If

    DxaIsValidNotationHit = True
End Function

Private Function DxaIsAsciiWord(ByVal s As String) As Boolean
    Dim i As Long, code As Long
    If Len(s) = 0 Then Exit Function
    For i = 1 To Len(s)
        code = AscW(Mid$(s, i, 1))
        If Not ((code >= 48 And code <= 57) Or (code >= 65 And code <= 90) Or (code >= 97 And code <= 122) Or code = 95) Then Exit Function
    Next
    DxaIsAsciiWord = True
End Function

Private Function DxaIsAsciiWordChar(ByVal s As String) As Boolean
    If Len(s) = 0 Then Exit Function
    DxaIsAsciiWordChar = DxaIsAsciiWord(Left$(s, 1))
End Function

Private Function DxaBuildInconsistentNotationGroups(ByVal groups As Object, ByVal found As Object) As Object
    Dim inconsistent As Object
    Set inconsistent = CreateObject("Scripting.Dictionary")

    Dim gKey As Variant
    For Each gKey In groups.Keys
        Dim g As Object
        Set g = groups(gKey)
        Dim vars As Variant
        vars = g("variants")
        Dim foundCount As Long
        Dim i As Long
        For i = LBound(vars) To UBound(vars)
            If found.Exists(CStr(gKey) & Chr$(31) & CStr(vars(i))) Then foundCount = foundCount + 1
        Next
        If foundCount >= 2 Then inconsistent(CStr(gKey)) = True
    Next

    Set DxaBuildInconsistentNotationGroups = inconsistent
End Function

Private Sub DxaOutputNotationCheckWorkbook(ByVal sourceWb As Workbook, ByVal groups As Object, ByVal records As Collection, ByVal counts As Object, ByVal inconsistent As Object)
    Dim outWb As Workbook
    Set outWb = Workbooks.Add(xlWBATWorksheet)

    Dim wsSummary As Worksheet
    Set wsSummary = outWb.Worksheets(1)
    wsSummary.Name = "�\�L�h��`�F�b�N"

    Dim wsDetail As Worksheet
    Set wsDetail = outWb.Worksheets.Add(After:=wsSummary)
    wsDetail.Name = "���o�ڍ�"

    DxaWriteNotationSummarySheet wsSummary, groups, counts, inconsistent
    DxaWriteNotationDetailSheet sourceWb, wsDetail, records, inconsistent

    wsSummary.Activate
End Sub

Private Sub DxaWriteNotationSummarySheet(ByVal ws As Worksheet, ByVal groups As Object, ByVal counts As Object, ByVal inconsistent As Object)
    ws.Range("A1:F1").Value = Array("No", "�����\�L", "���o�\�L", "����", "����", "���l")
    ws.Range("A1:F1").Font.Bold = True

    Dim r As Long
    r = 2

    If inconsistent.Count = 0 Then
        ws.Cells(r, 1).Value = 1
        ws.Cells(r, 5).Value = "�\�L�h��Ȃ�"
        ws.Cells(r, 6).Value = "����O���[�v���ŕ����\�L�͌��o����܂���ł����B"
    Else
        Dim gKey As Variant
        For Each gKey In groups.Keys
            If inconsistent.Exists(CStr(gKey)) Then
                Dim g As Object
                Set g = groups(gKey)
                Dim vars As Variant
                vars = g("variants")
                Dim i As Long
                For i = LBound(vars) To UBound(vars)
                    Dim countKey As String
                    countKey = CStr(gKey) & Chr$(31) & CStr(vars(i))
                    If counts.Exists(countKey) Then
                        ws.Cells(r, 1).Value = r - 1
                        ws.Cells(r, 2).Value = CStr(g("preferred"))
                        ws.Cells(r, 3).Value = CStr(vars(i))
                        ws.Cells(r, 4).Value = CLng(counts(countKey))
                        If StrComp(CStr(vars(i)), CStr(g("preferred")), vbTextCompare) = 0 Then
                            ws.Cells(r, 5).Value = "�����\�L"
                        Else
                            ws.Cells(r, 5).Value = "�h����"
                        End If
                        ws.Cells(r, 6).Value = "�����\�L�ɓ��ꂷ�邩�m�F���Ă��������B"
                        r = r + 1
                    End If
                Next
            End If
        Next
    End If

    ws.Columns("A:F").AutoFit
    ws.Range("A1:F1").AutoFilter
End Sub

Private Sub DxaWriteNotationDetailSheet(ByVal sourceWb As Workbook, ByVal ws As Worksheet, ByVal records As Collection, ByVal inconsistent As Object)
    ws.Range("A1:H1").Value = Array("No", "�ΏۃV�[�g", "�ꏊ", "���", "���o�\�L", "�����\�L", "���Ӄe�L�X�g", "�m�F����")
    ws.Range("A1:H1").Font.Bold = True

    Dim r As Long
    r = 2

    Dim i As Long
    For i = 1 To records.Count
        Dim rec As Variant
        rec = records(i)
        If inconsistent.Exists(CStr(rec(0))) Then
            ws.Cells(r, 1).Value = r - 1
            ws.Cells(r, 2).Value = rec(3)
            ws.Cells(r, 3).Value = rec(4)
            ws.Cells(r, 4).Value = rec(5)
            ws.Cells(r, 5).Value = rec(1)
            ws.Cells(r, 6).Value = rec(2)
            ws.Cells(r, 7).Value = rec(6)
            ws.Cells(r, 8).Value = "�v�m�F"

            On Error Resume Next
            If CStr(rec(5)) = "�Z��" And Len(sourceWb.FullName) > 0 Then
                ws.Hyperlinks.Add Anchor:=ws.Cells(r, 3), Address:=sourceWb.FullName, SubAddress:="'" & rec(3) & "'!" & rec(4), TextToDisplay:=rec(4)
            End If
            On Error GoTo 0
            r = r + 1
        End If
    Next

    If r = 2 Then
        ws.Cells(2, 1).Value = 1
        ws.Cells(2, 8).Value = "�\�L�h��Ȃ�"
    End If

    ws.Columns("A:H").AutoFit
    ws.Range("A1:H1").AutoFilter
End Sub

' ============================================================
' �d��Excel�f�f
' ���u�b�N�ɂ̓V�[�g��ǉ������A�f�f���ʂ�ʃu�b�N�ɏo�͂��܂��B
' ============================================================
Public Sub DxaDiagnoseHeavyWorkbook(ByVal control As Object)
    On Error GoTo EH

    Dim srcWb As Workbook
    Set srcWb = ActiveWorkbook
    If srcWb Is Nothing Then Exit Sub
    If srcWb.Name = ThisWorkbook.Name Then
        MsgBox "�f�f�Ώۂ̃u�b�N���A�N�e�B�u�ɂ��Ă�����s���Ă��������B", vbExclamation, "DExcelAssist"
        Exit Sub
    End If

    Dim reportWb As Workbook
    Dim wsSummary As Worksheet
    Dim wsDetail As Worksheet

    Application.ScreenUpdating = False
    Application.StatusBar = "DExcelAssist: �d��Excel�f�f�����s���Ă��܂�..."

    Set reportWb = Application.Workbooks.Add(xlWBATWorksheet)
    Set wsSummary = reportWb.Worksheets(1)
    wsSummary.Name = "�d��Excel�f�f"
    Set wsDetail = reportWb.Worksheets.Add(After:=wsSummary)
    wsDetail.Name = "�f�f�ڍ�"

    DxaPrepareHeavySummarySheet wsSummary, srcWb
    DxaPrepareHeavyDetailSheet wsDetail

    Dim detailRow As Long
    detailRow = 2

    Dim totalFormula As Double
    Dim totalVolatile As Double
    Dim totalFormatConditions As Double
    Dim totalValidations As Double
    Dim totalShapes As Double
    Dim totalPictures As Double
    Dim totalHyperlinks As Double
    Dim totalComments As Double
    Dim totalPivotTables As Double
    Dim totalTables As Double
    Dim totalHiddenSheets As Double
    Dim totalBloatedUsedRange As Double
    Dim totalLargeSheets As Double

    Dim ws As Worksheet
    For Each ws In srcWb.Worksheets
        Application.StatusBar = "DExcelAssist: �d��Excel�f�f�� - " & ws.Name

        Dim lastRow As Long
        Dim lastCol As Long
        Dim hasData As Boolean
        hasData = DxaGetActualLastCell(ws, lastRow, lastCol)

        Dim usedRows As Double
        Dim usedCols As Double
        Dim usedCells As Double
        usedRows = 0
        usedCols = 0
        usedCells = 0
        On Error Resume Next
        usedRows = CDbl(ws.UsedRange.Rows.Count)
        usedCols = CDbl(ws.UsedRange.Columns.Count)
        usedCells = CDbl(ws.UsedRange.CountLarge)
        On Error GoTo EH

        Dim actualCells As Double
        If hasData Then
            actualCells = CDbl(lastRow) * CDbl(lastCol)
        Else
            actualCells = 0
        End If

        Dim formulaCount As Double
        formulaCount = DxaCountSpecialCells(ws, xlCellTypeFormulas)
        totalFormula = totalFormula + formulaCount

        Dim volatileCount As Double
        volatileCount = DxaCountVolatileFormulas(ws)
        totalVolatile = totalVolatile + volatileCount

        Dim fcCount As Double
        fcCount = DxaCountFormatConditions(ws)
        totalFormatConditions = totalFormatConditions + fcCount

        Dim validationCount As Double
        validationCount = DxaCountSpecialCells(ws, xlCellTypeAllValidation)
        totalValidations = totalValidations + validationCount

        Dim shapeCount As Double
        shapeCount = DxaSafeShapeCount(ws)
        totalShapes = totalShapes + shapeCount

        Dim pictureCount As Double
        pictureCount = DxaSafePictureCount(ws)
        totalPictures = totalPictures + pictureCount

        Dim hyperlinkCount As Double
        hyperlinkCount = DxaSafeHyperlinkCount(ws)
        totalHyperlinks = totalHyperlinks + hyperlinkCount

        Dim commentCount As Double
        commentCount = DxaSafeCommentCount(ws)
        totalComments = totalComments + commentCount

        Dim pivotCount As Double
        pivotCount = DxaSafePivotCount(ws)
        totalPivotTables = totalPivotTables + pivotCount

        Dim tableCount As Double
        tableCount = DxaSafeTableCount(ws)
        totalTables = totalTables + tableCount

        If ws.Visible <> xlSheetVisible Then totalHiddenSheets = totalHiddenSheets + 1

        Dim usedRangeStatus As String
        Dim usedRangeReason As String
        usedRangeStatus = "OK"
        usedRangeReason = "�g�p�͈͂ɑ傫�Ȉُ�͌�����܂���B"
        If usedCells >= 1000000# Then
            usedRangeStatus = "����"
            usedRangeReason = "UsedRange���傫���ł��B�s�v�ȍs��ɏ������c���Ă���\��������܂��B"
            totalLargeSheets = totalLargeSheets + 1
        End If
        If hasData Then
            If (usedRows > lastRow + 1000) Or (usedCols > lastCol + 20) Then
                usedRangeStatus = "�x��"
                usedRangeReason = "���f�[�^�͈͂��UsedRange���L���ł��B���g�p�͈͂̃��Z�b�g���ł��B"
                totalBloatedUsedRange = totalBloatedUsedRange + 1
            End If
        End If

        DxaWriteHeavyDetail wsDetail, detailRow, "�V�[�g�T�v", ws.Name, "�\�����", DxaSheetVisibleText(ws), DxaStatusBySheetVisible(ws), "��\��/VeryHidden�V�[�g���s�v�ł���Ε\���܂��͍폜���������Ă��������B"
        DxaWriteHeavyDetail wsDetail, detailRow, "�g�p�͈�", ws.Name, "UsedRange", "�s=" & CStr(usedRows) & ", ��=" & CStr(usedCols) & ", �Z��=" & Format$(usedCells, "#,##0"), usedRangeStatus, usedRangeReason
        DxaWriteHeavyDetail wsDetail, detailRow, "���f�[�^�͈�", ws.Name, "�ŏI�Z��", IIf(hasData, "�s=" & CStr(lastRow) & ", ��=" & CStr(lastCol), "�f�[�^�Ȃ�"), "���", "UsedRange�Ǝ��f�[�^�͈͂̍����傫���ꍇ�AExcel���d���Ȃ錴���ɂȂ�܂��B"
        DxaWriteHeavyDetail wsDetail, detailRow, "����", ws.Name, "�����Z����", Format$(formulaCount, "#,##0"), DxaStatusByNumber(formulaCount, 10000, 50000), "�����������ꍇ�͌v�Z�����A�s�v�����A�l�\��t�����������Ă��������B"
        DxaWriteHeavyDetail wsDetail, detailRow, "�������֐�", ws.Name, "���茏��", Format$(volatileCount, "#,##0"), DxaStatusByNumber(volatileCount, 1, 100), "NOW/TODAY/RAND/OFFSET/INDIRECT�Ȃǂ͍Čv�Z���ׂ������Ȃ�ꍇ������܂��B"
        DxaWriteHeavyDetail wsDetail, detailRow, "�����t������", ws.Name, "����", Format$(fcCount, "#,##0"), DxaStatusByNumber(fcCount, 100, 1000), "�R�s�[�\��t���ŏ����t�����������B���Ă��Ȃ����m�F���Ă��������B"
        DxaWriteHeavyDetail wsDetail, detailRow, "���͋K��", ws.Name, "�ΏۃZ����", Format$(validationCount, "#,##0"), DxaStatusByNumber(validationCount, 5000, 50000), "���͋K������ʂɕ��������Ɠ��삪�d���Ȃ�ꍇ������܂��B"
        DxaWriteHeavyDetail wsDetail, detailRow, "�}�`/�摜", ws.Name, "�}�`=" & Format$(shapeCount, "#,##0"), "�摜=" & Format$(pictureCount, "#,##0"), DxaStatusByNumber(shapeCount, 100, 500), "�s�v�Ȑ}�`�A�����摜�A�\��t���摜���c���Ă��Ȃ����m�F���Ă��������B"
        DxaWriteHeavyDetail wsDetail, detailRow, "�����N/�R�����g", ws.Name, "�����N=" & Format$(hyperlinkCount, "#,##0"), "�R�����g=" & Format$(commentCount, "#,##0"), DxaStatusByNumber(hyperlinkCount + commentCount, 200, 1000), "�s�v�ȃ����N�A�R�����g�A�������c���Ă��Ȃ����m�F���Ă��������B"
        DxaWriteHeavyDetail wsDetail, detailRow, "�W�v�I�u�W�F�N�g", ws.Name, "�s�{�b�g=" & Format$(pivotCount, "#,##0"), "�e�[�u��=" & Format$(tableCount, "#,##0"), "���", "�s�{�b�g��e�[�u���������ꍇ�͍X�V�͈͂�L���b�V�����m�F���Ă��������B"
    Next ws

    Dim externalLinkCount As Double
    externalLinkCount = DxaCountExternalLinks(srcWb)

    Dim nameCount As Double
    Dim brokenNameCount As Double
    Dim externalNameCount As Double
    DxaCountNames srcWb, nameCount, brokenNameCount, externalNameCount

    Dim styleCount As Double
    styleCount = DxaSafeStyleCount(srcWb)

    Dim fileSizeText As String
    Dim fileSizeMB As Double
    fileSizeMB = DxaWorkbookFileSizeMB(srcWb)
    If fileSizeMB >= 0 Then
        fileSizeText = Format$(fileSizeMB, "0.00") & " MB"
    Else
        fileSizeText = "���ۑ��܂��͎擾�s��"
    End If

    Dim r As Long
    r = 5
    DxaWriteHeavySummary wsSummary, r, "�t�@�C���T�C�Y", DxaStatusByFileSize(fileSizeMB), fileSizeText, "�t�@�C���T�C�Y���傫���ꍇ�͉摜�A�����t�������A���g�p�͈́A�s�v�X�^�C�����m�F���Ă��������B"
    DxaWriteHeavySummary wsSummary, r, "�V�[�g��", DxaStatusByNumber(srcWb.Worksheets.Count, 30, 80), CStr(srcWb.Worksheets.Count), "�V�[�g���������ꍇ�͕s�v�V�[�g���\���V�[�g���m�F���Ă��������B"
    DxaWriteHeavySummary wsSummary, r, "��\���V�[�g��", DxaStatusByNumber(totalHiddenSheets, 1, 10), Format$(totalHiddenSheets, "#,##0"), "�s�v�Ȕ�\��/VeryHidden�V�[�g���Ȃ����m�F���Ă��������B"
    DxaWriteHeavySummary wsSummary, r, "UsedRange�����", DxaStatusByNumber(totalBloatedUsedRange, 1, 5), Format$(totalBloatedUsedRange, "#,##0"), "���f�[�^�͈͂��UsedRange���L���V�[�g�́A���g�p�͈̓��Z�b�g���ł��B"
    DxaWriteHeavySummary wsSummary, r, "��K��UsedRange�V�[�g", DxaStatusByNumber(totalLargeSheets, 1, 5), Format$(totalLargeSheets, "#,##0"), "�g�p�͈͂����ɑ傫���V�[�g�͏d���Ȃ錴���ł��B"
    DxaWriteHeavySummary wsSummary, r, "�����Z����", DxaStatusByNumber(totalFormula, 50000, 200000), Format$(totalFormula, "#,##0"), "�����������ꍇ�A�l�\��t���E�v�Z�͈͌��������������Ă��������B"
    DxaWriteHeavySummary wsSummary, r, "�������֐����萔", DxaStatusByNumber(totalVolatile, 1, 100), Format$(totalVolatile, "#,##0"), "�������֐��͍Čv�Z���ׂ��������߁A�K�v�����m�F���Ă��������B"
    DxaWriteHeavySummary wsSummary, r, "�����t��������", DxaStatusByNumber(totalFormatConditions, 500, 3000), Format$(totalFormatConditions, "#,##0"), "�����t�����������B���Ă���ꍇ�͐������Ă��������B"
    DxaWriteHeavySummary wsSummary, r, "���͋K���ΏۃZ����", DxaStatusByNumber(totalValidations, 10000, 100000), Format$(totalValidations, "#,##0"), "���͋K�����L�͈͂ɐݒ肳��Ă���ꍇ�͔͈͂��������Ă��������B"
    DxaWriteHeavySummary wsSummary, r, "�}�`��", DxaStatusByNumber(totalShapes, 200, 1000), Format$(totalShapes, "#,##0"), "�s�v�Ȑ}�`�ⓧ���I�u�W�F�N�g���Ȃ����m�F���Ă��������B"
    DxaWriteHeavySummary wsSummary, r, "�摜��", DxaStatusByNumber(totalPictures, 50, 200), Format$(totalPictures, "#,##0"), "�摜�������ꍇ�͈��k��s�v�摜�폜���������Ă��������B"
    DxaWriteHeavySummary wsSummary, r, "�O�������N��", DxaStatusByNumber(externalLinkCount, 1, 10), Format$(externalLinkCount, "#,##0"), "�s�v�ȊO�������N���c���Ă��Ȃ����m�F���Ă��������B"
    DxaWriteHeavySummary wsSummary, r, "���O��`��", DxaStatusByNumber(nameCount, 200, 1000), Format$(nameCount, "#,##0"), "�s�v�Ȗ��O��`�������Ă��Ȃ����m�F���Ă��������B"
    DxaWriteHeavySummary wsSummary, r, "�Q�Ɛ؂ꖼ�O��`��", DxaStatusByNumber(brokenNameCount, 1, 10), Format$(brokenNameCount, "#,##0"), "#REF!���܂ޖ��O��`�͍폜���ł��B"
    DxaWriteHeavySummary wsSummary, r, "�O���Q�Ɩ��O��`��", DxaStatusByNumber(externalNameCount, 1, 10), Format$(externalNameCount, "#,##0"), "���O��`���̊O���Q�Ƃ͊O�������N�x���̌����ɂȂ�ꍇ������܂��B"
    DxaWriteHeavySummary wsSummary, r, "�X�^�C����", DxaStatusByNumber(styleCount, 500, 2000), Format$(styleCount, "#,##0"), "�s�v�X�^�C�������B���Ă���ꍇ�A�t�@�C����剻�̌����ɂȂ�ꍇ������܂��B"

    wsSummary.Columns("A:D").AutoFit
    wsDetail.Columns("A:G").AutoFit
    wsSummary.Range("A4:D4").AutoFilter
    wsDetail.Range("A1:G1").AutoFilter
    wsSummary.Activate
    wsSummary.Range("A1").Select

    Application.StatusBar = False
    Application.ScreenUpdating = True

    MsgBox "�d��Excel�f�f���������܂����B���ʂ͕ʃu�b�N�ɏo�͂��܂����B", vbInformation, "DExcelAssist"
    Exit Sub

EH:
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "�d��Excel�f�f�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DExcelAssist"
End Sub

Private Sub DxaPrepareHeavySummarySheet(ByVal ws As Worksheet, ByVal srcWb As Workbook)
    ws.Range("A1").Value = "�d��Excel�f�f"
    ws.Range("A1").Font.Bold = True
    ws.Range("A1").Font.Size = 16
    ws.Range("A2").Value = "�Ώۃu�b�N"
    ws.Range("B2").Value = srcWb.Name
    ws.Range("A3").Value = "�f�f����"
    ws.Range("B3").Value = Now
    ws.Range("B3").NumberFormatLocal = "yyyy/mm/dd hh:mm:ss"
    ws.Range("A4:D4").Value = Array("�f�f����", "����", "����/�l", "�����Ή�")
    ws.Range("A4:D4").Font.Bold = True
End Sub

Private Sub DxaPrepareHeavyDetailSheet(ByVal ws As Worksheet)
    ws.Range("A1:G1").Value = Array("No", "�J�e�S��", "�V�[�g��", "�Ώ�", "�l1", "����", "�����Ή�")
    ws.Range("A1:G1").Font.Bold = True
End Sub

Private Sub DxaWriteHeavySummary(ByVal ws As Worksheet, ByRef rowNo As Long, ByVal itemName As String, ByVal statusText As String, ByVal valueText As String, ByVal recommendation As String)
    ws.Cells(rowNo, 1).Value = itemName
    ws.Cells(rowNo, 2).Value = statusText
    ws.Cells(rowNo, 3).Value = valueText
    ws.Cells(rowNo, 4).Value = recommendation
    DxaApplyStatusColor ws.Cells(rowNo, 2), statusText
    rowNo = rowNo + 1
End Sub

Private Sub DxaWriteHeavyDetail(ByVal ws As Worksheet, ByRef rowNo As Long, ByVal category As String, ByVal sheetName As String, ByVal targetName As String, ByVal valueText As String, ByVal statusText As String, ByVal recommendation As String)
    ws.Cells(rowNo, 1).Value = rowNo - 1
    ws.Cells(rowNo, 2).Value = category
    ws.Cells(rowNo, 3).Value = sheetName
    ws.Cells(rowNo, 4).Value = targetName
    ws.Cells(rowNo, 5).Value = valueText
    ws.Cells(rowNo, 6).Value = statusText
    ws.Cells(rowNo, 7).Value = recommendation
    DxaApplyStatusColor ws.Cells(rowNo, 6), statusText
    rowNo = rowNo + 1
End Sub

Private Sub DxaApplyStatusColor(ByVal cell As Range, ByVal statusText As String)
    On Error Resume Next
    Select Case statusText
        Case "�x��"
            cell.Interior.Color = RGB(255, 199, 206)
            cell.Font.Color = RGB(156, 0, 6)
        Case "����"
            cell.Interior.Color = RGB(255, 235, 156)
            cell.Font.Color = RGB(156, 101, 0)
        Case "OK"
            cell.Interior.Color = RGB(198, 239, 206)
            cell.Font.Color = RGB(0, 97, 0)
        Case Else
            cell.Interior.Color = RGB(217, 225, 242)
    End Select
End Sub

Private Function DxaStatusByNumber(ByVal value As Double, ByVal cautionThreshold As Double, ByVal warningThreshold As Double) As String
    If value >= warningThreshold Then
        DxaStatusByNumber = "�x��"
    ElseIf value >= cautionThreshold Then
        DxaStatusByNumber = "����"
    Else
        DxaStatusByNumber = "OK"
    End If
End Function

Private Function DxaStatusByFileSize(ByVal mb As Double) As String
    If mb < 0 Then
        DxaStatusByFileSize = "���"
    ElseIf mb >= 50 Then
        DxaStatusByFileSize = "�x��"
    ElseIf mb >= 10 Then
        DxaStatusByFileSize = "����"
    Else
        DxaStatusByFileSize = "OK"
    End If
End Function

Private Function DxaStatusBySheetVisible(ByVal ws As Worksheet) As String
    If ws.Visible = xlSheetVisible Then
        DxaStatusBySheetVisible = "OK"
    Else
        DxaStatusBySheetVisible = "����"
    End If
End Function

Private Function DxaSheetVisibleText(ByVal ws As Worksheet) As String
    Select Case ws.Visible
        Case xlSheetVisible
            DxaSheetVisibleText = "�\��"
        Case xlSheetHidden
            DxaSheetVisibleText = "��\��"
        Case xlSheetVeryHidden
            DxaSheetVisibleText = "VeryHidden"
        Case Else
            DxaSheetVisibleText = CStr(ws.Visible)
    End Select
End Function

Private Function DxaGetActualLastCell(ByVal ws As Worksheet, ByRef lastRow As Long, ByRef lastCol As Long) As Boolean
    On Error GoTo EH
    Dim c As Range
    Set c = ws.Cells.Find(What:="*", After:=ws.Range("A1"), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, MatchCase:=False)
    If c Is Nothing Then
        lastRow = 0
        lastCol = 0
        DxaGetActualLastCell = False
        Exit Function
    End If
    lastRow = c.Row
    Set c = ws.Cells.Find(What:="*", After:=ws.Range("A1"), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious, MatchCase:=False)
    lastCol = c.Column
    DxaGetActualLastCell = True
    Exit Function
EH:
    lastRow = 0
    lastCol = 0
    DxaGetActualLastCell = False
End Function

Private Function DxaCountSpecialCells(ByVal ws As Worksheet, ByVal cellType As Long) As Double
    On Error GoTo EH
    Dim rng As Range
    Set rng = ws.UsedRange.SpecialCells(cellType)
    DxaCountSpecialCells = CDbl(rng.CountLarge)
    Exit Function
EH:
    DxaCountSpecialCells = 0
End Function

Private Function DxaCountFormatConditions(ByVal ws As Worksheet) As Double
    On Error GoTo EH
    DxaCountFormatConditions = CDbl(ws.Cells.FormatConditions.Count)
    Exit Function
EH:
    DxaCountFormatConditions = 0
End Function

Private Function DxaSafeShapeCount(ByVal ws As Worksheet) As Double
    On Error Resume Next
    DxaSafeShapeCount = CDbl(ws.Shapes.Count)
End Function

Private Function DxaSafePictureCount(ByVal ws As Worksheet) As Double
    On Error GoTo EH
    Dim shp As Shape
    Dim n As Double
    For Each shp In ws.Shapes
        If shp.Type = msoPicture Or shp.Type = msoLinkedPicture Then n = n + 1
    Next shp
    DxaSafePictureCount = n
    Exit Function
EH:
    DxaSafePictureCount = 0
End Function

Private Function DxaSafeHyperlinkCount(ByVal ws As Worksheet) As Double
    On Error Resume Next
    DxaSafeHyperlinkCount = CDbl(ws.Hyperlinks.Count)
End Function

Private Function DxaSafeCommentCount(ByVal ws As Worksheet) As Double
    On Error Resume Next
    Dim n As Double
    n = 0
    n = n + CDbl(ws.Comments.Count)
    Err.Clear
    n = n + CDbl(ws.CommentsThreaded.Count)
    DxaSafeCommentCount = n
End Function

Private Function DxaSafePivotCount(ByVal ws As Worksheet) As Double
    On Error Resume Next
    DxaSafePivotCount = CDbl(ws.PivotTables.Count)
End Function

Private Function DxaSafeTableCount(ByVal ws As Worksheet) As Double
    On Error Resume Next
    DxaSafeTableCount = CDbl(ws.ListObjects.Count)
End Function

Private Function DxaSafeStyleCount(ByVal wb As Workbook) As Double
    On Error Resume Next
    DxaSafeStyleCount = CDbl(wb.Styles.Count)
End Function

Private Function DxaWorkbookFileSizeMB(ByVal wb As Workbook) As Double
    On Error GoTo EH
    If Len(wb.FullName) = 0 Then
        DxaWorkbookFileSizeMB = -1
    ElseIf Len(Dir$(wb.FullName)) = 0 Then
        DxaWorkbookFileSizeMB = -1
    Else
        DxaWorkbookFileSizeMB = CDbl(FileLen(wb.FullName)) / 1024# / 1024#
    End If
    Exit Function
EH:
    DxaWorkbookFileSizeMB = -1
End Function

Private Function DxaCountExternalLinks(ByVal wb As Workbook) As Double
    On Error GoTo EH
    Dim links As Variant
    links = wb.LinkSources(Type:=xlLinkTypeExcelLinks)
    If IsEmpty(links) Then
        DxaCountExternalLinks = 0
    Else
        DxaCountExternalLinks = CDbl(UBound(links) - LBound(links) + 1)
    End If
    Exit Function
EH:
    DxaCountExternalLinks = 0
End Function

Private Sub DxaCountNames(ByVal wb As Workbook, ByRef nameCount As Double, ByRef brokenNameCount As Double, ByRef externalNameCount As Double)
    On Error Resume Next
    Dim nm As Name
    Dim refText As String
    nameCount = 0
    brokenNameCount = 0
    externalNameCount = 0
    For Each nm In wb.Names
        nameCount = nameCount + 1
        Err.Clear
        refText = nm.RefersTo
        If InStr(1, refText, "#REF!", vbTextCompare) > 0 Then brokenNameCount = brokenNameCount + 1
        If InStr(1, refText, "[", vbTextCompare) > 0 And InStr(1, refText, "]", vbTextCompare) > 0 Then externalNameCount = externalNameCount + 1
    Next nm
End Sub

Private Function DxaCountVolatileFormulas(ByVal ws As Worksheet) As Double
    On Error GoTo EH
    Dim rng As Range
    Set rng = ws.UsedRange.SpecialCells(xlCellTypeFormulas)
    If rng Is Nothing Then
        DxaCountVolatileFormulas = 0
        Exit Function
    End If

    Dim volatileWords As Variant
    volatileWords = Array("NOW(", "TODAY(", "RAND(", "RANDBETWEEN(", "OFFSET(", "INDIRECT(", "CELL(", "INFO(")

    Dim total As Double
    Dim word As Variant
    For Each word In volatileWords
        total = total + DxaCountFormulaFindHits(rng, CStr(word))
    Next word
    DxaCountVolatileFormulas = total
    Exit Function
EH:
    DxaCountVolatileFormulas = 0
End Function

Private Function DxaCountFormulaFindHits(ByVal rng As Range, ByVal token As String) As Double
    On Error GoTo EH
    Dim firstAddress As String
    Dim c As Range
    Dim n As Double
    Set c = rng.Find(What:=token, After:=rng.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlNext, MatchCase:=False)
    If c Is Nothing Then
        DxaCountFormulaFindHits = 0
        Exit Function
    End If
    firstAddress = c.Address(External:=True)
    Do
        n = n + 1
        Set c = rng.FindNext(c)
        If c Is Nothing Then Exit Do
    Loop While c.Address(External:=True) <> firstAddress
    DxaCountFormulaFindHits = n
    Exit Function
EH:
    DxaCountFormulaFindHits = 0
End Function

'============================================================
' Backlog�K���g�`���[�g�x���@�\ v107
' Backlog����G�N�X�|�[�g�����K���g�`���[�g�����₷�����`���܂��B
' �z��`���FA�`L�񂪉ۑ���AM��ȍ~�����t�K���g
'============================================================
Public Sub DxaBacklogFormatGantt(ByVal control As Object)
    On Error GoTo EH

    Dim ws As Worksheet
    Set ws = ActiveSheet
    If ws Is Nothing Then Exit Sub

    Dim headerRow As Long, dataFirstRow As Long, lastRow As Long, lastCol As Long, dateStartCol As Long
    If Not DxaBacklogDetectLayout(ws, headerRow, dataFirstRow, lastRow, lastCol, dateStartCol) Then Exit Sub

    Application.ScreenUpdating = False
    Application.StatusBar = "DExcelAssist: Backlog�K���g�𐮌`���Ă��܂�..."

    DxaBacklogFormatIssueColumns ws, headerRow, dataFirstRow, lastRow, lastCol, dateStartCol
    DxaBacklogFormatDateColumns ws, headerRow, dataFirstRow, lastRow, lastCol, dateStartCol
    DxaBacklogHighlightRows ws, dataFirstRow, lastRow, lastCol
    DxaBacklogFreezeGantt ws, dataFirstRow, dateStartCol

    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "Backlog�K���g���`���������܂����B", vbInformation, "DExcelAssist"
    Exit Sub
EH:
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "Backlog�K���g���`�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DExcelAssist"
End Sub

Public Sub DxaBacklogCreateGanttSummary(ByVal control As Object)
    On Error GoTo EH

    Dim ws As Worksheet
    Set ws = ActiveSheet
    If ws Is Nothing Then Exit Sub

    Dim headerRow As Long, dataFirstRow As Long, lastRow As Long, lastCol As Long, dateStartCol As Long
    If Not DxaBacklogDetectLayout(ws, headerRow, dataFirstRow, lastRow, lastCol, dateStartCol) Then Exit Sub

    Application.ScreenUpdating = False
    Application.StatusBar = "DExcelAssist: Backlog�K���g�T�}���[���쐬���Ă��܂�..."

    Dim outWs As Worksheet
    Set outWs = DxaBacklogRecreateSheet(ws.Parent, "Backlog�K���g�T�}���[")
    DxaBacklogWriteSummary ws, outWs, dataFirstRow, lastRow

    outWs.Activate
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "Backlog�K���g�T�}���[���쐬���܂����B", vbInformation, "DExcelAssist"
    Exit Sub
EH:
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "Backlog�K���g�T�}���[�쐬�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DExcelAssist"
End Sub

Public Sub DxaBacklogCreateDelayList(ByVal control As Object)
    On Error GoTo EH

    Dim ws As Worksheet
    Set ws = ActiveSheet
    If ws Is Nothing Then Exit Sub

    Dim headerRow As Long, dataFirstRow As Long, lastRow As Long, lastCol As Long, dateStartCol As Long
    If Not DxaBacklogDetectLayout(ws, headerRow, dataFirstRow, lastRow, lastCol, dateStartCol) Then Exit Sub

    Application.ScreenUpdating = False
    Application.StatusBar = "DExcelAssist: Backlog�x���ꗗ���쐬���Ă��܂�..."

    Dim outWs As Worksheet
    Set outWs = DxaBacklogRecreateSheet(ws.Parent, "Backlog�x���ꗗ")
    DxaBacklogWriteDelayList ws, outWs, dataFirstRow, lastRow

    outWs.Activate
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "Backlog�x���ꗗ���쐬���܂����B", vbInformation, "DExcelAssist"
    Exit Sub
EH:
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "Backlog�x���ꗗ�쐬�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DExcelAssist"
End Sub

Public Sub DxaBacklogCreateMeetingView(ByVal control As Object)
    On Error GoTo EH

    Dim ws As Worksheet
    Set ws = ActiveSheet
    If ws Is Nothing Then Exit Sub

    Dim headerRow As Long, dataFirstRow As Long, lastRow As Long, lastCol As Long, dateStartCol As Long
    If Not DxaBacklogDetectLayout(ws, headerRow, dataFirstRow, lastRow, lastCol, dateStartCol) Then Exit Sub

    Application.ScreenUpdating = False
    Application.StatusBar = "DExcelAssist: Backlog��c�p�r���[���쐬���Ă��܂�..."

    Dim outWs As Worksheet
    Set outWs = DxaBacklogRecreateSheet(ws.Parent, "Backlog��c�p")
    DxaBacklogWriteMeetingView ws, outWs, dataFirstRow, lastRow

    outWs.Activate
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "Backlog��c�p�r���[���쐬���܂����B", vbInformation, "DExcelAssist"
    Exit Sub
EH:
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "Backlog��c�p�r���[�쐬�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DExcelAssist"
End Sub

Public Sub DxaBacklogCreateAssigneeLoad(ByVal control As Object)
    On Error GoTo EH

    Dim ws As Worksheet
    Set ws = ActiveSheet
    If ws Is Nothing Then Exit Sub

    Dim headerRow As Long, dataFirstRow As Long, lastRow As Long, lastCol As Long, dateStartCol As Long
    If Not DxaBacklogDetectLayout(ws, headerRow, dataFirstRow, lastRow, lastCol, dateStartCol) Then Exit Sub

    Application.ScreenUpdating = False
    Application.StatusBar = "DExcelAssist: Backlog�S���ҕʕ��ׂ��쐬���Ă��܂�..."

    Dim outWs As Worksheet
    Set outWs = DxaBacklogRecreateSheet(ws.Parent, "Backlog�S���ҕʕ���")
    DxaBacklogWriteAssigneeLoad ws, outWs, dataFirstRow, lastRow

    outWs.Activate
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "Backlog�S���ҕʕ��ׂ��쐬���܂����B", vbInformation, "DExcelAssist"
    Exit Sub
EH:
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "Backlog�S���ҕʕ��׍쐬�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DExcelAssist"
End Sub

Private Function DxaBacklogDetectLayout(ByVal ws As Worksheet, ByRef headerRow As Long, ByRef dataFirstRow As Long, ByRef lastRow As Long, ByRef lastCol As Long, ByRef dateStartCol As Long) As Boolean
    Dim r As Long
    headerRow = 0
    For r = 1 To 20
        If InStr(1, CStr(ws.Cells(r, 1).Value), "�L�[", vbTextCompare) > 0 And _
           InStr(1, CStr(ws.Cells(r, 3).Value), "����", vbTextCompare) > 0 Then
            headerRow = r
            Exit For
        End If
    Next

    If headerRow = 0 Then headerRow = 4
    dataFirstRow = headerRow + 1
    dateStartCol = 13

    lastRow = DxaBacklogLastUsedRow(ws)
    lastCol = DxaBacklogLastUsedCol(ws)
    If lastRow < dataFirstRow Or lastCol < 12 Then
        MsgBox "Backlog�K���g�o�͌`���𔻒�ł��܂���ł����BA�`L��ɉۑ��񂪂���V�[�g���A�N�e�B�u�ɂ��Ď��s���Ă��������B", vbExclamation, "DExcelAssist"
        Exit Function
    End If

    If lastCol < dateStartCol Then lastCol = dateStartCol
    DxaBacklogDetectLayout = True
End Function

Private Function DxaBacklogLastUsedRow(ByVal ws As Worksheet) As Long
    Dim c As Range
    On Error Resume Next
    Set c = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, MatchCase:=False)
    On Error GoTo 0
    If c Is Nothing Then DxaBacklogLastUsedRow = 1 Else DxaBacklogLastUsedRow = c.Row
End Function

Private Function DxaBacklogLastUsedCol(ByVal ws As Worksheet) As Long
    Dim c As Range
    On Error Resume Next
    Set c = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious, MatchCase:=False)
    On Error GoTo 0
    If c Is Nothing Then DxaBacklogLastUsedCol = 1 Else DxaBacklogLastUsedCol = c.Column
End Function

Private Sub DxaBacklogFormatIssueColumns(ByVal ws As Worksheet, ByVal headerRow As Long, ByVal dataFirstRow As Long, ByVal lastRow As Long, ByVal lastCol As Long, ByVal dateStartCol As Long)
    With ws
        .Rows(headerRow).Font.Bold = True
        .Rows(headerRow).Interior.Color = RGB(217, 225, 242)
        .Range(.Cells(headerRow, 1), .Cells(headerRow, lastCol)).AutoFilter
        .Columns("A:A").ColumnWidth = 14
        .Columns("B:B").ColumnWidth = 9
        .Columns("C:C").ColumnWidth = 55
        .Columns("C:C").WrapText = True
        .Columns("D:F").ColumnWidth = 12
        .Columns("G:G").ColumnWidth = 14
        .Columns("H:I").ColumnWidth = 12
        .Columns("H:I").NumberFormatLocal = "yyyy/mm/dd"
        .Columns("J:K").ColumnWidth = 10
        .Columns("L:L").ColumnWidth = 10
        .Rows(dataFirstRow & ":" & lastRow).RowHeight = 24
        .Range(.Cells(headerRow, 1), .Cells(lastRow, 12)).Borders.LineStyle = xlContinuous
    End With
End Sub

Private Sub DxaBacklogFormatDateColumns(ByVal ws As Worksheet, ByVal headerRow As Long, ByVal dataFirstRow As Long, ByVal lastRow As Long, ByVal lastCol As Long, ByVal dateStartCol As Long)
    Dim c As Long
    For c = dateStartCol To lastCol
        ws.Columns(c).ColumnWidth = 3.5
        Dim d As Date
        If DxaBacklogColumnDate(ws, c, headerRow, d) Then
            If Weekday(d, vbMonday) >= 6 Then
                ws.Range(ws.Cells(1, c), ws.Cells(lastRow, c)).Interior.Color = RGB(242, 242, 242)
            End If
            If DateValue(d) = Date Then
                ws.Range(ws.Cells(1, c), ws.Cells(lastRow, c)).Interior.Color = RGB(255, 242, 204)
                ws.Range(ws.Cells(1, c), ws.Cells(lastRow, c)).Borders(xlEdgeLeft).Weight = xlThick
                ws.Range(ws.Cells(1, c), ws.Cells(lastRow, c)).Borders(xlEdgeRight).Weight = xlThick
            End If
            If Day(d) = 1 Then
                ws.Range(ws.Cells(1, c), ws.Cells(lastRow, c)).Borders(xlEdgeLeft).Weight = xlMedium
            End If
        End If
    Next
    ws.Range(ws.Cells(1, dateStartCol), ws.Cells(headerRow, lastCol)).HorizontalAlignment = xlCenter
End Sub

Private Function DxaBacklogColumnDate(ByVal ws As Worksheet, ByVal colNo As Long, ByVal headerRow As Long, ByRef d As Date) As Boolean
    Dim r As Long
    For r = 1 To headerRow
        If IsDate(ws.Cells(r, colNo).Value) Then
            d = CDate(ws.Cells(r, colNo).Value)
            DxaBacklogColumnDate = True
            Exit Function
        End If
    Next
End Function

Private Sub DxaBacklogHighlightRows(ByVal ws As Worksheet, ByVal dataFirstRow As Long, ByVal lastRow As Long, ByVal lastCol As Long)
    Dim r As Long
    For r = dataFirstRow To lastRow
        If Len(Trim$(CStr(ws.Cells(r, 1).Value))) = 0 And Len(Trim$(CStr(ws.Cells(r, 3).Value))) = 0 Then GoTo ContinueRow

        Dim statusText As String
        statusText = CStr(ws.Cells(r, 12).Value)

        If DxaBacklogIsCompleted(statusText) Then
            ws.Range(ws.Cells(r, 1), ws.Cells(r, 12)).Interior.Color = RGB(217, 217, 217)
        ElseIf DxaBacklogIsOverdue(ws.Cells(r, 9).Value, statusText) Then
            ws.Range(ws.Cells(r, 1), ws.Cells(r, 12)).Interior.Color = RGB(255, 199, 206)
        ElseIf DxaBacklogIsDueWithin(ws.Cells(r, 9).Value, statusText, 3) Then
            ws.Range(ws.Cells(r, 1), ws.Cells(r, 12)).Interior.Color = RGB(244, 176, 132)
        ElseIf DxaBacklogIsDueWithin(ws.Cells(r, 9).Value, statusText, 7) Then
            ws.Range(ws.Cells(r, 1), ws.Cells(r, 12)).Interior.Color = RGB(255, 242, 204)
        End If

        If Len(Trim$(CStr(ws.Cells(r, 7).Value))) = 0 Then
            ws.Cells(r, 7).Interior.Color = RGB(255, 199, 206)
        End If
        If Not IsDate(ws.Cells(r, 8).Value) Then
            ws.Cells(r, 8).Interior.Color = RGB(255, 199, 206)
        End If
        If Not IsDate(ws.Cells(r, 9).Value) Then
            ws.Cells(r, 9).Interior.Color = RGB(255, 199, 206)
        ElseIf IsDate(ws.Cells(r, 8).Value) Then
            If CDate(ws.Cells(r, 9).Value) < CDate(ws.Cells(r, 8).Value) Then
                ws.Cells(r, 9).Interior.Color = RGB(255, 0, 0)
                ws.Cells(r, 9).Font.Color = RGB(255, 255, 255)
            End If
        End If
ContinueRow:
    Next
End Sub

Private Sub DxaBacklogFreezeGantt(ByVal ws As Worksheet, ByVal dataFirstRow As Long, ByVal dateStartCol As Long)
    On Error Resume Next
    ws.Activate
    ActiveWindow.FreezePanes = False
    ws.Cells(dataFirstRow, dateStartCol).Select
    ActiveWindow.FreezePanes = True
    On Error GoTo 0
End Sub

Private Function DxaBacklogIsCompleted(ByVal statusText As String) As Boolean
    Dim s As String
    s = Trim$(statusText)
    DxaBacklogIsCompleted = (InStr(1, s, "����", vbTextCompare) > 0 Or InStr(1, s, "�I��", vbTextCompare) > 0 Or InStr(1, s, "Closed", vbTextCompare) > 0)
End Function

Private Function DxaBacklogIsOverdue(ByVal dueValue As Variant, ByVal statusText As String) As Boolean
    If DxaBacklogIsCompleted(statusText) Then Exit Function
    If Not IsDate(dueValue) Then Exit Function
    DxaBacklogIsOverdue = (DateValue(CDate(dueValue)) < Date)
End Function

Private Function DxaBacklogIsDueWithin(ByVal dueValue As Variant, ByVal statusText As String, ByVal days As Long) As Boolean
    If DxaBacklogIsCompleted(statusText) Then Exit Function
    If Not IsDate(dueValue) Then Exit Function
    Dim d As Date
    d = DateValue(CDate(dueValue))
    DxaBacklogIsDueWithin = (d >= Date And d <= DateAdd("d", days, Date))
End Function

Private Function DxaBacklogDueStatus(ByVal dueValue As Variant, ByVal statusText As String) As String
    If DxaBacklogIsCompleted(statusText) Then
        DxaBacklogDueStatus = "����"
    ElseIf Not IsDate(dueValue) Then
        DxaBacklogDueStatus = "���������ݒ�"
    ElseIf DateValue(CDate(dueValue)) < Date Then
        DxaBacklogDueStatus = "��������"
    ElseIf DateValue(CDate(dueValue)) <= DateAdd("d", 3, Date) Then
        DxaBacklogDueStatus = "����3���ȓ�"
    ElseIf DateValue(CDate(dueValue)) <= DateAdd("d", 7, Date) Then
        DxaBacklogDueStatus = "����7���ȓ�"
    Else
        DxaBacklogDueStatus = "�ʏ�"
    End If
End Function

Private Function DxaBacklogOverdueDays(ByVal dueValue As Variant, ByVal statusText As String) As Long
    If Not DxaBacklogIsOverdue(dueValue, statusText) Then Exit Function
    DxaBacklogOverdueDays = DateDiff("d", DateValue(CDate(dueValue)), Date)
End Function

Private Function DxaBacklogAssignee(ByVal ws As Worksheet, ByVal rowNo As Long) As String
    DxaBacklogAssignee = Trim$(CStr(ws.Cells(rowNo, 7).Value))
    If Len(DxaBacklogAssignee) = 0 Then DxaBacklogAssignee = "���S��"
End Function

Private Function DxaBacklogRecreateSheet(ByVal wb As Workbook, ByVal sheetName As String) As Worksheet
    Application.DisplayAlerts = False
    On Error Resume Next
    wb.Worksheets(sheetName).Delete
    On Error GoTo 0
    Application.DisplayAlerts = True

    Dim ws As Worksheet
    Set ws = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))
    ws.Name = sheetName
    Set DxaBacklogRecreateSheet = ws
End Function

Private Sub DxaBacklogWriteSummary(ByVal srcWs As Worksheet, ByVal outWs As Worksheet, ByVal dataFirstRow As Long, ByVal lastRow As Long)
    Dim total As Long, completed As Long, processing As Long, notStarted As Long, overdue As Long, due3 As Long, due7 As Long
    Dim noAssignee As Long, noStart As Long, noDue As Long, invalidDue As Long
    Dim statusCounts As Object
    Set statusCounts = CreateObject("Scripting.Dictionary")

    Dim r As Long
    For r = dataFirstRow To lastRow
        If Len(Trim$(CStr(srcWs.Cells(r, 1).Value))) = 0 And Len(Trim$(CStr(srcWs.Cells(r, 3).Value))) = 0 Then GoTo ContinueRow
        total = total + 1
        Dim st As String
        st = Trim$(CStr(srcWs.Cells(r, 12).Value))
        If Len(st) = 0 Then st = "��Ԗ��ݒ�"
        If statusCounts.Exists(st) Then statusCounts(st) = CLng(statusCounts(st)) + 1 Else statusCounts.Add st, 1
        If DxaBacklogIsCompleted(st) Then completed = completed + 1
        If InStr(1, st, "������", vbTextCompare) > 0 Then processing = processing + 1
        If InStr(1, st, "���Ή�", vbTextCompare) > 0 Then notStarted = notStarted + 1
        If DxaBacklogIsOverdue(srcWs.Cells(r, 9).Value, st) Then overdue = overdue + 1
        If DxaBacklogIsDueWithin(srcWs.Cells(r, 9).Value, st, 3) Then due3 = due3 + 1
        If DxaBacklogIsDueWithin(srcWs.Cells(r, 9).Value, st, 7) Then due7 = due7 + 1
        If Len(Trim$(CStr(srcWs.Cells(r, 7).Value))) = 0 Then noAssignee = noAssignee + 1
        If Not IsDate(srcWs.Cells(r, 8).Value) Then noStart = noStart + 1
        If Not IsDate(srcWs.Cells(r, 9).Value) Then noDue = noDue + 1
        If IsDate(srcWs.Cells(r, 8).Value) And IsDate(srcWs.Cells(r, 9).Value) Then
            If CDate(srcWs.Cells(r, 9).Value) < CDate(srcWs.Cells(r, 8).Value) Then invalidDue = invalidDue + 1
        End If
ContinueRow:
    Next

    outWs.Range("A1:B1").Value = Array("����", "����")
    outWs.Range("A1:B1").Font.Bold = True
    outWs.Cells(2, 1).Value = "�S�ۑ萔": outWs.Cells(2, 2).Value = total
    outWs.Cells(3, 1).Value = "����": outWs.Cells(3, 2).Value = completed
    outWs.Cells(4, 1).Value = "������": outWs.Cells(4, 2).Value = processing
    outWs.Cells(5, 1).Value = "���Ή�": outWs.Cells(5, 2).Value = notStarted
    outWs.Cells(6, 1).Value = "��������": outWs.Cells(6, 2).Value = overdue
    outWs.Cells(7, 1).Value = "����3���ȓ�": outWs.Cells(7, 2).Value = due3
    outWs.Cells(8, 1).Value = "����7���ȓ�": outWs.Cells(8, 2).Value = due7
    outWs.Cells(9, 1).Value = "�S���Җ��ݒ�": outWs.Cells(9, 2).Value = noAssignee
    outWs.Cells(10, 1).Value = "�J�n�����ݒ�": outWs.Cells(10, 2).Value = noStart
    outWs.Cells(11, 1).Value = "���������ݒ�": outWs.Cells(11, 2).Value = noDue
    outWs.Cells(12, 1).Value = "���������J�n�����O": outWs.Cells(12, 2).Value = invalidDue

    outWs.Range("D1:E1").Value = Array("���", "����")
    outWs.Range("D1:E1").Font.Bold = True
    Dim rowOut As Long
    rowOut = 2
    Dim k As Variant
    For Each k In statusCounts.Keys
        outWs.Cells(rowOut, 4).Value = CStr(k)
        outWs.Cells(rowOut, 5).Value = CLng(statusCounts(k))
        rowOut = rowOut + 1
    Next

    outWs.Columns("A:E").AutoFit
    outWs.Range("A1:E1").Interior.Color = RGB(217, 225, 242)
End Sub

Private Sub DxaBacklogWriteDelayList(ByVal srcWs As Worksheet, ByVal outWs As Worksheet, ByVal dataFirstRow As Long, ByVal lastRow As Long)
    outWs.Range("A1:I1").Value = Array("No", "�ۑ�L�[", "����", "�S����", "���", "�J�n��", "������", "���ߓ���", "�m�F")
    outWs.Range("A1:I1").Font.Bold = True
    outWs.Range("A1:I1").Interior.Color = RGB(217, 225, 242)

    Dim rowOut As Long
    rowOut = 2
    Dim r As Long
    For r = dataFirstRow To lastRow
        Dim st As String
        st = CStr(srcWs.Cells(r, 12).Value)
        If DxaBacklogIsOverdue(srcWs.Cells(r, 9).Value, st) Then
            outWs.Cells(rowOut, 1).Value = rowOut - 1
            outWs.Cells(rowOut, 2).Value = srcWs.Cells(r, 1).Value
            outWs.Cells(rowOut, 3).Value = srcWs.Cells(r, 3).Value
            outWs.Cells(rowOut, 4).Value = DxaBacklogAssignee(srcWs, r)
            outWs.Cells(rowOut, 5).Value = st
            outWs.Cells(rowOut, 6).Value = srcWs.Cells(r, 8).Value
            outWs.Cells(rowOut, 7).Value = srcWs.Cells(r, 9).Value
            outWs.Cells(rowOut, 8).Value = DxaBacklogOverdueDays(srcWs.Cells(r, 9).Value, st)
            outWs.Cells(rowOut, 9).Value = "���s�ֈړ�"
            On Error Resume Next
            outWs.Hyperlinks.Add Anchor:=outWs.Cells(rowOut, 9), Address:="", SubAddress:="'" & srcWs.Name & "'!A" & r, TextToDisplay:="���s�ֈړ�"
            On Error GoTo 0
            rowOut = rowOut + 1
        End If
    Next

    If rowOut = 2 Then outWs.Cells(2, 1).Value = "�������߉ۑ�͂���܂���B"
    outWs.Columns("A:I").AutoFit
    outWs.Range("A1:I1").AutoFilter
End Sub

Private Sub DxaBacklogWriteMeetingView(ByVal srcWs As Worksheet, ByVal outWs As Worksheet, ByVal dataFirstRow As Long, ByVal lastRow As Long)
    outWs.Range("A1:J1").Value = Array("No", "�ۑ�L�[", "����", "�S����", "���", "�J�n��", "������", "�x����", "�\�莞��", "���ю���")
    outWs.Range("A1:J1").Font.Bold = True
    outWs.Range("A1:J1").Interior.Color = RGB(217, 225, 242)

    Dim rowOut As Long
    rowOut = 2
    Dim r As Long
    For r = dataFirstRow To lastRow
        If Len(Trim$(CStr(srcWs.Cells(r, 1).Value))) = 0 And Len(Trim$(CStr(srcWs.Cells(r, 3).Value))) = 0 Then GoTo ContinueRow
        Dim st As String
        st = CStr(srcWs.Cells(r, 12).Value)
        If DxaBacklogIsCompleted(st) Then GoTo ContinueRow

        outWs.Cells(rowOut, 1).Value = rowOut - 1
        outWs.Cells(rowOut, 2).Value = srcWs.Cells(r, 1).Value
        outWs.Cells(rowOut, 3).Value = srcWs.Cells(r, 3).Value
        outWs.Cells(rowOut, 4).Value = DxaBacklogAssignee(srcWs, r)
        outWs.Cells(rowOut, 5).Value = st
        outWs.Cells(rowOut, 6).Value = srcWs.Cells(r, 8).Value
        outWs.Cells(rowOut, 7).Value = srcWs.Cells(r, 9).Value
        outWs.Cells(rowOut, 8).Value = DxaBacklogDueStatus(srcWs.Cells(r, 9).Value, st)
        outWs.Cells(rowOut, 9).Value = srcWs.Cells(r, 10).Value
        outWs.Cells(rowOut, 10).Value = srcWs.Cells(r, 11).Value
        On Error Resume Next
        outWs.Hyperlinks.Add Anchor:=outWs.Cells(rowOut, 2), Address:="", SubAddress:="'" & srcWs.Name & "'!A" & r, TextToDisplay:=CStr(srcWs.Cells(r, 1).Value)
        On Error GoTo 0
        rowOut = rowOut + 1
ContinueRow:
    Next

    If rowOut = 2 Then outWs.Cells(2, 1).Value = "��c�p�ɕ\�����関�����ۑ�͂���܂���B"
    outWs.Columns("A:J").AutoFit
    outWs.Range("A1:J1").AutoFilter
End Sub

Private Sub DxaBacklogWriteAssigneeLoad(ByVal srcWs As Worksheet, ByVal outWs As Worksheet, ByVal dataFirstRow As Long, ByVal lastRow As Long)
    Dim dict As Object
    Set dict = CreateObject("Scripting.Dictionary")

    Dim r As Long
    For r = dataFirstRow To lastRow
        If Len(Trim$(CStr(srcWs.Cells(r, 1).Value))) = 0 And Len(Trim$(CStr(srcWs.Cells(r, 3).Value))) = 0 Then GoTo ContinueRow
        Dim assignee As String
        assignee = DxaBacklogAssignee(srcWs, r)
        If Not dict.Exists(assignee) Then dict.Add assignee, Array(0#, 0#, 0#, 0#, 0#, 0#)

        Dim a As Variant
        a = dict(assignee)
        a(0) = CDbl(a(0)) + 1
        a(1) = CDbl(a(1)) + DxaBacklogToDouble(srcWs.Cells(r, 10).Value)
        a(2) = CDbl(a(2)) + DxaBacklogToDouble(srcWs.Cells(r, 11).Value)
        If Not DxaBacklogIsCompleted(CStr(srcWs.Cells(r, 12).Value)) Then a(3) = CDbl(a(3)) + 1
        If DxaBacklogIsOverdue(srcWs.Cells(r, 9).Value, CStr(srcWs.Cells(r, 12).Value)) Then a(4) = CDbl(a(4)) + 1
        If DxaBacklogIsDueWithin(srcWs.Cells(r, 9).Value, CStr(srcWs.Cells(r, 12).Value), 7) Then a(5) = CDbl(a(5)) + 1
        dict(assignee) = a
ContinueRow:
    Next

    outWs.Range("A1:G1").Value = Array("�S����", "�ۑ萔", "�\�莞��", "���ю���", "������", "��������", "����7���ȓ�")
    outWs.Range("A1:G1").Font.Bold = True
    outWs.Range("A1:G1").Interior.Color = RGB(217, 225, 242)

    Dim rowOut As Long
    rowOut = 2
    Dim k As Variant
    For Each k In dict.Keys
        Dim v As Variant
        v = dict(k)
        outWs.Cells(rowOut, 1).Value = CStr(k)
        outWs.Cells(rowOut, 2).Value = v(0)
        outWs.Cells(rowOut, 3).Value = v(1)
        outWs.Cells(rowOut, 4).Value = v(2)
        outWs.Cells(rowOut, 5).Value = v(3)
        outWs.Cells(rowOut, 6).Value = v(4)
        outWs.Cells(rowOut, 7).Value = v(5)
        rowOut = rowOut + 1
    Next

    outWs.Columns("A:G").AutoFit
    outWs.Range("A1:G1").AutoFilter
End Sub

Private Function DxaBacklogToDouble(ByVal v As Variant) As Double
    On Error GoTo EH
    If IsNumeric(v) Then DxaBacklogToDouble = CDbl(v)
    Exit Function
EH:
    DxaBacklogToDouble = 0
End Function

' ============================================================
' BITS�Αӕ\�擾
' �u���E�U��̋Ζ��\���R�s�[�����e�L�X�g����A���t�E�o�Ύ����E�ދΎ����𒊏o���܂��B
' ���T�C�g�֒��ڃ��O�C��������A�u���E�U�̔F�؏���ǂݎ�����肵�܂���B
' ============================================================
Public Sub DxaImportTimecardNormalWork(ByVal control As Object)
    ' �ʏ�Ζ��F�ދΎ����� 17:30�`18:14 �� 17:30 �Ƃ��Ĉ����A18:15�ȍ~��15���P�ʂŐ؂�̂Ă܂��B
    DxaImportTimecardFromClipboardCore 2, "�ʏ�Ζ�"
End Sub

Public Sub DxaImportTimecardShiftWork(ByVal control As Object)
    ' �V�t�g�Ζ��F�ދΎ����͏��15���P�ʂŐ؂�̂Ă܂��B
    DxaImportTimecardFromClipboardCore 1, "�V�t�g�Ζ�"
End Sub

Public Sub DxaImportTimecardFromClipboard(ByVal control As Object)
    ' �݊��p�F���{�^������Ă΂ꂽ�ꍇ�͒ʏ�Ζ��Ƃ��Ď�荞�݂܂��B
    DxaImportTimecardFromClipboardCore 2, "�ʏ�Ζ�"
End Sub

Private Sub DxaImportTimecardFromClipboardCore(ByVal endRoundMode As Long, ByVal workTypeLabel As String)
    On Error GoTo EH

    Dim clipText As String
    clipText = DxaGetClipboardTextSafe()

    If Len(Trim$(clipText)) = 0 Then
        MsgBox "�N���b�v�{�[�h����Ζ��\�̃e�L�X�g���擾�ł��܂���ł����B" & vbCrLf & _
               "�u���E�U�ŋΖ��\�̕\������I������ Ctrl + C �ŃR�s�[���Ă���Ď��s���Ă��������B", vbExclamation, "DExcelAssist"
        Exit Sub
    End If

    Dim records As Collection
    Set records = DxaParseTimecardRecords(clipText)

    If records Is Nothing Or records.Count = 0 Then
        MsgBox "���t�A�o�Ύ����A�ދΎ��������o�ł��܂���ł����B" & vbCrLf & vbCrLf & _
               "�������R�s�[����Ă��Ȃ��\��������܂��B" & vbCrLf & _
               "�u���E�U�ŋΖ��\�̕\������I������ Ctrl + C �ŃR�s�[���Ă���Ď��s���Ă��������B" & vbCrLf & _
               "�Ώۗ�F01�i���j 08:50 17:51", vbExclamation, "DExcelAssist"
        Exit Sub
    End If

    Dim wb As Workbook
    Set wb = ActiveWorkbook
    If wb Is Nothing Then Set wb = Workbooks.Add

    Application.ScreenUpdating = False
    Application.DisplayAlerts = False

    Dim ws As Worksheet
    On Error Resume Next
    Set ws = wb.Worksheets("�Αӈꗗ")
    On Error GoTo EH
    If Not ws Is Nothing Then ws.Delete

    Set ws = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))
    ws.Name = "�Αӈꗗ"

    Application.DisplayAlerts = True

    ws.Range("A1:E1").Value = Array("���t", "�o�Ύ���", "�ދΎ���", "�擾�o�Ύ���", "�擾�ދΎ���")
    ws.Range("A1:E1").Font.Bold = True
    ws.Range("A1:E1").Interior.Color = RGB(217, 225, 242)
    ws.Columns("A:E").NumberFormatLocal = "@"

    Dim r As Long
    r = 2

    Dim rec As Variant
    Dim rawStart As String
    Dim rawEnd As String
    Dim roundedStart As String
    Dim roundedEnd As String

    For Each rec In records
        rawStart = CStr(rec(1))
        rawEnd = CStr(rec(2))
        roundedStart = DxaRoundTimecardStart(rawStart)
        roundedEnd = DxaRoundTimecardEnd(rawEnd, endRoundMode)

        ws.Cells(r, 1).Value = CStr(rec(0))
        ws.Cells(r, 2).Value = roundedStart
        ws.Cells(r, 3).Value = roundedEnd
        ws.Cells(r, 4).Value = rawStart
        ws.Cells(r, 5).Value = rawEnd
        r = r + 1
    Next

    ws.Columns("A:E").AutoFit
    ws.Range("A1:E1").AutoFilter
    ws.Activate
    ws.Range("A1").Select

CleanExit:
    Application.DisplayAlerts = True
    Application.ScreenUpdating = True
    Exit Sub

EH:
    Application.DisplayAlerts = True
    Application.ScreenUpdating = True
    MsgBox "�Αӕ\�擾�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DExcelAssist"
End Sub

Private Function DxaTimecardEndRoundModeLabel(ByVal mode As Long) As String
    Select Case mode
        Case 1
            DxaTimecardEndRoundModeLabel = "�V�t�g�Ζ��i15���؂�̂āj"
        Case 2
            DxaTimecardEndRoundModeLabel = "�ʏ�Ζ��i17:30�`18:14��17:30�j"
        Case Else
            DxaTimecardEndRoundModeLabel = ""
    End Select
End Function

Private Function DxaRoundTimecardStart(ByVal timeText As String) As String
    Dim totalMinutes As Long
    If Not DxaTimecardTextToMinutes(timeText, totalMinutes) Then
        DxaRoundTimecardStart = timeText
        Exit Function
    End If

    ' �o�Ύ�����15���P�ʂŐ؂�グ��B
    ' �������A����00�̏ꍇ�������̂܂܂ɂ���B
    If totalMinutes Mod 60 = 0 Then
        DxaRoundTimecardStart = DxaMinutesToTimecardText(totalMinutes)
    Else
        DxaRoundTimecardStart = DxaMinutesToTimecardText(((totalMinutes \ 15) + 1) * 15)
    End If
End Function

Private Function DxaRoundTimecardEnd(ByVal timeText As String, ByVal mode As Long) As String
    Dim totalMinutes As Long
    If Not DxaTimecardTextToMinutes(timeText, totalMinutes) Then
        DxaRoundTimecardEnd = timeText
        Exit Function
    End If

    Select Case mode
        Case 2
            ' �v�]�Ή��F17:30�`18:14 �̏ꍇ�� 17:30 �Ƃ��ďo�͂���B
            If totalMinutes >= (17 * 60 + 30) And totalMinutes <= (18 * 60 + 14) Then
                DxaRoundTimecardEnd = "17:30"
            Else
                DxaRoundTimecardEnd = DxaMinutesToTimecardText((totalMinutes \ 15) * 15)
            End If
        Case Else
            ' �ʏ�F15���P�ʂŐ؂�̂Ă�B
            DxaRoundTimecardEnd = DxaMinutesToTimecardText((totalMinutes \ 15) * 15)
    End Select
End Function

Private Function DxaTimecardTextToMinutes(ByVal timeText As String, ByRef totalMinutes As Long) As Boolean
    On Error GoTo EH
    Dim s As String
    s = Trim$(timeText)
    If Len(s) = 0 Then Exit Function

    Dim parts As Variant
    parts = Split(s, ":")
    If UBound(parts) <> 1 Then Exit Function

    Dim h As Long
    Dim m As Long
    h = CLng(parts(0))
    m = CLng(parts(1))

    If h < 0 Or h > 23 Then Exit Function
    If m < 0 Or m > 59 Then Exit Function

    totalMinutes = h * 60 + m
    DxaTimecardTextToMinutes = True
    Exit Function
EH:
    DxaTimecardTextToMinutes = False
End Function

Private Function DxaMinutesToTimecardText(ByVal totalMinutes As Long) As String
    Do While totalMinutes < 0
        totalMinutes = totalMinutes + 24 * 60
    Loop
    totalMinutes = totalMinutes Mod (24 * 60)

    DxaMinutesToTimecardText = Format$(totalMinutes \ 60, "00") & ":" & Format$(totalMinutes Mod 60, "00")
End Function

Private Function DxaGetClipboardTextSafe() As String
    On Error Resume Next

    Dim dataObj As Object
    Set dataObj = CreateObject("MSForms.DataObject")
    If Not dataObj Is Nothing Then
        dataObj.GetFromClipboard
        DxaGetClipboardTextSafe = CStr(dataObj.GetText(1))
        If Len(DxaGetClipboardTextSafe) > 0 Then Exit Function
    End If

    Err.Clear
    Dim html As Object
    Set html = CreateObject("htmlfile")
    If Not html Is Nothing Then
        DxaGetClipboardTextSafe = CStr(html.parentWindow.clipboardData.GetData("Text"))
    End If
End Function

Private Function DxaParseTimecardRecords(ByVal sourceText As String) As Collection
    Dim result As New Collection

    Dim y As Long
    Dim m As Long
    Dim hasYm As Boolean
    hasYm = DxaExtractYearMonth(sourceText, y, m)

    Dim normalized As String
    normalized = Replace(sourceText, vbCrLf, vbLf)
    normalized = Replace(normalized, vbCr, vbLf)

    Dim lines As Variant
    lines = Split(normalized, vbLf)

    Dim reDate As Object
    Set reDate = CreateObject("VBScript.RegExp")
    reDate.Global = False
    reDate.IgnoreCase = True
    reDate.Pattern = "^\s*(\d{1,2})\s*[\(�i]?\s*([���ΐ��؋��y��])?\s*[\)�j]?"

    Dim reTime As Object
    Set reTime = CreateObject("VBScript.RegExp")
    reTime.Global = True
    reTime.IgnoreCase = True
    reTime.Pattern = "\b([0-2]?\d:[0-5]\d)\b"

    Dim i As Long
    For i = LBound(lines) To UBound(lines)
        Dim lineText As String
        lineText = Trim$(CStr(lines(i)))
        If Len(lineText) = 0 Then GoTo ContinueLine

        Dim matches As Object
        Set matches = reDate.Execute(lineText)
        If matches.Count = 0 Then GoTo ContinueLine

        Dim dayNum As Long
        dayNum = CLng(matches(0).SubMatches(0))
        If dayNum < 1 Or dayNum > 31 Then GoTo ContinueLine

        Dim timeMatches As Object
        Set timeMatches = reTime.Execute(lineText)

        Dim startTime As String
        Dim endTime As String
        startTime = ""
        endTime = ""

        If timeMatches.Count >= 1 Then startTime = CStr(timeMatches(0).SubMatches(0))
        If timeMatches.Count >= 2 Then endTime = CStr(timeMatches(1).SubMatches(0))

        Dim dateText As String
        If hasYm Then
            On Error Resume Next
            dateText = Format$(DateSerial(y, m, dayNum), "yyyy/mm/dd") & "�i" & DxaWeekdayJa(DateSerial(y, m, dayNum)) & "�j"
            If Err.Number <> 0 Then
                Err.Clear
                dateText = DxaNormalizeDateText(matches(0).Value)
            End If
            On Error GoTo 0
        Else
            dateText = DxaNormalizeDateText(matches(0).Value)
        End If

        result.Add Array(dateText, startTime, endTime)

ContinueLine:
    Next

    Set DxaParseTimecardRecords = result
End Function

Private Function DxaExtractYearMonth(ByVal text As String, ByRef y As Long, ByRef m As Long) As Boolean
    On Error GoTo EH
    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = False
    re.IgnoreCase = True
    re.Pattern = "(20\d{2}|19\d{2})\s*�N\s*(\d{1,2})\s*��"

    Dim ms As Object
    Set ms = re.Execute(text)
    If ms.Count = 0 Then Exit Function

    y = CLng(ms(0).SubMatches(0))
    m = CLng(ms(0).SubMatches(1))
    If m < 1 Or m > 12 Then Exit Function

    DxaExtractYearMonth = True
    Exit Function
EH:
    DxaExtractYearMonth = False
End Function

Private Function DxaNormalizeDateText(ByVal text As String) As String
    Dim s As String
    s = Trim$(text)
    s = Replace(s, " ", "")
    s = Replace(s, "(", "�i")
    s = Replace(s, ")", "�j")
    DxaNormalizeDateText = s
End Function

Private Function DxaWeekdayJa(ByVal d As Date) As String
    DxaWeekdayJa = Mid$("�����ΐ��؋��y", Weekday(d, vbSunday), 1)
End Function



' DExcelAssist v114
' �A�N�e�B�u�u�b�N�̊O���f�[�^�A�N�G���A�s�{�b�g�e�[�u���A�������X�V���܂��B
Public Sub DxaRefreshWorkbook(ByVal control As Object)
    On Error GoTo EH

    Dim wb As Workbook
    Dim ws As Worksheet
    Dim pt As PivotTable
    Dim qt As QueryTable
    Dim lo As ListObject
    Dim refreshedPivotCount As Long
    Dim refreshedQueryCount As Long

    If Application.Workbooks.Count = 0 Then
        MsgBox "�X�V�Ώۂ̃u�b�N���J����Ă��܂���B", vbExclamation, "DExcelAssist �X�V"
        Exit Sub
    End If

    Set wb = ActiveWorkbook
    If wb Is Nothing Then
        MsgBox "�X�V�Ώۂ̃u�b�N���擾�ł��܂���ł����B", vbExclamation, "DExcelAssist �X�V"
        Exit Sub
    End If

    If StrComp(wb.Name, ThisWorkbook.Name, vbTextCompare) = 0 Then
        MsgBox "DExcelAssist.xlam�ł͂Ȃ��A�X�V�������u�b�N���A�N�e�B�u�ɂ��Ă�����s���Ă��������B", vbExclamation, "DExcelAssist �X�V"
        Exit Sub
    End If

    Application.ScreenUpdating = False
    Application.StatusBar = "DExcelAssist: �u�b�N���X�V���Ă��܂�..."

    On Error Resume Next
    wb.RefreshAll
    Application.CalculateUntilAsyncQueriesDone
    On Error GoTo EH

    For Each ws In wb.Worksheets
        For Each qt In ws.QueryTables
            On Error Resume Next
            qt.Refresh BackgroundQuery:=False
            If Err.Number = 0 Then refreshedQueryCount = refreshedQueryCount + 1
            Err.Clear
            On Error GoTo EH
        Next qt

        For Each lo In ws.ListObjects
            If Not lo.QueryTable Is Nothing Then
                On Error Resume Next
                lo.QueryTable.Refresh BackgroundQuery:=False
                If Err.Number = 0 Then refreshedQueryCount = refreshedQueryCount + 1
                Err.Clear
                On Error GoTo EH
            End If
        Next lo

        For Each pt In ws.PivotTables
            On Error Resume Next
            pt.RefreshTable
            If Err.Number = 0 Then refreshedPivotCount = refreshedPivotCount + 1
            Err.Clear
            On Error GoTo EH
        Next pt
    Next ws

    Application.CalculateFull

    Application.StatusBar = False
    Application.ScreenUpdating = True

    MsgBox "�X�V���������܂����B" & vbCrLf & _
           "�Ώۃu�b�N: " & wb.Name & vbCrLf & _
           "�X�V�����N�G��/�e�[�u��: " & refreshedQueryCount & vbCrLf & _
           "�X�V�����s�{�b�g�e�[�u��: " & refreshedPivotCount, _
           vbInformation, "DExcelAssist �X�V"
    Exit Sub

EH:
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "�X�V���ɃG���[���������܂����B" & vbCrLf & _
           "Err " & Err.Number & ": " & Err.Description, vbExclamation, "DExcelAssist �X�V"
End Sub



' DExcelAssist v115
' GitHub main�u�����`��VERSION.txt���m�F���A���݂��V�����ꍇ�����m�F�_�C�A���O��\�����ăA�b�v�f�[�g���܂��B
Public Sub DxaCheckDExcelAssistUpdate(ByVal control As Object)
    On Error GoTo EH

    Dim currentVersion As String
    Dim latestVersion As String

    currentVersion = DxaNormalizeVersionText(DxaGetCurrentVersionText())
    latestVersion = DxaNormalizeVersionText(DxaGetLatestVersionTextFromGitHub())

    If Len(Trim$(latestVersion)) = 0 Then
        MsgBox "GitHub main�u�����`��VERSION.txt���擾�ł��܂���ł����B" & vbCrLf & _
               "�l�b�g���[�N�ڑ��A�܂���GitHub main�u�����`�̔z�u���m�F���Ă��������B", _
               vbExclamation, "DExcelAssist �A�b�v�f�[�g�m�F"
        Exit Sub
    End If

    If DxaCompareVersionText(currentVersion, latestVersion) >= 0 Then
        MsgBox "DExcelAssist�͍ŐV�ł��B" & vbCrLf & vbCrLf & _
               "���݂̃o�[�W����: " & currentVersion & vbCrLf & _
               "�ŐV�̃o�[�W����: " & latestVersion, _
               vbInformation, "DExcelAssist �A�b�v�f�[�g�m�F"
        Exit Sub
    End If

    Dim answer As VbMsgBoxResult
    answer = MsgBox("�V����DExcelAssist��������܂����B" & vbCrLf & vbCrLf & _
                    "���݂̃o�[�W����: " & currentVersion & vbCrLf & _
                    "�ŐV�̃o�[�W����: " & latestVersion & vbCrLf & vbCrLf & _
                    "�C���X�g�[�����_�E�����[�h���ăA�b�v�f�[�g���܂����H" & vbCrLf & _
                    "�A�b�v�f�[�g����Excel���I�����܂��B", _
                    vbYesNo + vbQuestion, "DExcelAssist �A�b�v�f�[�g�m�F")
    If answer <> vbYes Then Exit Sub

    Dim wb As Workbook
    For Each wb In Application.Workbooks
        If StrComp(wb.Name, ThisWorkbook.Name, vbTextCompare) <> 0 Then
            If wb.Saved = False Then
                MsgBox "�ۑ�����Ă��Ȃ��u�b�N������܂��B" & vbCrLf & _
                       "�A�b�v�f�[�g�ł�Excel���I�����邽�߁A��ɂ��ׂĕۑ����Ă���Ď��s���Ă��������B" & vbCrLf & _
                       "�Ώ�: " & wb.Name, vbExclamation, "DExcelAssist �A�b�v�f�[�g�m�F"
                Exit Sub
            End If
        End If
    Next wb

    Dim tempDir As String
    Dim zipPath As String
    Dim psCmd As String
    Dim sh As Object

    tempDir = Environ$("TEMP") & "\DExcelAssistInstaller_" & Format$(Now, "yyyymmdd_hhnnss")
    zipPath = tempDir & "\DExcelAssistInstaller.zip"

    psCmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command " & _
            DxaQuoteForCommand("$ErrorActionPreference='Stop'; " & _
            "New-Item -ItemType Directory -Force -Path " & DxaPsQuote(tempDir) & " | Out-Null; " & _
            "Invoke-WebRequest -Uri 'https://raw.githubusercontent.com/Chairman-bits/DExcelAssist/main/DExcelAssistInstaller.zip' -OutFile " & DxaPsQuote(zipPath) & " -UseBasicParsing; " & _
            "Expand-Archive -Path " & DxaPsQuote(zipPath) & " -DestinationPath " & DxaPsQuote(tempDir) & " -Force; " & _
            "$bat = Get-ChildItem -Path " & DxaPsQuote(tempDir) & " -Recurse -Filter 'DExcelAssist.bat' | Select-Object -First 1; " & _
            "if($null -eq $bat){ throw 'DExcelAssist.bat ��������܂���B' }; " & _
            "Start-Process -FilePath $bat.FullName -ArgumentList '/install' -WorkingDirectory $bat.DirectoryName")

    Set sh = CreateObject("WScript.Shell")
    sh.Run psCmd, 0, False

    MsgBox "DExcelAssist�̃C���X�g�[�����N�����܂����B" & vbCrLf & _
           "���̂���Excel���I�����܂��B�C���X�g�[���������Excel���ċN�����Ă��������B", _
           vbInformation, "DExcelAssist �A�b�v�f�[�g�m�F"

    Application.DisplayAlerts = False
    Application.Quit
    Exit Sub

EH:
    MsgBox "DExcelAssist�̃A�b�v�f�[�g�m�F���ɃG���[���������܂����B" & vbCrLf & _
           "Err " & Err.Number & ": " & Err.Description, vbExclamation, "DExcelAssist �A�b�v�f�[�g�m�F"
End Sub

' �����{��ID�Ƃ̌݊��p�B���݂̃��{������͌Ăяo���܂���B
Public Sub DxaUpdateDExcelAssist(ByVal control As Object)
    DxaCheckDExcelAssistUpdate control
End Sub

Private Function DxaGetCurrentVersionText() As String
    On Error GoTo Fallback

    Dim sh As Object
    Set sh = CreateObject("WScript.Shell")
    DxaGetCurrentVersionText = Trim$(CStr(sh.RegRead("HKCU\Software\DExcelAssist\LocalVersion")))
    If Len(DxaGetCurrentVersionText) > 0 Then Exit Function

Fallback:
    On Error Resume Next
    Dim installRoot As String
    Dim fso As Object
    Dim ts As Object

    installRoot = DxaReadInstallRoot()
    If Len(installRoot) > 0 Then
        Set fso = CreateObject("Scripting.FileSystemObject")
        If fso.FileExists(installRoot & "\VERSION.txt") Then
            Set ts = fso.OpenTextFile(installRoot & "\VERSION.txt", 1, False)
            DxaGetCurrentVersionText = Trim$(CStr(ts.ReadAll))
            ts.Close
        End If
    End If

    If Len(DxaGetCurrentVersionText) = 0 Then DxaGetCurrentVersionText = "v0.0.0"
End Function

Private Function DxaGetLatestVersionTextFromGitHub() As String
    On Error GoTo EH

    Dim http As Object
    Set http = CreateObject("WinHttp.WinHttpRequest.5.1")
    http.Open "GET", "https://raw.githubusercontent.com/Chairman-bits/DExcelAssist/main/VERSION.txt", False
    http.SetTimeouts 5000, 5000, 10000, 10000
    http.Send

    If CLng(http.Status) <> 200 Then
        DxaGetLatestVersionTextFromGitHub = vbNullString
    Else
        DxaGetLatestVersionTextFromGitHub = Trim$(CStr(http.ResponseText))
    End If
    Exit Function

EH:
    DxaGetLatestVersionTextFromGitHub = vbNullString
End Function

Private Function DxaNormalizeVersionText(ByVal versionText As String) As String
    Dim s As String
    Dim i As Long
    Dim ch As String
    Dim result As String
    Dim started As Boolean

    s = Trim$(CStr(versionText))
    s = Replace(s, ChrW$(&HFEFF), vbNullString)
    s = Replace(s, ChrW$(&HFFFD), vbNullString)
    s = Replace(s, "?", vbNullString)

    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        If Not started Then
            If ch = "v" Or ch = "V" Or (ch >= "0" And ch <= "9") Then
                started = True
            End If
        End If

        If started Then
            If ch = "v" Or ch = "V" Or ch = "." Or ch = "-" Or ch = "_" Or (ch >= "0" And ch <= "9") Then
                result = result & ch
            ElseIf Len(result) > 0 Then
                Exit For
            End If
        End If
    Next i

    result = Trim$(result)
    If Len(result) = 0 Then result = "v0.0.0"
    DxaNormalizeVersionText = result
End Function

Private Function DxaCompareVersionText(ByVal currentVersion As String, ByVal latestVersion As String) As Long
    Dim i As Long
    Dim a As Long
    Dim b As Long

    For i = 0 To 3
        a = DxaGetVersionPart(currentVersion, i)
        b = DxaGetVersionPart(latestVersion, i)
        If a < b Then
            DxaCompareVersionText = -1
            Exit Function
        ElseIf a > b Then
            DxaCompareVersionText = 1
            Exit Function
        End If
    Next i

    DxaCompareVersionText = 0
End Function

Private Function DxaGetVersionPart(ByVal versionText As String, ByVal index As Long) As Long
    Dim s As String
    Dim parts As Variant

    s = LCase$(DxaNormalizeVersionText(versionText))
    If Left$(s, 1) = "v" Then s = Mid$(s, 2)
    s = Replace(s, "_", "-")
    If InStr(1, s, "-", vbTextCompare) > 0 Then s = Left$(s, InStr(1, s, "-", vbTextCompare) - 1)

    parts = Split(s, ".")
    If index <= UBound(parts) Then
        DxaGetVersionPart = CLng(Val(CStr(parts(index))))
    Else
        DxaGetVersionPart = 0
    End If
End Function

Private Function DxaReadInstallRoot() As String
    On Error GoTo EH
    Dim sh As Object
    Set sh = CreateObject("WScript.Shell")
    DxaReadInstallRoot = CStr(sh.RegRead("HKCU\Software\DExcelAssist\InstallRoot"))
    Exit Function
EH:
    DxaReadInstallRoot = vbNullString
End Function

Private Function DxaPsQuote(ByVal value As String) As String
    DxaPsQuote = "'" & Replace(value, "'", "''") & "'"
End Function

Private Function DxaQuoteForCommand(ByVal value As String) As String
    DxaQuoteForCommand = Chr$(34) & Replace(value, Chr$(34), Chr$(34) & Chr$(34)) & Chr$(34)
End Function
