Attribute VB_Name = "DelaxToolsExtra"

Option Explicit

Private Const DxaChangeHistoryDisabledV186Marker As String = "v186"

' DelaxTools change-history event state.
' DelaxTools v172
' Module-level declarations must be placed before all procedures.
Private gDxaEvents As DelaxToolsAppEvents
Private gDxaSessionId As String
Private gDxaSnapshotQueue As Collection
Private gDxaSnapshotScheduled As Boolean
Private gDxaPreChangeMap As Object
Private gDxaPreChangeWorkbookKey As String
Private gDxaLoggedChangeKeys As Object
Private gDxaLoggedChangeWorkbookKey As String
Private gDxaLastSelectionCaptureKey As String
Private gDxaLastSelectionCaptureAt As Double
Private Const DxaSelectionCaptureMaxCells As Long = 50
Private Const DxaChangePersistMaxCells As Long = 500
Private gDxaCleanupDone As Boolean
Private Const DXA_SNAPSHOT_DELAY_SECONDS As Double = 8
Private gDxaRibbon As Object
Private gDxaStealthRibbonKeyStage As String
Private gDxaStealthRibbonKeyStageAt As Double


#If VBA7 Then
Private Type DxaDataBlob
    cbData As Long
    pbData As LongPtr
End Type

Private Declare PtrSafe Function DxaCryptProtectData Lib "crypt32.dll" Alias "CryptProtectData" (ByRef pDataIn As DxaDataBlob, ByVal szDataDescr As LongPtr, ByVal pOptionalEntropy As LongPtr, ByVal pvReserved As LongPtr, ByVal pPromptStruct As LongPtr, ByVal dwFlags As Long, ByRef pDataOut As DxaDataBlob) As Long
Private Declare PtrSafe Function DxaCryptUnprotectData Lib "crypt32.dll" Alias "CryptUnprotectData" (ByRef pDataIn As DxaDataBlob, ByVal ppszDataDescr As LongPtr, ByVal pOptionalEntropy As LongPtr, ByVal pvReserved As LongPtr, ByVal pPromptStruct As LongPtr, ByVal dwFlags As Long, ByRef pDataOut As DxaDataBlob) As Long
Private Declare PtrSafe Sub DxaCopyMemory Lib "kernel32" Alias "RtlMoveMemory" (ByVal Destination As LongPtr, ByVal Source As LongPtr, ByVal Length As LongPtr)
Private Declare PtrSafe Function DxaLocalFree Lib "kernel32" Alias "LocalFree" (ByVal hMem As LongPtr) As LongPtr
#Else
Private Type DxaDataBlob
    cbData As Long
    pbData As Long
End Type

Private Declare Function DxaCryptProtectData Lib "crypt32.dll" Alias "CryptProtectData" (ByRef pDataIn As DxaDataBlob, ByVal szDataDescr As Long, ByVal pOptionalEntropy As Long, ByVal pvReserved As Long, ByVal pPromptStruct As Long, ByVal dwFlags As Long, ByRef pDataOut As DxaDataBlob) As Long
Private Declare Function DxaCryptUnprotectData Lib "crypt32.dll" Alias "CryptUnprotectData" (ByRef pDataIn As DxaDataBlob, ByVal ppszDataDescr As Long, ByVal pOptionalEntropy As Long, ByVal pvReserved As Long, ByVal pPromptStruct As Long, ByVal dwFlags As Long, ByRef pDataOut As DxaDataBlob) As Long
Private Declare Sub DxaCopyMemory Lib "kernel32" Alias "RtlMoveMemory" (ByVal Destination As Long, ByVal Source As Long, ByVal Length As Long)
Private Declare Function DxaLocalFree Lib "kernel32" Alias "LocalFree" (ByVal hMem As Long) As Long
#End If



' DelaxTools v108

' �����A�b�v�f�[�g�@�\�͊܂߂Ă��܂���B

' �ǉ��@�\��Excel��VBA�Ƃ��Ď��s���܂��B



Public Sub DxaCreateHolidaySheet(ByVal control As Object)

    On Error GoTo EH

    Dim yText As String

    yText = InputBox("�x���ꗗ���쐬����N����͂��Ă��������B", "�x���V�[�g�쐬", CStr(Year(Date)))

    If Len(Trim$(yText)) = 0 Then Exit Sub

    If Not IsNumeric(yText) Then

        MsgBox "�N�͐��l�œ��͂��Ă��������B", vbExclamation, "DelaxTools"

        Exit Sub

    End If



    Dim y As Long

    y = CLng(yText)

    If y < 1900 Or y > 2100 Then

        MsgBox "1900�`2100�͈̔͂œ��͂��Ă��������B", vbExclamation, "DelaxTools"

        Exit Sub

    End If



    Dim wb As Workbook

    Set wb = ActiveWorkbook

    If wb Is Nothing Then Exit Sub



    Dim sheetName As String

    sheetName = "�x��" & CStr(y)



    Application.ScreenUpdating = False

    Application.DisplayAlerts = False

    Dim ws As Worksheet

    On Error Resume Next

    Set ws = wb.Worksheets(sheetName)

    On Error GoTo EH

    If Not ws Is Nothing Then ws.Delete

    Application.DisplayAlerts = True



    Set ws = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))

    ws.Name = sheetName



    Dim items As Object

    Set items = CreateObject("Scripting.Dictionary")

    AddJapaneseHolidays y, items



    ws.Range("A1:C1").Value = Array("���t", "�j��", "�x����")

    ws.Range("A1:C1").Font.Bold = True



    Dim keys As Variant

    keys = items.Keys

    SortDateKeys keys



    Dim r As Long, k As Variant

    r = 2

    For Each k In keys

        ws.Cells(r, 1).Value = CDate(k)

        ws.Cells(r, 2).Value = JapaneseWeekday(CDate(k))

        ws.Cells(r, 3).Value = items(k)

        r = r + 1

    Next



    ws.Columns("A:A").NumberFormatLocal = "yyyy/mm/dd"

    ws.Columns("A:C").AutoFit

    ws.Range("A1:C1").AutoFilter

    ws.Activate

    ws.Range("A1").Select

    Application.ScreenUpdating = True

    MsgBox CStr(y) & "�N�̋x���ꗗ���쐬���܂����B", vbInformation, "DelaxTools"

    Exit Sub

EH:

    Application.DisplayAlerts = True

    Application.ScreenUpdating = True

    MsgBox "�x���V�[�g�쐬�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DelaxTools"

End Sub



Public Sub DxaAllSheetsZoom100(ByVal control As Object)

    On Error GoTo EH

    Dim wb As Workbook

    Set wb = ActiveWorkbook

    If wb Is Nothing Then Exit Sub



    Dim activeName As String

    activeName = ActiveSheet.Name

    Dim ws As Worksheet

    Application.ScreenUpdating = False

    For Each ws In wb.Worksheets

        If ws.Visible = xlSheetVisible Then

            ws.Activate

            ActiveWindow.Zoom = 100

        End If

    Next

    wb.Worksheets(activeName).Activate

    Application.ScreenUpdating = True

    MsgBox "�S�V�[�g�̔{����100%�ɂ��܂����B", vbInformation, "DelaxTools"

    Exit Sub

EH:

    Application.ScreenUpdating = True

    MsgBox "�S�V�[�g�{��100%�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DelaxTools"

End Sub



Public Sub DxaHalfToFull(ByVal control As Object)

    ConvertSelectionAscii True

End Sub



Public Sub DxaFullToHalf(ByVal control As Object)

    ConvertSelectionAscii False

End Sub



Public Sub DxaAutoFitActiveSheetColumns(ByVal control As Object)

    On Error GoTo EH

    Dim ws As Worksheet

    Set ws = ActiveSheet

    If ws Is Nothing Then Exit Sub

    Application.ScreenUpdating = False

    If Application.WorksheetFunction.CountA(ws.Cells) = 0 Then

        ws.Columns.AutoFit

    Else

        ws.UsedRange.Columns.AutoFit

    End If

    Application.ScreenUpdating = True

    MsgBox "���s�V�[�g�̗񕝂������������܂����B", vbInformation, "DelaxTools"

    Exit Sub

EH:

    Application.ScreenUpdating = True

    MsgBox "�񕝎��������ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DelaxTools"

End Sub



Public Sub DxaAutoFitActiveSheetRows(ByVal control As Object)

    On Error GoTo EH

    Dim ws As Worksheet

    Set ws = ActiveSheet

    If ws Is Nothing Then Exit Sub



    Application.ScreenUpdating = False

    If Application.WorksheetFunction.CountA(ws.Cells) = 0 Then

        ws.Rows.AutoFit

    Else

        ws.UsedRange.Rows.AutoFit

    End If

    Application.ScreenUpdating = True

    MsgBox "���s�V�[�g�̍s�����������������܂����B", vbInformation, "DelaxTools"

    Exit Sub

EH:

    Application.ScreenUpdating = True

    MsgBox "�s�������������ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DelaxTools"

End Sub



Private Sub ConvertSelectionAscii(ByVal halfToFull As Boolean)

    On Error GoTo EH

    If TypeName(Selection) = "Nothing" Then Exit Sub

    Application.ScreenUpdating = False



    Dim rng As Range, c As Range

    On Error Resume Next

    Set rng = Selection.SpecialCells(xlCellTypeConstants)

    On Error GoTo EH

    If Not rng Is Nothing Then

        For Each c In rng.Cells

            If Not IsError(c.Value) Then

                c.Value = ConvertAsciiText(CStr(c.Value), halfToFull)

            End If

        Next

    End If



    Dim sr As ShapeRange, shp As Shape

    On Error Resume Next

    Set sr = Selection.ShapeRange

    On Error GoTo EH

    If Not sr Is Nothing Then

        For Each shp In sr

            ConvertShapeText shp, halfToFull

        Next

    End If



    Application.ScreenUpdating = True

    If halfToFull Then

        MsgBox "�I��͈͂̔��p�p������S�p�ɕϊ����܂����B", vbInformation, "DelaxTools"

    Else

        MsgBox "�I��͈͂̑S�p�p�����𔼊p�ɕϊ����܂����B", vbInformation, "DelaxTools"

    End If

    Exit Sub

EH:

    Application.ScreenUpdating = True

    MsgBox "�����ϊ��ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DelaxTools"

End Sub



Private Sub ConvertShapeText(ByVal shp As Shape, ByVal halfToFull As Boolean)

    On Error Resume Next

    If shp.TextFrame2.HasText Then shp.TextFrame2.TextRange.Text = ConvertAsciiText(shp.TextFrame2.TextRange.Text, halfToFull)

    If shp.TextFrame.Characters.Count > 0 Then shp.TextFrame.Characters.Text = ConvertAsciiText(shp.TextFrame.Characters.Text, halfToFull)

End Sub



Private Function ConvertAsciiText(ByVal s As String, ByVal halfToFull As Boolean) As String

    Dim i As Long, code As Long, ch As String, out As String

    For i = 1 To Len(s)

        ch = Mid$(s, i, 1)

        code = AscW(ch)

        If halfToFull Then

            If (code >= 48 And code <= 57) Or (code >= 65 And code <= 90) Or (code >= 97 And code <= 122) Then

                out = out & ChrW$(code + &HFEE0)

            Else

                out = out & ch

            End If

        Else

            If (code >= &HFF10 And code <= &HFF19) Or (code >= &HFF21 And code <= &HFF3A) Or (code >= &HFF41 And code <= &HFF5A) Then

                out = out & ChrW$(code - &HFEE0)

            Else

                out = out & ch

            End If

        End If

    Next

    ConvertAsciiText = out

End Function



Private Sub AddJapaneseHolidays(ByVal y As Long, ByVal d As Object)

    AddHoliday d, DateSerial(y, 1, 1), "����"

    AddHoliday d, NthMonday(y, 1, 2), "���l�̓�"

    AddHoliday d, DateSerial(y, 2, 11), "�����L�O�̓�"

    If y >= 2020 Then AddHoliday d, DateSerial(y, 2, 23), "�V�c�a����"

    AddHoliday d, VernalEquinox(y), "�t���̓�"

    AddHoliday d, DateSerial(y, 4, 29), "���a�̓�"

    AddHoliday d, DateSerial(y, 5, 3), "���@�L�O��"

    AddHoliday d, DateSerial(y, 5, 4), "�݂ǂ�̓�"

    AddHoliday d, DateSerial(y, 5, 5), "���ǂ��̓�"

    AddHoliday d, NthMonday(y, 7, 3), "�C�̓�"

    AddHoliday d, DateSerial(y, 8, 11), "�R�̓�"

    AddHoliday d, NthMonday(y, 9, 3), "�h�V�̓�"

    AddHoliday d, AutumnalEquinox(y), "�H���̓�"

    AddHoliday d, NthMonday(y, 10, 2), "�X�|�[�c�̓�"

    AddHoliday d, DateSerial(y, 11, 3), "�����̓�"

    AddHoliday d, DateSerial(y, 11, 23), "�ΘJ���ӂ̓�"

    AddSubstituteHolidays y, d

    AddCitizensHolidays y, d

End Sub



Private Sub AddHoliday(ByVal d As Object, ByVal dt As Date, ByVal name As String)

    Dim key As String

    key = Format$(dt, "yyyy/mm/dd")

    If d.Exists(key) Then

        If InStr(1, d(key), name, vbTextCompare) = 0 Then d(key) = d(key) & " / " & name

    Else

        d.Add key, name

    End If

End Sub



Private Sub AddSubstituteHolidays(ByVal y As Long, ByVal d As Object)

    Dim keys As Variant, k As Variant, dt As Date, subDt As Date

    keys = d.Keys

    For Each k In keys

        dt = CDate(k)

        If Year(dt) = y And Weekday(dt, vbSunday) = vbSunday Then

            subDt = DateAdd("d", 1, dt)

            Do While d.Exists(Format$(subDt, "yyyy/mm/dd"))

                subDt = DateAdd("d", 1, subDt)

            Loop

            If Year(subDt) = y Then AddHoliday d, subDt, "�U�֋x��"

        End If

    Next

End Sub



Private Sub AddCitizensHolidays(ByVal y As Long, ByVal d As Object)

    Dim dt As Date

    For dt = DateSerial(y, 1, 2) To DateSerial(y, 12, 30)

        If Not d.Exists(Format$(dt, "yyyy/mm/dd")) Then

            If d.Exists(Format$(DateAdd("d", -1, dt), "yyyy/mm/dd")) And d.Exists(Format$(DateAdd("d", 1, dt), "yyyy/mm/dd")) Then

                If Weekday(dt, vbSunday) <> vbSunday Then AddHoliday d, dt, "�����̋x��"

            End If

        End If

    Next

End Sub



Private Function NthMonday(ByVal y As Long, ByVal m As Long, ByVal n As Long) As Date

    Dim dt As Date

    dt = DateSerial(y, m, 1)

    Do While Weekday(dt, vbMonday) <> 1

        dt = DateAdd("d", 1, dt)

    Loop

    NthMonday = DateAdd("d", (n - 1) * 7, dt)

End Function



Private Function VernalEquinox(ByVal y As Long) As Date

    Dim dayNum As Long

    If y <= 2099 Then

        dayNum = Int(20.8431 + 0.242194 * (y - 1980) - Int((y - 1980) / 4))

    Else

        dayNum = Int(21.851 + 0.242194 * (y - 1980) - Int((y - 1980) / 4))

    End If

    VernalEquinox = DateSerial(y, 3, dayNum)

End Function



Private Function AutumnalEquinox(ByVal y As Long) As Date

    Dim dayNum As Long

    If y <= 2099 Then

        dayNum = Int(23.2488 + 0.242194 * (y - 1980) - Int((y - 1980) / 4))

    Else

        dayNum = Int(24.2488 + 0.242194 * (y - 1980) - Int((y - 1980) / 4))

    End If

    AutumnalEquinox = DateSerial(y, 9, dayNum)

End Function



Private Function JapaneseWeekday(ByVal dt As Date) As String

    JapaneseWeekday = Choose(Weekday(dt, vbSunday), "��", "��", "��", "��", "��", "��", "�y")

End Function



Private Sub SortDateKeys(ByRef keys As Variant)

    Dim i As Long, j As Long, tmp As Variant

    For i = LBound(keys) To UBound(keys) - 1

        For j = i + 1 To UBound(keys)

            If CDate(keys(i)) > CDate(keys(j)) Then

                tmp = keys(i)

                keys(i) = keys(j)

                keys(j) = tmp

            End If

        Next

    Next

End Sub





'============================================================

' v95 �ǉ��@�\

'============================================================

Public Sub DxaCreateSheetIndex(ByVal control As Object)

    On Error GoTo EH

    Dim wb As Workbook
    Set wb = ActiveWorkbook
    If wb Is Nothing Then Exit Sub

    Dim indexName As String
    indexName = "�V�[�g�ꗗ"

    Application.ScreenUpdating = False
    Application.DisplayAlerts = False

    Dim wsIndex As Worksheet
    On Error Resume Next
    Set wsIndex = wb.Worksheets(indexName)
    On Error GoTo EH
    If Not wsIndex Is Nothing Then wsIndex.Delete

    Application.DisplayAlerts = True

    Set wsIndex = wb.Worksheets.Add(Before:=wb.Worksheets(1))
    wsIndex.Name = indexName

    wsIndex.Range("A1:C1").Value = Array("No", "�V�[�g��", "�\�����")
    wsIndex.Range("A1:C1").Font.Bold = True
    wsIndex.Range("A1:C1").Interior.Color = RGB(221, 235, 247)

    Dim r As Long
    r = 2

    Dim ws As Worksheet
    For Each ws In wb.Worksheets
        If ws.Name <> wsIndex.Name Then
            wsIndex.Cells(r, 1).Value = r - 1
            wsIndex.Cells(r, 2).Value = ws.Name
            wsIndex.Hyperlinks.Add Anchor:=wsIndex.Cells(r, 2), Address:="", SubAddress:="'" & Replace(ws.Name, "'", "''") & "'!A1", TextToDisplay:=ws.Name
            Select Case ws.Visible
                Case xlSheetVisible
                    wsIndex.Cells(r, 3).Value = "�\��"
                Case xlSheetHidden
                    wsIndex.Cells(r, 3).Value = "��\��"
                Case xlSheetVeryHidden
                    wsIndex.Cells(r, 3).Value = "VeryHidden"
                Case Else
                    wsIndex.Cells(r, 3).Value = CStr(ws.Visible)
            End Select
            r = r + 1
        End If
    Next ws

    wsIndex.Columns("A:C").AutoFit
    wsIndex.Range("A1:C1").AutoFilter
    wsIndex.Activate
    wsIndex.Range("A1").Select

    Application.ScreenUpdating = True
    MsgBox "�V�[�g�ꗗ���쐬���܂����B", vbInformation, "DelaxTools"
    Exit Sub
EH:
    Application.DisplayAlerts = True
    Application.ScreenUpdating = True
    MsgBox "�V�[�g�ꗗ�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DelaxTools"
End Sub

Public Sub DxaBacklogGroupByParent(ByVal control As Object)
    DxaBacklogGroupByParentCore
End Sub

Private Sub DxaBacklogGroupByParentCore()
    On Error GoTo EH

    Dim wb As Workbook
    Dim wsTarget As Worksheet
    Dim wsParent As Worksheet
    Dim parentDict As Object
    Dim lastRowTarget As Long
    Dim lastRowParent As Long
    Dim rowIndex As Long
    Dim cellValue As String
    Dim parentSource As String

    Set wb = ActiveWorkbook
    If wb Is Nothing Then
        MsgBox "�Ώۃu�b�N���J���Ă�����s���Ă��������B", vbExclamation, "DelaxTools"
        Exit Sub
    End If

    Set wsTarget = ActiveSheet
    If wsTarget Is Nothing Then
        MsgBox "�ΏۃV�[�g��I�����Ă�����s���Ă��������B", vbExclamation, "DelaxTools"
        Exit Sub
    End If

    Set parentDict = CreateObject("Scripting.Dictionary")
    Set wsParent = DxaFindWorksheetInWorkbook(wb, "�e�ۑ�ꗗ")

    If Not wsParent Is Nothing Then
        lastRowParent = wsParent.Cells(wsParent.Rows.Count, "A").End(xlUp).Row
        For rowIndex = 1 To lastRowParent
            cellValue = DxaBacklogIssueKeyText(wsParent.Cells(rowIndex, "A"))
            If Len(cellValue) > 0 Then parentDict(cellValue) = True
        Next rowIndex
        parentSource = "�e�ۑ�ꗗ"
    Else
        DxaCollectBacklogParentCandidates wsTarget, parentDict
        parentSource = "�K���g�V�[�g��������"
    End If

    If parentDict.Count = 0 Then
        MsgBox "�e�ۑ肪������܂���ł����B" & vbCrLf & _
               "�e�ۑ�ꗗ�V�[�g���쐬���邩�ABacklog�K���g�o�̓V�[�g��I�����Ă�����s���Ă��������B", _
               vbExclamation, "DelaxTools"
        Exit Sub
    End If

    lastRowTarget = wsTarget.Cells(wsTarget.Rows.Count, "A").End(xlUp).Row
    If lastRowTarget < 5 Then
        MsgBox "�O���[�v���Ώۂ̍s��������܂���ł����B", vbExclamation, "DelaxTools"
        Exit Sub
    End If

    Application.ScreenUpdating = False

    On Error Resume Next
    wsTarget.Rows.ClearOutline
    On Error GoTo EH

    wsTarget.Range("A5:A" & lastRowTarget).IndentLevel = 0

    rowIndex = 5
    Do While rowIndex <= lastRowTarget
        cellValue = DxaBacklogIssueKeyText(wsTarget.Cells(rowIndex, "A"))

        If parentDict.Exists(cellValue) Then
            rowIndex = DxaGroupOneBacklogParent(wsTarget, parentDict, rowIndex, lastRowTarget)
        Else
            rowIndex = rowIndex + 1
        End If
    Loop

    Application.ScreenUpdating = True
    MsgBox "�e�ۑ�ŃO���[�v�����܂����B" & vbCrLf & "�e�ۑ�̔�����@: " & parentSource, vbInformation, "DelaxTools"
    Exit Sub

EH:
    Application.ScreenUpdating = True
    MsgBox "�e�ۑ�ŃO���[�v�����ɃG���[���������܂����B" & vbCrLf & _
           "�Ώۃu�b�N�E�ΏۃV�[�g�E�e�ۑ�ꗗ�V�[�g���m�F���Ă��������B" & vbCrLf & _
           Err.Description, vbExclamation, "DelaxTools"
End Sub

Private Function DxaGroupOneBacklogParent(ByVal wsTarget As Worksheet, ByVal parentDict As Object, ByVal parentRow As Long, ByVal lastRowTarget As Long) As Long
    Dim nextParentRow As Long
    Dim searchRow As Long
    Dim startChild As Long
    Dim endChild As Long
    Dim i As Long
    Dim keyText As String

    nextParentRow = 0

    With wsTarget.Cells(parentRow, "A").Font
        .Bold = True
        .Size = Application.Max(8, .Size + 4)
    End With

    With wsTarget.Cells(parentRow, "C").Font
        .Bold = True
        .Size = Application.Max(8, .Size + 4)
    End With

    For searchRow = parentRow + 1 To lastRowTarget
        keyText = DxaBacklogIssueKeyText(wsTarget.Cells(searchRow, "A"))
        If parentDict.Exists(keyText) Then
            nextParentRow = searchRow
            Exit For
        End If
    Next searchRow

    startChild = parentRow + 1
    If nextParentRow > 0 Then
        endChild = nextParentRow - 1
    Else
        endChild = lastRowTarget
    End If

    If startChild <= endChild Then
        wsTarget.Rows(startChild & ":" & endChild).Group
        For i = startChild To endChild
            wsTarget.Cells(i, "A").IndentLevel = wsTarget.Cells(i, "A").IndentLevel + 1
        Next i
    End If

    If nextParentRow > 0 Then
        DxaGroupOneBacklogParent = nextParentRow
    Else
        DxaGroupOneBacklogParent = lastRowTarget + 1
    End If
End Function

Private Sub DxaCollectBacklogParentCandidates(ByVal ws As Worksheet, ByVal parentDict As Object)
    Dim headerRow As Long
    Dim firstDataRow As Long
    Dim lastRow As Long
    Dim r As Long
    Dim keyText As String

    headerRow = DxaBacklogFindHeaderRow(ws)
    If headerRow = 0 Then headerRow = 4
    firstDataRow = headerRow + 1
    lastRow = ws.Cells(ws.Rows.Count, "A").End(xlUp).Row

    For r = firstDataRow To lastRow
        keyText = DxaBacklogIssueKeyText(ws.Cells(r, "A"))
        If Len(keyText) > 0 Then
            If DxaLooksLikeBacklogParentRow(ws, r, firstDataRow, lastRow) Then
                parentDict(keyText) = True
            End If
        End If
    Next r
End Sub

Private Function DxaLooksLikeBacklogParentRow(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal firstDataRow As Long, ByVal lastRow As Long) As Boolean
    Dim assigneeText As String
    Dim plannedText As String
    Dim actualText As String
    Dim startValue As Variant
    Dim dueValue As Variant
    Dim durationDays As Long

    assigneeText = Trim$(CStr(ws.Cells(rowNo, "G").Value))
    plannedText = Trim$(CStr(ws.Cells(rowNo, "J").Value))
    actualText = Trim$(CStr(ws.Cells(rowNo, "K").Value))
    startValue = ws.Cells(rowNo, "H").Value
    dueValue = ws.Cells(rowNo, "I").Value

    If Len(assigneeText) > 0 Then Exit Function
    If Len(plannedText) > 0 Or Len(actualText) > 0 Then Exit Function

    If IsDate(startValue) And IsDate(dueValue) Then
        durationDays = CLng(CDate(dueValue) - CDate(startValue))
        If durationDays >= 2 Then
            DxaLooksLikeBacklogParentRow = True
            Exit Function
        End If
    End If

    If DxaNextRowsLookLikeChildren(ws, rowNo, lastRow) Then
        DxaLooksLikeBacklogParentRow = True
    End If
End Function

Private Function DxaNextRowsLookLikeChildren(ByVal ws As Worksheet, ByVal parentRow As Long, ByVal lastRow As Long) As Boolean
    Dim r As Long
    Dim checkLimit As Long
    Dim childCount As Long

    checkLimit = parentRow + 5
    If checkLimit > lastRow Then checkLimit = lastRow

    For r = parentRow + 1 To checkLimit
        If Len(DxaBacklogIssueKeyText(ws.Cells(r, "A"))) > 0 Then
            If Len(Trim$(CStr(ws.Cells(r, "G").Value))) > 0 Or Len(Trim$(CStr(ws.Cells(r, "J").Value))) > 0 Or Len(Trim$(CStr(ws.Cells(r, "K").Value))) > 0 Then
                childCount = childCount + 1
            End If
        End If
    Next r

    DxaNextRowsLookLikeChildren = (childCount >= 1)
End Function

Private Function DxaBacklogIssueKeyText(ByVal cell As Range) As String
    On Error Resume Next
    If cell.Hyperlinks.Count > 0 Then
        DxaBacklogIssueKeyText = Trim$(CStr(cell.Hyperlinks(1).TextToDisplay))
    ElseIf cell.HasFormula Then
        DxaBacklogIssueKeyText = Trim$(CStr(cell.Text))
    Else
        DxaBacklogIssueKeyText = Trim$(CStr(cell.Value))
    End If
End Function

Private Function DxaBacklogFindHeaderRow(ByVal ws As Worksheet) As Long
    Dim r As Long
    For r = 1 To 20
        If Trim$(CStr(ws.Cells(r, "A").Value)) = "�L�[" _
           And Trim$(CStr(ws.Cells(r, "C").Value)) = "����" Then
            DxaBacklogFindHeaderRow = r
            Exit Function
        End If
    Next r
    DxaBacklogFindHeaderRow = 0
End Function

Private Function DxaFindWorksheetInWorkbook(ByVal wb As Workbook, ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set DxaFindWorksheetInWorkbook = wb.Worksheets(sheetName)
    On Error GoTo 0
End Function

' �t�H���_�c���[�쐬�F�I�������t�H���_�z���̃t�H���_/�t�@�C���\�����A���݂̃V�[�g�֕�����x�[�X�ő}�����܂��B
' �Q�l����FRelaxApps�́u�t�H���_�[ �c���[�쐬�v���l�A�t�H���_��I�����Ď擾���AExcel��Ƀc���[��\��t���܂��B
Public Sub DxaCreateFolderTreeWithFolderPicker(ByVal control As Object)
    On Error GoTo ErrHandler

    Dim rootFolder As String
    rootFolder = DxaPickSourceFolder("�c���[���쐬����t�H���_��I�����Ă�������")
    If Len(rootFolder) = 0 Then Exit Sub

    Dim includeFilesAnswer As VbMsgBoxResult
    includeFilesAnswer = MsgBox("�t�@�C�����c���[�Ɋ܂߂܂����H" & vbCrLf & _
                                "�͂�: �t�H���_�{�t�@�C�����o��" & vbCrLf & _
                                "������: �t�H���_�̂ݏo��", _
                                vbQuestion + vbYesNoCancel, "�t�H���_�c���[")
    If includeFilesAnswer = vbCancel Then Exit Sub

    Dim includeFiles As Boolean
    includeFiles = (includeFilesAnswer = vbYes)

    Dim fso As Object
    Set fso = CreateObject("Scripting.FileSystemObject")
    If Not fso.FolderExists(rootFolder) Then
        MsgBox "�I�������t�H���_��������܂���B" & vbCrLf & rootFolder, vbExclamation, "�t�H���_�c���["
        Exit Sub
    End If

    Dim wb As Workbook
    Set wb = ActiveWorkbook
    If wb Is Nothing Then Exit Sub

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.DisplayAlerts = False

    Dim ws As Worksheet
    On Error Resume Next
    Set ws = wb.Worksheets("�t�H���_�c���[")
    On Error GoTo ErrHandler
    If Not ws Is Nothing Then ws.Delete

    Application.DisplayAlerts = True

    Set ws = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))
    ws.Name = "�t�H���_�c���["

    Dim rowNo As Long
    rowNo = 1

    Dim colTree As Long
    Dim colType As Long
    Dim colPath As Long
    Dim colModified As Long
    Dim colSize As Long
    colTree = 1
    colType = 2
    colPath = 3
    colModified = 4
    colSize = 5

    ws.Cells(rowNo, colTree).Value = "�c���["
    ws.Cells(rowNo, colType).Value = "���"
    ws.Cells(rowNo, colPath).Value = "�p�X"
    ws.Cells(rowNo, colModified).Value = "�X�V����"
    ws.Cells(rowNo, colSize).Value = "�T�C�Y(KB)"
    ws.Range(ws.Cells(rowNo, colTree), ws.Cells(rowNo, colSize)).Font.Bold = True
    ws.Range(ws.Cells(rowNo, colTree), ws.Cells(rowNo, colSize)).Interior.Color = RGB(221, 235, 247)
    rowNo = rowNo + 1

    Dim root As Object
    Set root = fso.GetFolder(rootFolder)

    DxaWriteTreeLine ws, rowNo, colTree, colType, colPath, colModified, colSize, _
                     "�� " & root.Name, "�t�H���_", root.Path, root.DateLastModified, "", root.Path
    rowNo = rowNo + 1

    Dim folderCount As Long
    Dim fileCount As Long
    folderCount = 1
    fileCount = 0

    DxaOutputFolderTree ws, rowNo, colTree, colType, colPath, colModified, colSize, root, "", includeFiles, folderCount, fileCount

    ws.Range(ws.Cells(1, colTree), ws.Cells(rowNo - 1, colSize)).Columns.AutoFit
    ws.Range("A1:E1").AutoFilter
    ws.Activate
    ws.Range("A1").Select

    Application.DisplayAlerts = True
    Application.EnableEvents = True
    Application.ScreenUpdating = True

    MsgBox "�t�H���_�c���[���쐬���܂����B" & vbCrLf & _
           "�擾��: " & rootFolder & vbCrLf & _
           "�o�͐�: �t�H���_�c���[ �V�[�g" & vbCrLf & _
           "�t�H���_: " & folderCount & " ��" & vbCrLf & _
           "�t�@�C��: " & fileCount & " ��", vbInformation, "�t�H���_�c���["
    Exit Sub

ErrHandler:
    Application.DisplayAlerts = True
    Application.EnableEvents = True
    Application.ScreenUpdating = True
    MsgBox "�t�H���_�c���[�쐬�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "�t�H���_�c���["
End Sub

Private Sub DxaOutputFolderTree(ByVal ws As Worksheet, ByRef rowNo As Long, _
                                ByVal colTree As Long, ByVal colType As Long, ByVal colPath As Long, ByVal colModified As Long, ByVal colSize As Long, _
                                ByVal folderObj As Object, ByVal prefix As String, ByVal includeFiles As Boolean, _
                                ByRef folderCount As Long, ByRef fileCount As Long)
    On Error GoTo AccessDenied

    Dim folderPaths As Variant
    Dim filePaths As Variant
    folderPaths = DxaSortedFolderPaths(folderObj)
    If includeFiles Then filePaths = DxaSortedFilePaths(folderObj)

    Dim folderTotal As Long
    Dim fileTotal As Long
    folderTotal = DxaVariantItemCount(folderPaths)
    If includeFiles Then fileTotal = DxaVariantItemCount(filePaths) Else fileTotal = 0

    Dim i As Long
    For i = 1 To folderTotal
        Dim fPath As String
        fPath = CStr(folderPaths(i))

        Dim childFolder As Object
        Set childFolder = CreateObject("Scripting.FileSystemObject").GetFolder(fPath)

        Dim isLastFolderItem As Boolean
        isLastFolderItem = (i = folderTotal And fileTotal = 0)

        Dim branch As String
        If isLastFolderItem Then branch = "���� " Else branch = "���� "

        DxaWriteTreeLine ws, rowNo, colTree, colType, colPath, colModified, colSize, _
                         prefix & branch & "�� " & childFolder.Name, "�t�H���_", childFolder.Path, childFolder.DateLastModified, "", childFolder.Path
        rowNo = rowNo + 1
        folderCount = folderCount + 1

        Dim nextPrefix As String
        If isLastFolderItem Then nextPrefix = prefix & "    " Else nextPrefix = prefix & "��  "
        DxaOutputFolderTree ws, rowNo, colTree, colType, colPath, colModified, colSize, childFolder, nextPrefix, includeFiles, folderCount, fileCount
    Next i

    If includeFiles Then
        For i = 1 To fileTotal
            Dim filePath As String
            filePath = CStr(filePaths(i))

            Dim fileObj As Object
            Set fileObj = CreateObject("Scripting.FileSystemObject").GetFile(filePath)

            Dim fileBranch As String
            If i = fileTotal Then fileBranch = "���� " Else fileBranch = "���� "

            DxaWriteTreeLine ws, rowNo, colTree, colType, colPath, colModified, colSize, _
                             prefix & fileBranch & "�E " & fileObj.Name, "�t�@�C��", fileObj.Path, fileObj.DateLastModified, DxaFormatKb(fileObj.Size), fileObj.Path
            rowNo = rowNo + 1
            fileCount = fileCount + 1
        Next i
    End If
    Exit Sub

AccessDenied:
    DxaWriteTreeLine ws, rowNo, colTree, colType, colPath, colModified, colSize, _
                     prefix & "���� [�A�N�Z�X�s��] " & folderObj.Name, "�G���[", folderObj.Path, "", "", folderObj.Path
    rowNo = rowNo + 1
End Sub

Private Sub DxaWriteTreeLine(ByVal ws As Worksheet, ByVal rowNo As Long, _
                             ByVal colTree As Long, ByVal colType As Long, ByVal colPath As Long, ByVal colModified As Long, ByVal colSize As Long, _
                             ByVal treeText As String, ByVal typeText As String, ByVal pathText As String, ByVal modifiedValue As Variant, ByVal sizeText As String, ByVal linkPath As String)
    ws.Cells(rowNo, colTree).Value = treeText
    ws.Cells(rowNo, colType).Value = typeText
    ws.Cells(rowNo, colPath).Value = pathText
    If Len(CStr(modifiedValue)) > 0 Then ws.Cells(rowNo, colModified).Value = modifiedValue
    ws.Cells(rowNo, colSize).Value = sizeText

    On Error Resume Next
    ws.Hyperlinks.Add Anchor:=ws.Cells(rowNo, colTree), Address:=linkPath, TextToDisplay:=treeText
    On Error GoTo 0
End Sub

Private Function DxaSortedFolderPaths(ByVal folderObj As Object) As Variant
    Dim col As Collection
    Set col = New Collection

    Dim f As Object
    For Each f In folderObj.SubFolders
        col.Add CStr(f.Path)
    Next f

    DxaSortedFolderPaths = DxaCollectionToSortedArray(col)
End Function

Private Function DxaSortedFilePaths(ByVal folderObj As Object) As Variant
    Dim col As Collection
    Set col = New Collection

    Dim f As Object
    For Each f In folderObj.Files
        col.Add CStr(f.Path)
    Next f

    DxaSortedFilePaths = DxaCollectionToSortedArray(col)
End Function

Private Function DxaCollectionToSortedArray(ByVal col As Collection) As Variant
    If col.Count = 0 Then
        DxaCollectionToSortedArray = Empty
        Exit Function
    End If

    Dim arr() As String
    ReDim arr(1 To col.Count)

    Dim i As Long
    For i = 1 To col.Count
        arr(i) = CStr(col(i))
    Next i

    DxaSortStringArray arr
    DxaCollectionToSortedArray = arr
End Function

Private Sub DxaSortStringArray(ByRef arr() As String)
    Dim i As Long
    Dim j As Long
    Dim tmp As String

    For i = LBound(arr) To UBound(arr) - 1
        For j = i + 1 To UBound(arr)
            If StrComp(arr(i), arr(j), vbTextCompare) > 0 Then
                tmp = arr(i)
                arr(i) = arr(j)
                arr(j) = tmp
            End If
        Next j
    Next i
End Sub

Private Function DxaVariantItemCount(ByVal values As Variant) As Long
    On Error GoTo EmptyValue
    If IsEmpty(values) Then
        DxaVariantItemCount = 0
    Else
        DxaVariantItemCount = UBound(values) - LBound(values) + 1
    End If
    Exit Function
EmptyValue:
    DxaVariantItemCount = 0
End Function

Private Function DxaFormatKb(ByVal bytes As Currency) As String
    DxaFormatKb = Format$(CDbl(bytes) / 1024#, "#,##0.0")
End Function

Private Function DxaPickSourceFolder(ByVal titleText As String) As String
    On Error GoTo Fallback
    Dim fd As FileDialog
    Set fd = Application.FileDialog(msoFileDialogFolderPicker)
    With fd
        .Title = titleText
        .AllowMultiSelect = False
        .InitialFileName = DxaDefaultFolder() & Application.PathSeparator
        If .Show <> -1 Then
            DxaPickSourceFolder = ""
        Else
            DxaPickSourceFolder = .SelectedItems(1)
        End If
    End With
    Exit Function
Fallback:
    DxaPickSourceFolder = InputBox(titleText & vbCrLf & "�t�H���_�̃p�X����͂��Ă��������B", "�t�H���_�I��", DxaDefaultFolder())
End Function

Public Sub DxaCreateFileList(ByVal control As Object)
    On Error GoTo ErrHandler

    Dim rootFolder As String
    rootFolder = DxaPickSourceFolder("�t�@�C���ꗗ���쐬����t�H���_��I�����Ă�������")
    If Len(rootFolder) = 0 Then Exit Sub

    Dim includeSubFoldersAnswer As VbMsgBoxResult
    includeSubFoldersAnswer = MsgBox("�T�u�t�H���_���̃t�@�C�����ꗗ�Ɋ܂߂܂����H" & vbCrLf & _
                                     "�͂�: �T�u�t�H���_���܂߂�" & vbCrLf & _
                                     "������: �I���t�H���_�����̂�", _
                                     vbQuestion + vbYesNoCancel, "�t�@�C���ꗗ")
    If includeSubFoldersAnswer = vbCancel Then Exit Sub

    Dim includeSubFolders As Boolean
    includeSubFolders = (includeSubFoldersAnswer = vbYes)

    Dim fso As Object
    Set fso = CreateObject("Scripting.FileSystemObject")
    If Not fso.FolderExists(rootFolder) Then
        MsgBox "�I�������t�H���_��������܂���B" & vbCrLf & rootFolder, vbExclamation, "�t�@�C���ꗗ"
        Exit Sub
    End If

    Dim wb As Workbook
    Set wb = ActiveWorkbook
    If wb Is Nothing Then Exit Sub

    Application.ScreenUpdating = False
    Application.DisplayAlerts = False

    Dim ws As Worksheet
    On Error Resume Next
    Set ws = wb.Worksheets("�t�@�C���ꗗ")
    On Error GoTo ErrHandler
    If Not ws Is Nothing Then ws.Delete

    Application.DisplayAlerts = True
    Set ws = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))
    ws.Name = "�t�@�C���ꗗ"

    ws.Range("A1:H1").Value = Array("No", "�t�@�C����", "�g���q", "�t�H���_", "�t���p�X", "�T�C�Y(KB)", "�X�V����", "�쐬����")
    ws.Range("A1:H1").Font.Bold = True
    ws.Range("A1:H1").Interior.Color = RGB(221, 235, 247)

    Dim rowNo As Long
    rowNo = 2

    Dim fileCount As Long
    fileCount = 0

    Dim root As Object
    Set root = fso.GetFolder(rootFolder)
    DxaOutputFileList ws, rowNo, root, includeSubFolders, fileCount

    ws.Columns("A:H").AutoFit
    ws.Range("A1:H1").AutoFilter
    ws.Activate
    ws.Range("A1").Select

    Application.DisplayAlerts = True
    Application.ScreenUpdating = True

    MsgBox "�t�@�C���ꗗ���쐬���܂����B" & vbCrLf & _
           "�Ώۃt�H���_: " & rootFolder & vbCrLf & _
           "�t�@�C����: " & fileCount & " ��", vbInformation, "�t�@�C���ꗗ"
    Exit Sub

ErrHandler:
    Application.DisplayAlerts = True
    Application.ScreenUpdating = True
    MsgBox "�t�@�C���ꗗ�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "�t�@�C���ꗗ"
End Sub

Private Sub DxaOutputFileList(ByVal ws As Worksheet, ByRef rowNo As Long, ByVal folderObj As Object, _
                              ByVal includeSubFolders As Boolean, ByRef fileCount As Long)
    On Error GoTo AccessDenied

    Dim filePaths As Variant
    filePaths = DxaSortedFilePaths(folderObj)

    Dim i As Long
    Dim fileObj As Object
    For i = 1 To DxaVariantItemCount(filePaths)
        Set fileObj = CreateObject("Scripting.FileSystemObject").GetFile(CStr(filePaths(i)))
        fileCount = fileCount + 1
        DxaWriteFileListLine ws, rowNo, fileCount, fileObj
        rowNo = rowNo + 1
    Next i

    If includeSubFolders Then
        Dim folderPaths As Variant
        folderPaths = DxaSortedFolderPaths(folderObj)
        For i = 1 To DxaVariantItemCount(folderPaths)
            DxaOutputFileList ws, rowNo, CreateObject("Scripting.FileSystemObject").GetFolder(CStr(folderPaths(i))), includeSubFolders, fileCount
        Next i
    End If

    Exit Sub
AccessDenied:
    ' �������Ȃ��t�H���_��ꎞ�I�ɎQ�Ƃł��Ȃ��t�@�C���͏������p�����܂��B
    Err.Clear
End Sub

Private Sub DxaWriteFileListLine(ByVal ws As Worksheet, ByVal rowNo As Long, ByVal no As Long, ByVal fileObj As Object)
    On Error Resume Next

    ws.Cells(rowNo, 1).Value = no
    ws.Cells(rowNo, 2).Value = fileObj.Name
    ws.Hyperlinks.Add Anchor:=ws.Cells(rowNo, 2), Address:=fileObj.Path, TextToDisplay:=fileObj.Name
    ws.Cells(rowNo, 3).Value = DxaFileExtension(fileObj.Name)
    ws.Cells(rowNo, 4).Value = fileObj.ParentFolder.Path
    ws.Cells(rowNo, 5).Value = fileObj.Path
    ws.Hyperlinks.Add Anchor:=ws.Cells(rowNo, 5), Address:=fileObj.Path, TextToDisplay:=fileObj.Path
    ws.Cells(rowNo, 6).Value = Round(CDbl(fileObj.Size) / 1024, 1)
    ws.Cells(rowNo, 7).Value = fileObj.DateLastModified
    ws.Cells(rowNo, 8).Value = fileObj.DateCreated
End Sub

Private Function DxaFileExtension(ByVal fileName As String) As String
    Dim p As Long
    p = InStrRev(fileName, ".")
    If p > 0 And p < Len(fileName) Then
        DxaFileExtension = Mid$(fileName, p + 1)
    Else
        DxaFileExtension = ""
    End If
End Function

Public Sub DxaExportVbaWithFolderPicker(ByVal control As Object)

    On Error GoTo EH



    Dim wb As Workbook

    Set wb = ActiveWorkbook

    If wb Is Nothing Then Exit Sub



    Dim selectedFolder As String

    selectedFolder = DxaPickOutputFolder("VBA�G�N�X�|�[�g��t�H���_��I�����Ă�������")

    If Len(selectedFolder) = 0 Then Exit Sub



    Dim exportFolder As String

    exportFolder = selectedFolder & Application.PathSeparator & "VBAExport_" & DxaSafeFileName(DxaWorkbookBaseName(wb.Name)) & "_" & Format(Now, "yyyymmdd_hhnnss")

    If Dir(exportFolder, vbDirectory) = "" Then MkDir exportFolder



    Dim vbProj As Object

    Set vbProj = wb.VBProject



    Dim comp As Object

    Dim ext As String

    Dim exportPath As String

    Dim count As Long



    For Each comp In vbProj.VBComponents

        ext = DxaVbComponentExtension(CLng(comp.Type))

        exportPath = exportFolder & Application.PathSeparator & DxaSafeFileName(CStr(comp.Name)) & ext

        comp.Export exportPath

        count = count + 1

    Next comp



    MsgBox "VBA�\�[�X���G�N�X�|�[�g���܂����B" & vbCrLf & _

           "�o�͐�: " & exportFolder & vbCrLf & _

           "�o�͐�: " & CStr(count), vbInformation, "DelaxTools"

    Exit Sub

EH:

    MsgBox "VBA�G�N�X�|�[�g�ŃG���[���������܂����B" & vbCrLf & _

           "Excel�́wVBA�v���W�F�N�g �I�u�W�F�N�g ���f���ւ̃A�N�Z�X��M������x���K�v�ł��B" & vbCrLf & _

           Err.Description, vbExclamation, "DelaxTools"

End Sub



Private Function DxaPickOutputFolder(ByVal titleText As String) As String

    On Error GoTo Fallback

    Dim fd As FileDialog

    Set fd = Application.FileDialog(msoFileDialogFolderPicker)

    With fd

        .Title = titleText

        .AllowMultiSelect = False

        .InitialFileName = DxaDefaultFolder() & Application.PathSeparator

        If .Show <> -1 Then

            DxaPickOutputFolder = ""

        Else

            DxaPickOutputFolder = .SelectedItems(1)

        End If

    End With

    Exit Function

Fallback:

    DxaPickOutputFolder = InputBox(titleText & vbCrLf & "�t�H���_�̃p�X����͂��Ă��������B", "�t�H���_�I��", DxaDefaultFolder())

End Function



Private Function DxaDefaultFolder() As String

    On Error Resume Next

    If Len(ActiveWorkbook.Path) > 0 Then

        DxaDefaultFolder = ActiveWorkbook.Path

    Else

        DxaDefaultFolder = CreateObject("WScript.Shell").SpecialFolders("Desktop")

    End If

    If Len(DxaDefaultFolder) = 0 Then DxaDefaultFolder = CurDir$

End Function



Private Function DxaVbComponentExtension(ByVal componentType As Long) As String

    Select Case componentType

        Case 1

            DxaVbComponentExtension = ".bas"

        Case 2

            DxaVbComponentExtension = ".cls"

        Case 3

            DxaVbComponentExtension = ".frm"

        Case 100

            DxaVbComponentExtension = ".cls"

        Case Else

            DxaVbComponentExtension = ".txt"

    End Select

End Function



Private Function DxaWorkbookBaseName(ByVal fileName As String) As String

    Dim p As Long

    p = InStrRev(fileName, ".")

    If p > 1 Then

        DxaWorkbookBaseName = Left$(fileName, p - 1)

    Else

        DxaWorkbookBaseName = fileName

    End If

End Function



Private Function DxaSafeFileName(ByVal text As String) As String

    Dim s As String

    s = text

    s = Replace(s, "\", "_")

    s = Replace(s, "/", "_")

    s = Replace(s, ":", "_")

    s = Replace(s, "*", "_")

    s = Replace(s, "?", "_")

    s = Replace(s, """", "_")

    s = Replace(s, "<", "_")

    s = Replace(s, ">", "_")

    s = Replace(s, "|", "_")

    If Len(Trim$(s)) = 0 Then s = "Export"

    DxaSafeFileName = s

End Function



' ============================================================
' �ύX�����쐬�x��
' - ���u�b�N�ɂ̓V�[�g��ǉ����܂���B
' - �ύX�O��Ԃ͊O���ꎞ�t�@�C���֎����ۑ����܂��B
' - �ύX�����쐬�������A���̈ꎞ�t�@�C����ǂݍ���Ŕ�r���܂��B
' - �Ώۃu�b�N������Ƃ��A�܂���Excel�I�����Ɉꎞ�t�@�C�����폜���܂��B
' ============================================================

Public Sub Auto_Open()
    ' v186: �N�����̏d���풓�����͊J�n�����A���{���\���ؑփV���[�g�J�b�g�����o�^���܂��B
    On Error Resume Next
    DxaRegisterStealthRibbonHotKey
End Sub

Public Sub Auto_Close()
    ' v186: �I�������d���X�i�b�v�V���b�g�����͎��s�����A�V���[�g�J�b�g�����������܂��B
    On Error Resume Next
    DxaUnregisterStealthRibbonHotKey
End Sub

Public Sub DxaInitChangeHistoryEvents()
    ' v172: �d�ʉ���������U���ׂč폜���邽�߁A�C�x���g�Ď��E�����L�^�͖��������܂��B
    On Error Resume Next
    Set gDxaEvents = Nothing
    Set gDxaSnapshotQueue = Nothing
    Set gDxaPreChangeMap = Nothing
    Set gDxaLoggedChangeKeys = Nothing
    gDxaSnapshotScheduled = False
    gDxaPreChangeWorkbookKey = ""
    gDxaLoggedChangeWorkbookKey = ""
    gDxaLastSelectionCaptureKey = ""
    gDxaLastSelectionCaptureAt = 0
End Sub


Public Sub DxaCapturePreChangeRange(ByVal target As Range)
    ' v172: �Z���I�����̏풓�����͍s���܂���B
End Sub

Private Sub DxaPutPreChangeCellRecord(ByVal cell As Range)
    On Error Resume Next
    If gDxaPreChangeMap Is Nothing Then Exit Sub
    Dim key As String
    key = cell.Worksheet.Name & "!" & cell.Address(False, False)
    gDxaPreChangeMap(key) = DxaBuildSnapshotRecordForCell(cell, True)
End Sub

Public Sub DxaPersistPreChangeForTarget(ByVal target As Range)
    ' v172: �Z���ύX���̏풓�����͍s���܂���B
End Sub

Private Function DxaBuildSnapshotRecordForCell(ByVal cell As Range, Optional ByVal includeBlank As Boolean = False) As String
    On Error Resume Next
    If cell Is Nothing Then Exit Function
    If Not includeBlank Then
        If Not DxaCellHasSnapshotValue(cell) Then Exit Function
    End If
    DxaBuildSnapshotRecordForCell = DxaJoinSnapshotFields(Array( _
        DxaEsc(cell.Worksheet.Name), _
        DxaEsc(cell.Address(False, False)), _
        CStr(cell.Row), _
        CStr(cell.Column), _
        DxaEsc(DxaGetHeaderText(cell.Worksheet, cell.Column)), _
        DxaEsc(DxaGetRowItemText(cell.Worksheet, cell.Row)), _
        DxaEsc(DxaCellFormulaText(cell)), _
        DxaEsc(DxaCellValueText(cell)), _
        DxaEsc(DxaCellDisplayText(cell)), _
        DxaEsc(DxaCellLinkText(cell)), _
        DxaEsc(DxaCellCommentText(cell)) _
    ))
End Function

Private Sub DxaAppendTextUtf8(ByVal path As String, ByVal text As String)
    On Error GoTo Fallback
    If Len(text) = 0 Then Exit Sub

    Dim bytes As Variant
    bytes = DxaUtf8BytesNoBom(text)

    Dim stm As Object
    Set stm = CreateObject("ADODB.Stream")
    stm.Type = 1
    stm.Open
    If DxaFileExists(path) Then stm.LoadFromFile path
    stm.Position = stm.Size
    stm.Write bytes
    stm.SaveToFile path, 2
    stm.Close
    Exit Sub

Fallback:
    On Error Resume Next
    Dim currentText As String
    If DxaFileExists(path) Then currentText = DxaReadTextUtf8(path)
    DxaWriteTextUtf8 path, currentText & text
End Sub

Private Function DxaUtf8BytesNoBom(ByVal text As String) As Variant
    Dim stm As Object
    Set stm = CreateObject("ADODB.Stream")
    stm.Type = 2
    stm.Charset = "utf-8"
    stm.Open
    stm.WriteText text
    stm.Position = 0
    stm.Type = 1

    Dim bytes As Variant
    bytes = stm.Read
    stm.Close

    On Error Resume Next
    If IsArray(bytes) Then
        If UBound(bytes) >= 2 Then
            If bytes(0) = &HEF And bytes(1) = &HBB And bytes(2) = &HBF Then
                Dim trimmed() As Byte
                Dim i As Long
                ReDim trimmed(0 To UBound(bytes) - 3)
                For i = 3 To UBound(bytes)
                    trimmed(i - 3) = bytes(i)
                Next i
                DxaUtf8BytesNoBom = trimmed
                Exit Function
            End If
        End If
    End If

    DxaUtf8BytesNoBom = bytes
End Function

Public Sub DxaQueueSnapshotForWorkbook(ByVal wb As Workbook)
    ' v172: �S�u�b�N/�S�V�[�g�̎����X�i�b�v�V���b�g�͍s���܂���B
    '       �ύX�����͑I���E�ύX���ꂽ�Z���������y�ʋL�^���܂��B
End Sub

Private Function DxaSnapshotQueueContains(ByVal key As String) As Boolean
    On Error Resume Next
    Dim i As Long
    If gDxaSnapshotQueue Is Nothing Then Exit Function
    For i = 1 To gDxaSnapshotQueue.Count
        If CStr(gDxaSnapshotQueue(i)) = key Then DxaSnapshotQueueContains = True: Exit Function
    Next
End Function

Private Sub DxaScheduleSnapshotProcessor()
    ' v172: �����X�i�b�v�V���b�g�\��͎g�p���܂���B
End Sub

Public Sub DxaProcessQueuedSnapshot()
    ' v172: �����X�i�b�v�V���b�g�����͎g�p���܂���B
End Sub

Private Function DxaWorkbookRuntimeKey(ByVal wb As Workbook) As String
    On Error Resume Next
    If wb Is Nothing Then Exit Function
    If Len(wb.FullName) > 0 Then
        DxaWorkbookRuntimeKey = wb.FullName
    Else
        DxaWorkbookRuntimeKey = wb.Name
    End If
End Function

Private Function DxaFindWorkbookByRuntimeKey(ByVal key As String) As Workbook
    On Error Resume Next
    Dim wb As Workbook
    For Each wb In Application.Workbooks
        If DxaWorkbookRuntimeKey(wb) = key Then
            Set DxaFindWorkbookByRuntimeKey = wb
            Exit Function
        End If
    Next
End Function

Public Sub DxaEnsureSnapshotForWorkbook(ByVal wb As Workbook)
    ' v172: �S�V�[�g�����𔭐������Ȃ����߁A�����X�i�b�v�V���b�g�͍쐬���܂���B
End Sub

Public Sub DxaDeleteSnapshotForWorkbook(ByVal wb As Workbook)
    ' v172: �I�����̃t�@�C��������s��Ȃ����߁A�����폜�͍s���܂���B
End Sub

Public Sub DxaCreateChangeHistory(ByVal control As Object)
    MsgBox "Excel���d���Ȃ錴����؂蕪���邽�߁A�ύX�����@�\��v172�ňꎞ��~���Ă��܂��B" & vbCrLf & _
           "�Αӎ擾�ȂǑ��̋@�\�͂��̂܂܎g�p�ł��܂��B", vbInformation, "DelaxTools"
End Sub

Private Function DxaIsWorkbookExcluded(ByVal wb As Workbook) As Boolean
    On Error Resume Next
    If wb Is Nothing Then DxaIsWorkbookExcluded = True: Exit Function
    If wb.IsAddin Then DxaIsWorkbookExcluded = True: Exit Function
    If LCase$(wb.Name) = "dexcelassist.xlam" Then DxaIsWorkbookExcluded = True: Exit Function
    If LCase$(wb.Name) = "delaxtools.xlam" Then DxaIsWorkbookExcluded = True: Exit Function
    If LCase$(wb.Name) Like "�ύX�����o��_*" Then DxaIsWorkbookExcluded = True: Exit Function
    If LCase$(wb.Name) Like "book*" And wb.Path = "" Then
        ' �V�K�u�b�N���Ώۂɂ͂ł��܂����A�댟�m������邽�ߊJ��������̋�u�b�N�͏��O���܂��B
        If wb.Worksheets.Count = 1 And Application.WorksheetFunction.CountA(wb.Worksheets(1).Cells) = 0 Then
            DxaIsWorkbookExcluded = True
            Exit Function
        End If
    End If
End Function

Private Function DxaChangeSnapshotDir() As String
    Dim p As String
    p = Environ$("APPDATA") & "\DelaxTools\ChangeSnapshots"
    DxaEnsureFolder p
    DxaChangeSnapshotDir = p
End Function

Private Function DxaSnapshotPathForWorkbook(ByVal wb As Workbook) As String
    If wb Is Nothing Then Exit Function
    If Len(gDxaSessionId) = 0 Then gDxaSessionId = Format$(Now, "yyyymmddhhnnss") & "_" & CStr(Int(Rnd() * 1000000))

    Dim keyText As String
    If Len(wb.FullName) > 0 Then
        keyText = wb.FullName
    Else
        keyText = wb.Name
    End If

    DxaSnapshotPathForWorkbook = DxaChangeSnapshotDir() & "\" & gDxaSessionId & "_" & DxaSafeFileName(DxaWorkbookBaseName(wb.Name)) & "_" & DxaSimpleHash(keyText) & ".tsv"
End Function

Private Function DxaBuildSnapshotText(ByVal wb As Workbook) As String
    Dim m As Object
    Set m = DxaBuildSnapshotMap(wb)

    Dim sb As String
    sb = "Key" & vbTab & "Sheet" & vbTab & "Address" & vbTab & "Row" & vbTab & "Column" & vbTab & "Header" & vbTab & "Item" & vbTab & "Formula" & vbTab & "Value" & vbTab & "Text" & vbTab & "Link" & vbTab & "Comment" & vbCrLf

    Dim k As Variant
    For Each k In m.Keys
        sb = sb & CStr(k) & vbTab & m(k) & vbCrLf
    Next

    DxaBuildSnapshotText = sb
End Function

Private Function DxaBuildSnapshotMap(ByVal wb As Workbook) As Object
    Dim dict As Object
    Set dict = CreateObject("Scripting.Dictionary")

    Dim ws As Worksheet
    For Each ws In wb.Worksheets
        If ws.Visible = xlSheetVisible Then
            DxaAddSheetSnapshot dict, ws
        End If
    Next

    Set DxaBuildSnapshotMap = dict
End Function

Private Function DxaBuildSnapshotMapForKeys(ByVal wb As Workbook, ByVal oldMap As Object) As Object
    Dim dict As Object
    Set dict = CreateObject("Scripting.Dictionary")

    On Error GoTo EH
    If wb Is Nothing Then
        Set DxaBuildSnapshotMapForKeys = dict
        Exit Function
    End If
    If oldMap Is Nothing Then
        Set DxaBuildSnapshotMapForKeys = dict
        Exit Function
    End If

    Dim k As Variant
    Dim keyText As String
    Dim pos As Long
    Dim sheetName As String
    Dim addr As String
    Dim ws As Worksheet
    Dim cell As Range

    For Each k In oldMap.Keys
        keyText = CStr(k)
        pos = InStrRev(keyText, "!")
        If pos > 1 Then
            sheetName = Left$(keyText, pos - 1)
            addr = Mid$(keyText, pos + 1)

            Set ws = Nothing
            On Error Resume Next
            Set ws = wb.Worksheets(sheetName)
            On Error GoTo EH

            If Not ws Is Nothing Then
                Set cell = Nothing
                On Error Resume Next
                Set cell = ws.Range(addr)
                On Error GoTo EH

                If Not cell Is Nothing Then
                    dict(keyText) = DxaBuildSnapshotRecordForCell(cell, True)
                End If
            End If
        End If
    Next

    Set DxaBuildSnapshotMapForKeys = dict
    Exit Function
EH:
    Set DxaBuildSnapshotMapForKeys = dict
End Function

Private Sub DxaEnsureChangeSnapshotLog(ByVal wb As Workbook, ByVal path As String)
    On Error Resume Next

    Dim wbKey As String
    wbKey = DxaWorkbookRuntimeKey(wb)

    If gDxaLoggedChangeKeys Is Nothing Or gDxaLoggedChangeWorkbookKey <> wbKey Then
        Set gDxaLoggedChangeKeys = DxaReadSnapshotKeys(path)
        gDxaLoggedChangeWorkbookKey = wbKey
    End If

    If Not DxaFileExists(path) Then
        DxaWriteTextUtf8 path, "Key" & vbTab & "Sheet" & vbTab & "Address" & vbTab & "Row" & vbTab & "Column" & vbTab & "Header" & vbTab & "Item" & vbTab & "Formula" & vbTab & "Value" & vbTab & "Text" & vbTab & "Link" & vbTab & "Comment" & vbCrLf
        If gDxaLoggedChangeKeys Is Nothing Then Set gDxaLoggedChangeKeys = CreateObject("Scripting.Dictionary")
    End If
End Sub

Private Function DxaReadSnapshotKeys(ByVal path As String) As Object
    Dim dict As Object
    Set dict = CreateObject("Scripting.Dictionary")

    On Error GoTo EH
    If Not DxaFileExists(path) Then
        Set DxaReadSnapshotKeys = dict
        Exit Function
    End If

    Dim text As String
    text = DxaReadTextUtf8(path)

    Dim lines As Variant
    lines = Split(text, vbLf)

    Dim i As Long
    For i = LBound(lines) To UBound(lines)
        Dim lineText As String
        lineText = Replace(CStr(lines(i)), vbCr, "")
        If i > 0 And Len(lineText) > 0 Then
            Dim parts As Variant
            parts = Split(lineText, vbTab)
            If UBound(parts) >= 0 Then dict(CStr(parts(0))) = True
        End If
    Next

    Set DxaReadSnapshotKeys = dict
    Exit Function
EH:
    Set DxaReadSnapshotKeys = dict
End Function

Private Function DxaRangeCellCountLarge(ByVal rng As Range) As Double
    On Error GoTo EH
    DxaRangeCellCountLarge = CDbl(rng.CountLarge)
    Exit Function
EH:
    DxaRangeCellCountLarge = 1000000000#
End Function

Private Sub DxaAddSheetSnapshot(ByVal dict As Object, ByVal ws As Worksheet)
    On Error GoTo EH
    Dim ur As Range
    Set ur = ws.UsedRange
    If ur Is Nothing Then Exit Sub

    Dim r1 As Long, c1 As Long, r2 As Long, c2 As Long
    r1 = ur.Row
    c1 = ur.Column
    r2 = ur.Row + ur.Rows.Count - 1
    c2 = ur.Column + ur.Columns.Count - 1

    Dim r As Long, c As Long
    Dim cell As Range
    For r = r1 To r2
        For c = c1 To c2
            Set cell = ws.Cells(r, c)
            If DxaCellHasSnapshotValue(cell) Then
                Dim key As String
                key = ws.Name & "!" & cell.Address(False, False)

                Dim headerText As String
                headerText = DxaGetHeaderText(ws, c)

                Dim itemText As String
                itemText = DxaGetRowItemText(ws, r)

                dict(key) = DxaBuildSnapshotRecordForCell(cell, False)
            End If
        Next c
    Next r
    Exit Sub
EH:
End Sub

Private Function DxaCellHasSnapshotValue(ByVal cell As Range) As Boolean
    On Error Resume Next
    If Len(DxaCellFormulaText(cell)) > 0 Then DxaCellHasSnapshotValue = True: Exit Function
    If Len(DxaCellValueText(cell)) > 0 Then DxaCellHasSnapshotValue = True: Exit Function
    If Len(DxaCellLinkText(cell)) > 0 Then DxaCellHasSnapshotValue = True: Exit Function
    If Len(DxaCellCommentText(cell)) > 0 Then DxaCellHasSnapshotValue = True: Exit Function
End Function

Private Function DxaCellFormulaText(ByVal cell As Range) As String
    On Error Resume Next
    If cell.HasFormula Then DxaCellFormulaText = CStr(cell.Formula)
End Function

Private Function DxaCellValueText(ByVal cell As Range) As String
    On Error Resume Next
    If IsError(cell.Value) Then
        DxaCellValueText = cell.Text
    Else
        DxaCellValueText = CStr(cell.Value)
    End If
End Function

Private Function DxaCellDisplayText(ByVal cell As Range) As String
    On Error Resume Next
    DxaCellDisplayText = CStr(cell.Text)
End Function

Private Function DxaCellLinkText(ByVal cell As Range) As String
    On Error Resume Next
    If cell.Hyperlinks.Count > 0 Then
        DxaCellLinkText = cell.Hyperlinks(1).Address
        If Len(cell.Hyperlinks(1).SubAddress) > 0 Then
            DxaCellLinkText = DxaCellLinkText & "#" & cell.Hyperlinks(1).SubAddress
        End If
    End If
End Function

Private Function DxaCellCommentText(ByVal cell As Range) As String
    On Error Resume Next
    If Not cell.Comment Is Nothing Then DxaCellCommentText = cell.Comment.Text
End Function

Private Function DxaGetHeaderText(ByVal ws As Worksheet, ByVal col As Long) As String
    On Error Resume Next
    Dim s As String
    s = Trim$(CStr(ws.Cells(1, col).Text))
    If Len(s) = 0 And col > 1 Then s = Trim$(CStr(ws.Cells(2, col).Text))
    If Len(s) = 0 Then s = DxaColumnLetter(col) & "��"
    DxaGetHeaderText = s
End Function

Private Function DxaGetRowItemText(ByVal ws As Worksheet, ByVal rowNo As Long) As String
    On Error Resume Next
    Dim s As String
    If rowNo > 1 Then
        s = Trim$(CStr(ws.Cells(rowNo, 1).Text))
        If Len(s) = 0 Then s = Trim$(CStr(ws.Cells(rowNo, 2).Text))
    End If
    If Len(s) = 0 Then s = CStr(rowNo) & "�s��"
    DxaGetRowItemText = s
End Function

Private Function DxaReadSnapshotMap(ByVal path As String) As Object
    Dim dict As Object
    Set dict = CreateObject("Scripting.Dictionary")

    Dim text As String
    text = DxaReadTextUtf8(path)

    Dim lines As Variant
    lines = Split(text, vbLf)

    Dim i As Long
    For i = LBound(lines) To UBound(lines)
        Dim lineText As String
        lineText = Replace(CStr(lines(i)), vbCr, "")
        If i > 0 And Len(lineText) > 0 Then
            Dim parts As Variant
            parts = Split(lineText, vbTab)
            If UBound(parts) >= 11 Then
                dict(parts(0)) = DxaJoinSnapshotFields(Array(parts(1), parts(2), parts(3), parts(4), parts(5), parts(6), parts(7), parts(8), parts(9), parts(10), parts(11)))
            End If
        End If
    Next

    Set DxaReadSnapshotMap = dict
End Function

Private Function DxaCompareSnapshotMaps(ByVal oldMap As Object, ByVal curMap As Object) As Collection
    Dim details As New Collection
    Dim k As Variant

    ' v169:
    ' �N�����̑S�ʃX�i�b�v�V���b�g��p�~���A�ύX���ꂽ�Z���̕ύX�O���O�������r���܂��B
    ' ����ɂ��AExcel�N������␔�b��ɑS�V�[�g���������炸�A�d���Ȃ�܂���B
    For Each k In oldMap.Keys
        If Not curMap.Exists(k) Then
            details.Add DxaBuildChangeDetail(CStr(k), "�폜", oldMap(k), "")
        ElseIf DxaSnapshotComparableText(oldMap(k)) <> DxaSnapshotComparableText(curMap(k)) Then
            details.Add DxaBuildChangeDetail(CStr(k), DxaDetectChangeType(oldMap(k), curMap(k)), oldMap(k), curMap(k))
        End If
    Next

    Set DxaCompareSnapshotMaps = details
End Function

Private Function DxaSnapshotComparableText(ByVal recordText As String) As String
    Dim f As Variant
    f = DxaSplitSnapshotFields(recordText)
    If UBound(f) < 10 Then
        DxaSnapshotComparableText = recordText
    Else
        DxaSnapshotComparableText = f(6) & Chr$(30) & f(7) & Chr$(30) & f(9) & Chr$(30) & f(10)
    End If
End Function

Private Function DxaDetectChangeType(ByVal oldRecord As String, ByVal newRecord As String) As String
    Dim o As Variant, n As Variant
    o = DxaSplitSnapshotFields(oldRecord)
    n = DxaSplitSnapshotFields(newRecord)

    If UBound(o) >= 10 And UBound(n) >= 10 Then
        If o(6) <> n(6) Then DxaDetectChangeType = "�����ύX": Exit Function
        If o(7) <> n(7) Then DxaDetectChangeType = "�l�ύX": Exit Function
        If o(9) <> n(9) Then DxaDetectChangeType = "�����N�ύX": Exit Function
        If o(10) <> n(10) Then DxaDetectChangeType = "�R�����g�ύX": Exit Function
    End If
    DxaDetectChangeType = "�ύX"
End Function

Private Function DxaBuildChangeDetail(ByVal key As String, ByVal changeType As String, ByVal oldRecord As String, ByVal newRecord As String) As Variant
    Dim baseRecord As String
    If Len(newRecord) > 0 Then baseRecord = newRecord Else baseRecord = oldRecord

    Dim b As Variant, o As Variant, n As Variant
    b = DxaSplitSnapshotFields(baseRecord)
    If Len(oldRecord) > 0 Then o = DxaSplitSnapshotFields(oldRecord) Else o = DxaEmptySnapshotFields()
    If Len(newRecord) > 0 Then n = DxaSplitSnapshotFields(newRecord) Else n = DxaEmptySnapshotFields()

    Dim oldValue As String, newValue As String
    oldValue = DxaDisplayValueFromFields(o)
    newValue = DxaDisplayValueFromFields(n)

    DxaBuildChangeDetail = Array( _
        key, _
        changeType, _
        DxaUnesc(CStr(b(0))), _
        DxaUnesc(CStr(b(1))), _
        CLng(Val(b(2))), _
        CLng(Val(b(3))), _
        DxaUnesc(CStr(b(4))), _
        DxaUnesc(CStr(b(5))), _
        oldValue, _
        newValue _
    )
End Function

Private Function DxaEmptySnapshotFields() As Variant
    DxaEmptySnapshotFields = Array("", "", "0", "0", "", "", "", "", "", "", "")
End Function

Private Function DxaDisplayValueFromFields(ByVal f As Variant) As String
    If UBound(f) < 10 Then Exit Function
    If Len(DxaUnesc(CStr(f(6)))) > 0 Then
        DxaDisplayValueFromFields = DxaUnesc(CStr(f(6)))
    ElseIf Len(DxaUnesc(CStr(f(7)))) > 0 Then
        DxaDisplayValueFromFields = DxaUnesc(CStr(f(7)))
    ElseIf Len(DxaUnesc(CStr(f(9)))) > 0 Then
        DxaDisplayValueFromFields = DxaUnesc(CStr(f(9)))
    ElseIf Len(DxaUnesc(CStr(f(10)))) > 0 Then
        DxaDisplayValueFromFields = DxaUnesc(CStr(f(10)))
    End If
End Function

Private Sub DxaOutputChangeHistoryWorkbook(ByVal sourceWb As Workbook, ByVal details As Collection)
    Dim outWb As Workbook
    Set outWb = Workbooks.Add(xlWBATWorksheet)

    Dim wsSummary As Worksheet
    Set wsSummary = outWb.Worksheets(1)
    wsSummary.Name = "�ύX����\�t�p"

    Dim wsDetail As Worksheet
    Set wsDetail = outWb.Worksheets.Add(After:=wsSummary)
    wsDetail.Name = "�ύX�ڍ�"

    DxaWriteChangeDetailSheet sourceWb, wsDetail, details
    DxaWriteChangeSummarySheet wsSummary, details

    wsSummary.Activate
End Sub

Private Sub DxaWriteChangeDetailSheet(ByVal sourceWb As Workbook, ByVal ws As Worksheet, ByVal details As Collection)
    ws.Range("A1:J1").Value = Array("No", "�ΏۃV�[�g", "�Z��", "�s", "�񌩏o��", "�Ώ�", "�ύX���", "�ύX�O", "�ύX��", "�ύX���e")
    ws.Range("A1:J1").Font.Bold = True

    Dim i As Long
    For i = 1 To details.Count
        Dim d As Variant
        d = details(i)
        ws.Cells(i + 1, 1).Value = i
        ws.Cells(i + 1, 2).Value = d(2)
        ws.Cells(i + 1, 3).Value = d(3)
        ws.Cells(i + 1, 4).Value = d(4)
        ws.Cells(i + 1, 5).Value = d(6)
        ws.Cells(i + 1, 6).Value = d(7)
        ws.Cells(i + 1, 7).Value = d(1)
        ws.Cells(i + 1, 8).Value = d(8)
        ws.Cells(i + 1, 9).Value = d(9)
        ws.Cells(i + 1, 10).Value = DxaBuildDetailText(d)

        On Error Resume Next
        If Len(sourceWb.FullName) > 0 Then
            ws.Hyperlinks.Add Anchor:=ws.Cells(i + 1, 3), Address:=sourceWb.FullName, SubAddress:="'" & d(2) & "'!" & d(3), TextToDisplay:=d(3)
        End If
        On Error GoTo 0
    Next

    ws.Columns("A:J").AutoFit
    ws.Range("A1:J1").AutoFilter
End Sub

Private Sub DxaWriteChangeSummarySheet(ByVal ws As Worksheet, ByVal details As Collection)
    ws.Range("A1:E1").Value = Array("No", "�ύX��", "�ΏۃV�[�g", "�Ώ�", "�ύX���e")
    ws.Range("A1:E1").Font.Bold = True

    Dim groups As Object
    Set groups = CreateObject("Scripting.Dictionary")

    Dim i As Long
    For i = 1 To details.Count
        Dim d As Variant
        d = details(i)
        Dim gKey As String
        gKey = d(2) & "|" & CStr(d(4))
        If Not groups.Exists(gKey) Then
            groups(gKey) = DxaNewSummaryGroup(d)
        Else
            groups(gKey) = DxaAppendSummaryGroup(groups(gKey), d)
        End If
    Next

    Dim r As Long
    r = 2
    Dim k As Variant
    For Each k In groups.Keys
        Dim g As Variant
        g = Split(CStr(groups(k)), Chr$(31))
        ws.Cells(r, 1).Value = r - 1
        ws.Cells(r, 2).Value = Date
        ws.Cells(r, 3).Value = g(0)
        ws.Cells(r, 4).Value = g(2)
        ws.Cells(r, 5).Value = DxaBuildSummaryText(g)
        r = r + 1
    Next

    ws.Columns("A:E").AutoFit
    ws.Range("A1:E1").AutoFilter
End Sub

Private Function DxaNewSummaryGroup(ByVal d As Variant) As String
    DxaNewSummaryGroup = d(2) & Chr$(31) & CStr(d(4)) & Chr$(31) & d(7) & Chr$(31) & d(6) & Chr$(31) & d(1) & Chr$(31) & d(8) & Chr$(31) & d(9)
End Function

Private Function DxaAppendSummaryGroup(ByVal groupText As String, ByVal d As Variant) As String
    Dim g As Variant
    g = Split(groupText, Chr$(31))
    g(3) = DxaAppendUniqueText(CStr(g(3)), CStr(d(6)))
    g(4) = DxaAppendUniqueText(CStr(g(4)), CStr(d(1)))
    If Len(CStr(g(5))) = 0 Then g(5) = d(8)
    If Len(CStr(g(6))) = 0 Then g(6) = d(9)
    DxaAppendSummaryGroup = Join(g, Chr$(31))
End Function

Private Function DxaBuildSummaryText(ByVal g As Variant) As String
    Dim target As String
    target = CStr(g(2))
    If Len(Trim$(target)) = 0 Then target = CStr(g(1)) & "�s��"

    Dim headers As String
    headers = CStr(g(3))

    Dim types As String
    types = CStr(g(4))

    Dim oldSample As String
    oldSample = CStr(g(5))

    Dim newSample As String
    newSample = CStr(g(6))

    If InStr(types, "�ǉ�") > 0 And InStr(types, "�ύX") = 0 And InStr(types, "�폜") = 0 Then
        DxaBuildSummaryText = target & "�Ɂu" & DxaShortText(newSample) & "�v��ǉ��B"
    ElseIf InStr(types, "�폜") > 0 And InStr(types, "�ύX") = 0 And InStr(types, "�ǉ�") = 0 Then
        DxaBuildSummaryText = target & "�́u" & DxaShortText(oldSample) & "�v���폜�B"
    ElseIf DxaCountList(headers) = 1 And Len(oldSample) > 0 And Len(newSample) > 0 Then
        DxaBuildSummaryText = target & "��" & headers & "���u" & DxaShortText(oldSample) & "�v����u" & DxaShortText(newSample) & "�v�ɕύX�B"
    Else
        DxaBuildSummaryText = target & "��" & headers & "��ύX�B"
    End If
End Function

Private Function DxaBuildDetailText(ByVal d As Variant) As String
    Select Case CStr(d(1))
        Case "�ǉ�"
            DxaBuildDetailText = d(7) & "��" & d(6) & "�Ɂu" & DxaShortText(d(9)) & "�v��ǉ��B"
        Case "�폜"
            DxaBuildDetailText = d(7) & "��" & d(6) & "����u" & DxaShortText(d(8)) & "�v���폜�B"
        Case Else
            DxaBuildDetailText = d(7) & "��" & d(6) & "���u" & DxaShortText(d(8)) & "�v����u" & DxaShortText(d(9)) & "�v�ɕύX�B"
    End Select
End Function

Private Function DxaShortText(ByVal text As String) As String
    Dim s As String
    s = Replace(CStr(text), vbCr, " ")
    s = Replace(s, vbLf, " ")
    s = Trim$(s)
    If Len(s) > 80 Then s = Left$(s, 80) & "..."
    DxaShortText = s
End Function

Private Function DxaAppendUniqueText(ByVal baseText As String, ByVal addText As String) As String
    If Len(Trim$(addText)) = 0 Then
        DxaAppendUniqueText = baseText
    ElseIf Len(Trim$(baseText)) = 0 Then
        DxaAppendUniqueText = addText
    ElseIf InStr(1, "," & baseText & ",", "," & addText & ",", vbTextCompare) > 0 Then
        DxaAppendUniqueText = baseText
    Else
        DxaAppendUniqueText = baseText & "," & addText
    End If
End Function

Private Function DxaCountList(ByVal text As String) As Long
    If Len(Trim$(text)) = 0 Then Exit Function
    DxaCountList = UBound(Split(text, ",")) + 1
End Function

Private Function DxaJoinSnapshotFields(ByVal values As Variant) As String
    Dim i As Long
    Dim s As String
    For i = LBound(values) To UBound(values)
        If i > LBound(values) Then s = s & vbTab
        s = s & CStr(values(i))
    Next
    DxaJoinSnapshotFields = s
End Function

Private Function DxaSplitSnapshotFields(ByVal recordText As String) As Variant
    DxaSplitSnapshotFields = Split(CStr(recordText), vbTab)
End Function

Private Function DxaEsc(ByVal text As String) As String
    Dim s As String
    s = CStr(text)
    s = Replace(s, "\", "\\")
    s = Replace(s, vbCrLf, "\n")
    s = Replace(s, vbCr, "\n")
    s = Replace(s, vbLf, "\n")
    s = Replace(s, vbTab, "\t")
    s = Replace(s, Chr$(30), "\u001e")
    DxaEsc = s
End Function

Private Function DxaUnesc(ByVal text As String) As String
    Dim s As String
    s = CStr(text)

    Dim i As Long
    Dim ch As String
    Dim nx As String
    Dim result As String

    i = 1
    Do While i <= Len(s)
        ch = Mid$(s, i, 1)
        If ch = "\" And i < Len(s) Then
            nx = Mid$(s, i + 1, 1)
            Select Case nx
                Case "n"
                    result = result & vbLf
                    i = i + 2
                Case "t"
                    result = result & vbTab
                    i = i + 2
                Case "\"
                    result = result & "\"
                    i = i + 2
                Case "u"
                    If Mid$(s, i + 1, 5) = "u001e" Then
                        result = result & Chr$(30)
                        i = i + 6
                    Else
                        result = result & ch
                        i = i + 1
                    End If
                Case Else
                    result = result & ch
                    i = i + 1
            End Select
        Else
            result = result & ch
            i = i + 1
        End If
    Loop

    DxaUnesc = result
End Function

Private Sub DxaWriteTextUtf8(ByVal path As String, ByVal text As String)
    Dim stm As Object
    Set stm = CreateObject("ADODB.Stream")
    stm.Type = 2
    stm.Charset = "utf-8"
    stm.Open
    stm.WriteText text
    stm.SaveToFile path, 2
    stm.Close
End Sub

Private Function DxaReadTextUtf8(ByVal path As String) As String
    Dim stm As Object
    Set stm = CreateObject("ADODB.Stream")
    stm.Type = 2
    stm.Charset = "utf-8"
    stm.Open
    stm.LoadFromFile path
    DxaReadTextUtf8 = stm.ReadText
    stm.Close
End Function

Private Function DxaFileExists(ByVal path As String) As Boolean
    On Error Resume Next
    DxaFileExists = (Len(Dir$(path, vbNormal + vbHidden + vbSystem)) > 0)
End Function

Private Sub DxaEnsureFolder(ByVal folderPath As String)
    On Error Resume Next
    Dim fso As Object
    Set fso = CreateObject("Scripting.FileSystemObject")
    If Not fso.FolderExists(folderPath) Then fso.CreateFolder folderPath
End Sub

Private Sub DxaCleanupOldChangeSnapshots()
    On Error Resume Next
    If gDxaCleanupDone Then Exit Sub
    gDxaCleanupDone = True
    Dim dirPath As String
    dirPath = DxaChangeSnapshotDir()
    Dim f As String
    f = Dir$(dirPath & "\*.tsv")
    Do While Len(f) > 0
        Dim p As String
        p = dirPath & "\" & f
        If DateDiff("d", FileDateTime(p), Now) >= 1 Then Kill p
        f = Dir$()
    Loop
End Sub

Private Sub DxaDeleteCurrentSessionSnapshots()
    On Error Resume Next
    If Len(gDxaSessionId) = 0 Then Exit Sub
    Dim dirPath As String
    dirPath = DxaChangeSnapshotDir()
    Dim f As String
    f = Dir$(dirPath & "\" & gDxaSessionId & "_*.tsv")
    Do While Len(f) > 0
        Kill dirPath & "\" & f
        f = Dir$()
    Loop
End Sub

Private Function DxaSimpleHash(ByVal text As String) As String
    Dim h As Double
    Dim i As Long
    Dim code As Long
    h = 5381
    For i = 1 To Len(text)
        code = AscW(Mid$(text, i, 1))
        If code < 0 Then code = code + 65536
        h = h * 33 + code
        h = h - Fix(h / 2147483647#) * 2147483647#
    Next
    DxaSimpleHash = Hex$(CLng(h))
End Function

Private Function DxaColumnLetter(ByVal col As Long) As String
    DxaColumnLetter = Split(Cells(1, col).Address(False, False), "1")(0)
End Function

'============================================================
' �\�L�h��`�F�b�N
'============================================================
Public Sub DxaCheckNotationVariants(ByVal control As Object)
    On Error GoTo EH

    Dim wb As Workbook
    Set wb = ActiveWorkbook
    If wb Is Nothing Then Exit Sub

    Dim groups As Object
    Set groups = DxaBuildNotationGroups()
    If groups.Count = 0 Then
        MsgBox "�\�L�h��`�F�b�N�p�̎�������ł��B", vbExclamation, "DelaxTools"
        Exit Sub
    End If

    Application.ScreenUpdating = False
    Application.StatusBar = "DelaxTools: �\�L�h����`�F�b�N���Ă��܂�..."

    Dim records As Collection
    Set records = New Collection

    Dim counts As Object
    Set counts = CreateObject("Scripting.Dictionary")

    Dim found As Object
    Set found = CreateObject("Scripting.Dictionary")

    Dim ws As Worksheet
    For Each ws In wb.Worksheets
        DxaScanNotationWorksheet ws, groups, records, counts, found
    Next

    Dim inconsistent As Object
    Set inconsistent = DxaBuildInconsistentNotationGroups(groups, found)

    DxaOutputNotationCheckWorkbook wb, groups, records, counts, inconsistent

    Application.StatusBar = False
    Application.ScreenUpdating = True

    If inconsistent.Count = 0 Then
        MsgBox "�\�L�h��͌��o����܂���ł����B���ʃu�b�N���쐬���܂����B", vbInformation, "DelaxTools"
    Else
        MsgBox "�\�L�h��`�F�b�N���������܂����B���o�O���[�v��: " & inconsistent.Count, vbInformation, "DelaxTools"
    End If
    Exit Sub
EH:
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "�\�L�h��`�F�b�N�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DelaxTools"
End Sub

Private Function DxaBuildNotationGroups() As Object
    Dim groups As Object
    Set groups = CreateObject("Scripting.Dictionary")

    DxaAddNotationGroup groups, "server", "�T�[�o�[", "�T�[�o�[", "�T�[�o", "server", "Server", "SERVER"
    DxaAddNotationGroup groups, "user", "���[�U�[", "���[�U�[", "���[�U", "user", "User", "USER"
    DxaAddNotationGroup groups, "computer", "�R���s���[�^�[", "�R���s���[�^�[", "�R���s���[�^", "PC", "�p�\�R��"
    DxaAddNotationGroup groups, "printer", "�v�����^�[", "�v�����^�[", "�v�����^"
    DxaAddNotationGroup groups, "folder", "�t�H���_�[", "�t�H���_�[", "�t�H���_"
    DxaAddNotationGroup groups, "browser", "�u���E�U�[", "�u���E�U�[", "�u���E�U"
    DxaAddNotationGroup groups, "driver", "�h���C�o�[", "�h���C�o�[", "�h���C�o"
    DxaAddNotationGroup groups, "viewer", "�r���[�A�[", "�r���[�A�[", "�r���[�A"
    DxaAddNotationGroup groups, "parameter", "�p�����[�^�[", "�p�����[�^�[", "�p�����[�^"
    DxaAddNotationGroup groups, "member", "�����o�[", "�����o�[", "�����o"
    DxaAddNotationGroup groups, "data", "�f�[�^", "�f�[�^", "�f�[�^�["
    DxaAddNotationGroup groups, "database", "�f�[�^�x�[�X", "�f�[�^�x�[�X", "DB", "�c�a"
    DxaAddNotationGroup groups, "id", "ID", "ID", "�h�c", "Id", "id"
    DxaAddNotationGroup groups, "api", "API", "API", "�`�o�h", "Api", "api"
    DxaAddNotationGroup groups, "url", "URL", "URL", "�t�q�k", "Url", "url"
    DxaAddNotationGroup groups, "csv", "CSV", "CSV", "�b�r�u", "Csv", "csv"
    DxaAddNotationGroup groups, "pdf", "PDF", "PDF", "�o�c�e", "Pdf", "pdf"
    DxaAddNotationGroup groups, "excel", "Excel", "Excel", "EXCEL", "�G�N�Z��"
    DxaAddNotationGroup groups, "mail", "���[��", "���[��", "E���[��", "E-Mail", "e-mail", "Email", "email"
    DxaAddNotationGroup groups, "login", "���O�C��", "���O�C��", "���O�I��", "�T�C���C��"
    DxaAddNotationGroup groups, "logout", "���O�A�E�g", "���O�A�E�g", "���O�I�t", "�T�C���A�E�g"
    DxaAddNotationGroup groups, "password", "�p�X���[�h", "�p�X���[�h", "PW", "�o�v", "Password", "password"
    DxaAddNotationGroup groups, "message", "���b�Z�[�W", "���b�Z�[�W", "���b�Z�[�W�[", "MSG", "�l�r�f"
    DxaAddNotationGroup groups, "error", "�G���[", "�G���[", "�G���|", "ERROR", "Error", "error"
    DxaAddNotationGroup groups, "backup", "�o�b�N�A�b�v", "�o�b�N�A�b�v", "�o�b�NUP", "�o�b�N�A�b�v�f�[�^"
    DxaAddNotationGroup groups, "master", "�}�X�^�[", "�}�X�^�[", "�}�X�^"
    DxaAddNotationGroup groups, "manager", "�}�l�[�W���[", "�}�l�[�W���[", "�}�l�[�W��"
    DxaAddNotationGroup groups, "center", "�Z���^�[", "�Z���^�[", "�Z���^"
    DxaAddNotationGroup groups, "check", "�`�F�b�N", "�`�F�b�N", "�m�F"
    DxaAddNotationGroup groups, "delete", "�폜", "�폜", "����", "���"
    DxaAddNotationGroup groups, "update", "�X�V", "�X�V", "�A�b�v�f�[�g", "�C��"
    DxaAddNotationGroup groups, "create", "�쐬", "�쐬", "����", "���"
    DxaAddNotationGroup groups, "register", "�o�^", "�o�^", "�ǉ�"
    DxaAddNotationGroup groups, "output", "�o��", "�o��", "�G�N�X�|�[�g", "Export", "export"
    DxaAddNotationGroup groups, "input", "����", "����", "�C���|�[�g", "Import", "import"

    DxaLoadUserNotationDictionary groups
    Set DxaBuildNotationGroups = groups
End Function

Private Sub DxaAddNotationGroup(ByVal groups As Object, ByVal groupId As String, ByVal preferred As String, ParamArray variants() As Variant)
    Dim d As Object
    Set d = CreateObject("Scripting.Dictionary")
    d("preferred") = CStr(preferred)
    d("variants") = DxaSortVariantsByLength(variants)
    If groups.Exists(CStr(groupId)) Then
        Set groups(CStr(groupId)) = d
    Else
        groups.Add CStr(groupId), d
    End If
End Sub

Private Function DxaSortVariantsByLength(ByVal variants As Variant) As Variant
    Dim arr() As String
    Dim i As Long
    ReDim arr(LBound(variants) To UBound(variants))
    For i = LBound(variants) To UBound(variants)
        arr(i) = CStr(variants(i))
    Next

    Dim j As Long, tmp As String
    For i = LBound(arr) To UBound(arr) - 1
        For j = i + 1 To UBound(arr)
            If Len(arr(j)) > Len(arr(i)) Then
                tmp = arr(i): arr(i) = arr(j): arr(j) = tmp
            End If
        Next
    Next
    DxaSortVariantsByLength = arr
End Function

Private Sub DxaLoadUserNotationDictionary(ByVal groups As Object)
    On Error Resume Next
    Dim path As String
    path = DxaNotationDictionaryPath()
    If Len(Dir$(path)) = 0 Then Exit Sub

    Dim text As String
    text = DxaReadTextUtf8(path)
    If Len(text) = 0 Then Exit Sub

    Dim lines As Variant
    lines = Split(Replace(text, vbCrLf, vbLf), vbLf)

    Dim i As Long
    For i = LBound(lines) To UBound(lines)
        Dim line As String
        line = Trim$(CStr(lines(i)))
        If Len(line) = 0 Then GoTo ContinueLine
        If Left$(line, 1) = "#" Then GoTo ContinueLine

        Dim parts As Variant
        parts = Split(line, ",")
        If UBound(parts) >= 1 Then
            Dim preferred As String
            preferred = Trim$(CStr(parts(0)))
            If Len(preferred) > 0 Then
                Dim v() As Variant
                ReDim v(0 To UBound(parts))
                Dim j As Long
                v(0) = preferred
                For j = 1 To UBound(parts)
                    v(j) = Trim$(CStr(parts(j)))
                Next
                DxaAddNotationGroup groups, "user_" & CStr(i), preferred, v
            End If
        End If
ContinueLine:
    Next
End Sub

Private Function DxaNotationDictionaryPath() As String
    DxaNotationDictionaryPath = Environ$("APPDATA") & "\DelaxTools\notation_variants.csv"
End Function

Private Sub DxaScanNotationWorksheet(ByVal ws As Worksheet, ByVal groups As Object, ByVal records As Collection, ByVal counts As Object, ByVal found As Object)
    On Error Resume Next
    If Application.WorksheetFunction.CountA(ws.Cells) > 0 Then
        Dim rng As Range
        Set rng = ws.UsedRange
        If Not rng Is Nothing Then
            Dim c As Range
            For Each c In rng.Cells
                If Not IsError(c.Value) Then
                    Dim text As String
                    text = CStr(c.Value)
                    If Len(text) > 0 Then DxaCollectNotationHits groups, records, counts, found, ws.Name, c.Address(False, False), "�Z��", text
                End If
            Next
        End If
    End If

    Dim shp As Shape
    For Each shp In ws.Shapes
        Dim s As String
        s = ""
        On Error Resume Next
        If shp.TextFrame2.HasText Then s = shp.TextFrame2.TextRange.Text
        If Len(s) = 0 Then
            If shp.TextFrame.HasText Then s = shp.TextFrame.Characters.Text
        End If
        On Error GoTo 0
        If Len(s) > 0 Then DxaCollectNotationHits groups, records, counts, found, ws.Name, shp.Name, "�}�`", s
    Next
End Sub

Private Sub DxaCollectNotationHits(ByVal groups As Object, ByVal records As Collection, ByVal counts As Object, ByVal found As Object, ByVal sheetName As String, ByVal location As String, ByVal kind As String, ByVal text As String)
    Dim gKey As Variant
    For Each gKey In groups.Keys
        Dim g As Object
        Set g = groups(gKey)
        Dim vars As Variant
        vars = g("variants")

        Dim i As Long
        For i = LBound(vars) To UBound(vars)
            Dim variantText As String
            variantText = CStr(vars(i))
            If Len(variantText) > 0 Then
                If DxaContainsNotationVariant(text, variantText) Then
                    Dim countKey As String
                    countKey = CStr(gKey) & Chr$(31) & variantText
                    If counts.Exists(countKey) Then counts(countKey) = CLng(counts(countKey)) + 1 Else counts(countKey) = 1
                    found(countKey) = True
                    records.Add Array(CStr(gKey), variantText, CStr(g("preferred")), sheetName, location, kind, DxaShortText(text))
                End If
            End If
        Next
    Next
End Sub

Private Function DxaContainsNotationVariant(ByVal text As String, ByVal variantText As String) As Boolean
    Dim pos As Long
    pos = 1
    Do
        pos = InStr(pos, text, variantText, vbTextCompare)
        If pos = 0 Then Exit Function
        If DxaIsValidNotationHit(text, variantText, pos) Then
            DxaContainsNotationVariant = True
            Exit Function
        End If
        pos = pos + Len(variantText)
    Loop
End Function

Private Function DxaIsValidNotationHit(ByVal text As String, ByVal variantText As String, ByVal pos As Long) As Boolean
    Dim beforeCh As String, afterCh As String
    beforeCh = "": afterCh = ""
    If pos > 1 Then beforeCh = Mid$(text, pos - 1, 1)
    If pos + Len(variantText) <= Len(text) Then afterCh = Mid$(text, pos + Len(variantText), 1)

    If DxaIsAsciiWord(variantText) Then
        If DxaIsAsciiWordChar(beforeCh) Then Exit Function
        If DxaIsAsciiWordChar(afterCh) Then Exit Function
    End If

    If Right$(variantText, 1) <> "�[" And Right$(variantText, 1) <> "�" Then
        If afterCh = "�[" Or afterCh = "�" Then Exit Function
    End If

    DxaIsValidNotationHit = True
End Function

Private Function DxaIsAsciiWord(ByVal s As String) As Boolean
    Dim i As Long, code As Long
    If Len(s) = 0 Then Exit Function
    For i = 1 To Len(s)
        code = AscW(Mid$(s, i, 1))
        If Not ((code >= 48 And code <= 57) Or (code >= 65 And code <= 90) Or (code >= 97 And code <= 122) Or code = 95) Then Exit Function
    Next
    DxaIsAsciiWord = True
End Function

Private Function DxaIsAsciiWordChar(ByVal s As String) As Boolean
    If Len(s) = 0 Then Exit Function
    DxaIsAsciiWordChar = DxaIsAsciiWord(Left$(s, 1))
End Function

Private Function DxaBuildInconsistentNotationGroups(ByVal groups As Object, ByVal found As Object) As Object
    Dim inconsistent As Object
    Set inconsistent = CreateObject("Scripting.Dictionary")

    Dim gKey As Variant
    For Each gKey In groups.Keys
        Dim g As Object
        Set g = groups(gKey)
        Dim vars As Variant
        vars = g("variants")
        Dim foundCount As Long
        Dim i As Long
        For i = LBound(vars) To UBound(vars)
            If found.Exists(CStr(gKey) & Chr$(31) & CStr(vars(i))) Then foundCount = foundCount + 1
        Next
        If foundCount >= 2 Then inconsistent(CStr(gKey)) = True
    Next

    Set DxaBuildInconsistentNotationGroups = inconsistent
End Function

Private Sub DxaOutputNotationCheckWorkbook(ByVal sourceWb As Workbook, ByVal groups As Object, ByVal records As Collection, ByVal counts As Object, ByVal inconsistent As Object)
    Dim outWb As Workbook
    Set outWb = Workbooks.Add(xlWBATWorksheet)

    Dim wsSummary As Worksheet
    Set wsSummary = outWb.Worksheets(1)
    wsSummary.Name = "�\�L�h��`�F�b�N"

    Dim wsDetail As Worksheet
    Set wsDetail = outWb.Worksheets.Add(After:=wsSummary)
    wsDetail.Name = "���o�ڍ�"

    DxaWriteNotationSummarySheet wsSummary, groups, counts, inconsistent
    DxaWriteNotationDetailSheet sourceWb, wsDetail, records, inconsistent

    wsSummary.Activate
End Sub

Private Sub DxaWriteNotationSummarySheet(ByVal ws As Worksheet, ByVal groups As Object, ByVal counts As Object, ByVal inconsistent As Object)
    ws.Range("A1:F1").Value = Array("No", "�����\�L", "���o�\�L", "����", "����", "���l")
    ws.Range("A1:F1").Font.Bold = True

    Dim r As Long
    r = 2

    If inconsistent.Count = 0 Then
        ws.Cells(r, 1).Value = 1
        ws.Cells(r, 5).Value = "�\�L�h��Ȃ�"
        ws.Cells(r, 6).Value = "����O���[�v���ŕ����\�L�͌��o����܂���ł����B"
    Else
        Dim gKey As Variant
        For Each gKey In groups.Keys
            If inconsistent.Exists(CStr(gKey)) Then
                Dim g As Object
                Set g = groups(gKey)
                Dim vars As Variant
                vars = g("variants")
                Dim i As Long
                For i = LBound(vars) To UBound(vars)
                    Dim countKey As String
                    countKey = CStr(gKey) & Chr$(31) & CStr(vars(i))
                    If counts.Exists(countKey) Then
                        ws.Cells(r, 1).Value = r - 1
                        ws.Cells(r, 2).Value = CStr(g("preferred"))
                        ws.Cells(r, 3).Value = CStr(vars(i))
                        ws.Cells(r, 4).Value = CLng(counts(countKey))
                        If StrComp(CStr(vars(i)), CStr(g("preferred")), vbTextCompare) = 0 Then
                            ws.Cells(r, 5).Value = "�����\�L"
                        Else
                            ws.Cells(r, 5).Value = "�h����"
                        End If
                        ws.Cells(r, 6).Value = "�����\�L�ɓ��ꂷ�邩�m�F���Ă��������B"
                        r = r + 1
                    End If
                Next
            End If
        Next
    End If

    ws.Columns("A:F").AutoFit
    ws.Range("A1:F1").AutoFilter
End Sub

Private Sub DxaWriteNotationDetailSheet(ByVal sourceWb As Workbook, ByVal ws As Worksheet, ByVal records As Collection, ByVal inconsistent As Object)
    ws.Range("A1:H1").Value = Array("No", "�ΏۃV�[�g", "�ꏊ", "���", "���o�\�L", "�����\�L", "���Ӄe�L�X�g", "�m�F����")
    ws.Range("A1:H1").Font.Bold = True

    Dim r As Long
    r = 2

    Dim i As Long
    For i = 1 To records.Count
        Dim rec As Variant
        rec = records(i)
        If inconsistent.Exists(CStr(rec(0))) Then
            ws.Cells(r, 1).Value = r - 1
            ws.Cells(r, 2).Value = rec(3)
            ws.Cells(r, 3).Value = rec(4)
            ws.Cells(r, 4).Value = rec(5)
            ws.Cells(r, 5).Value = rec(1)
            ws.Cells(r, 6).Value = rec(2)
            ws.Cells(r, 7).Value = rec(6)
            ws.Cells(r, 8).Value = "�v�m�F"

            On Error Resume Next
            If CStr(rec(5)) = "�Z��" And Len(sourceWb.FullName) > 0 Then
                ws.Hyperlinks.Add Anchor:=ws.Cells(r, 3), Address:=sourceWb.FullName, SubAddress:="'" & rec(3) & "'!" & rec(4), TextToDisplay:=rec(4)
            End If
            On Error GoTo 0
            r = r + 1
        End If
    Next

    If r = 2 Then
        ws.Cells(2, 1).Value = 1
        ws.Cells(2, 8).Value = "�\�L�h��Ȃ�"
    End If

    ws.Columns("A:H").AutoFit
    ws.Range("A1:H1").AutoFilter
End Sub

' ============================================================
' �d��Excel�f�f
' ���u�b�N�ɂ̓V�[�g��ǉ������A�f�f���ʂ�ʃu�b�N�ɏo�͂��܂��B
' ============================================================
Public Sub DxaDiagnoseHeavyWorkbook(ByVal control As Object)
    On Error GoTo EH

    Dim srcWb As Workbook
    Set srcWb = ActiveWorkbook
    If srcWb Is Nothing Then Exit Sub
    If srcWb.Name = ThisWorkbook.Name Then
        MsgBox "�f�f�Ώۂ̃u�b�N���A�N�e�B�u�ɂ��Ă�����s���Ă��������B", vbExclamation, "DelaxTools"
        Exit Sub
    End If

    Dim reportWb As Workbook
    Dim wsSummary As Worksheet
    Dim wsDetail As Worksheet

    Application.ScreenUpdating = False
    Application.StatusBar = "DelaxTools: �d��Excel�f�f�����s���Ă��܂�..."

    Set reportWb = Application.Workbooks.Add(xlWBATWorksheet)
    Set wsSummary = reportWb.Worksheets(1)
    wsSummary.Name = "�d��Excel�f�f"
    Set wsDetail = reportWb.Worksheets.Add(After:=wsSummary)
    wsDetail.Name = "�f�f�ڍ�"

    DxaPrepareHeavySummarySheet wsSummary, srcWb
    DxaPrepareHeavyDetailSheet wsDetail

    Dim detailRow As Long
    detailRow = 2

    Dim totalFormula As Double
    Dim totalVolatile As Double
    Dim totalFormatConditions As Double
    Dim totalValidations As Double
    Dim totalShapes As Double
    Dim totalPictures As Double
    Dim totalHyperlinks As Double
    Dim totalComments As Double
    Dim totalPivotTables As Double
    Dim totalTables As Double
    Dim totalHiddenSheets As Double
    Dim totalBloatedUsedRange As Double
    Dim totalLargeSheets As Double

    Dim ws As Worksheet
    For Each ws In srcWb.Worksheets
        Application.StatusBar = "DelaxTools: �d��Excel�f�f�� - " & ws.Name

        Dim lastRow As Long
        Dim lastCol As Long
        Dim hasData As Boolean
        hasData = DxaGetActualLastCell(ws, lastRow, lastCol)

        Dim usedRows As Double
        Dim usedCols As Double
        Dim usedCells As Double
        usedRows = 0
        usedCols = 0
        usedCells = 0
        On Error Resume Next
        usedRows = CDbl(ws.UsedRange.Rows.Count)
        usedCols = CDbl(ws.UsedRange.Columns.Count)
        usedCells = CDbl(ws.UsedRange.CountLarge)
        On Error GoTo EH

        Dim actualCells As Double
        If hasData Then
            actualCells = CDbl(lastRow) * CDbl(lastCol)
        Else
            actualCells = 0
        End If

        Dim formulaCount As Double
        formulaCount = DxaCountSpecialCells(ws, xlCellTypeFormulas)
        totalFormula = totalFormula + formulaCount

        Dim volatileCount As Double
        volatileCount = DxaCountVolatileFormulas(ws)
        totalVolatile = totalVolatile + volatileCount

        Dim fcCount As Double
        fcCount = DxaCountFormatConditions(ws)
        totalFormatConditions = totalFormatConditions + fcCount

        Dim validationCount As Double
        validationCount = DxaCountSpecialCells(ws, xlCellTypeAllValidation)
        totalValidations = totalValidations + validationCount

        Dim shapeCount As Double
        shapeCount = DxaSafeShapeCount(ws)
        totalShapes = totalShapes + shapeCount

        Dim pictureCount As Double
        pictureCount = DxaSafePictureCount(ws)
        totalPictures = totalPictures + pictureCount

        Dim hyperlinkCount As Double
        hyperlinkCount = DxaSafeHyperlinkCount(ws)
        totalHyperlinks = totalHyperlinks + hyperlinkCount

        Dim commentCount As Double
        commentCount = DxaSafeCommentCount(ws)
        totalComments = totalComments + commentCount

        Dim pivotCount As Double
        pivotCount = DxaSafePivotCount(ws)
        totalPivotTables = totalPivotTables + pivotCount

        Dim tableCount As Double
        tableCount = DxaSafeTableCount(ws)
        totalTables = totalTables + tableCount

        If ws.Visible <> xlSheetVisible Then totalHiddenSheets = totalHiddenSheets + 1

        Dim usedRangeStatus As String
        Dim usedRangeReason As String
        usedRangeStatus = "OK"
        usedRangeReason = "�g�p�͈͂ɑ傫�Ȉُ�͌�����܂���B"
        If usedCells >= 1000000# Then
            usedRangeStatus = "����"
            usedRangeReason = "UsedRange���傫���ł��B�s�v�ȍs��ɏ������c���Ă���\��������܂��B"
            totalLargeSheets = totalLargeSheets + 1
        End If
        If hasData Then
            If (usedRows > lastRow + 1000) Or (usedCols > lastCol + 20) Then
                usedRangeStatus = "�x��"
                usedRangeReason = "���f�[�^�͈͂��UsedRange���L���ł��B���g�p�͈͂̃��Z�b�g���ł��B"
                totalBloatedUsedRange = totalBloatedUsedRange + 1
            End If
        End If

        DxaWriteHeavyDetail wsDetail, detailRow, "�V�[�g�T�v", ws.Name, "�\�����", DxaSheetVisibleText(ws), DxaStatusBySheetVisible(ws), "��\��/VeryHidden�V�[�g���s�v�ł���Ε\���܂��͍폜���������Ă��������B"
        DxaWriteHeavyDetail wsDetail, detailRow, "�g�p�͈�", ws.Name, "UsedRange", "�s=" & CStr(usedRows) & ", ��=" & CStr(usedCols) & ", �Z��=" & Format$(usedCells, "#,##0"), usedRangeStatus, usedRangeReason
        DxaWriteHeavyDetail wsDetail, detailRow, "���f�[�^�͈�", ws.Name, "�ŏI�Z��", IIf(hasData, "�s=" & CStr(lastRow) & ", ��=" & CStr(lastCol), "�f�[�^�Ȃ�"), "���", "UsedRange�Ǝ��f�[�^�͈͂̍����傫���ꍇ�AExcel���d���Ȃ錴���ɂȂ�܂��B"
        DxaWriteHeavyDetail wsDetail, detailRow, "����", ws.Name, "�����Z����", Format$(formulaCount, "#,##0"), DxaStatusByNumber(formulaCount, 10000, 50000), "�����������ꍇ�͌v�Z�����A�s�v�����A�l�\��t�����������Ă��������B"
        DxaWriteHeavyDetail wsDetail, detailRow, "�������֐�", ws.Name, "���茏��", Format$(volatileCount, "#,##0"), DxaStatusByNumber(volatileCount, 1, 100), "NOW/TODAY/RAND/OFFSET/INDIRECT�Ȃǂ͍Čv�Z���ׂ������Ȃ�ꍇ������܂��B"
        DxaWriteHeavyDetail wsDetail, detailRow, "�����t������", ws.Name, "����", Format$(fcCount, "#,##0"), DxaStatusByNumber(fcCount, 100, 1000), "�R�s�[�\��t���ŏ����t�����������B���Ă��Ȃ����m�F���Ă��������B"
        DxaWriteHeavyDetail wsDetail, detailRow, "���͋K��", ws.Name, "�ΏۃZ����", Format$(validationCount, "#,##0"), DxaStatusByNumber(validationCount, 5000, 50000), "���͋K������ʂɕ��������Ɠ��삪�d���Ȃ�ꍇ������܂��B"
        DxaWriteHeavyDetail wsDetail, detailRow, "�}�`/�摜", ws.Name, "�}�`=" & Format$(shapeCount, "#,##0"), "�摜=" & Format$(pictureCount, "#,##0"), DxaStatusByNumber(shapeCount, 100, 500), "�s�v�Ȑ}�`�A�����摜�A�\��t���摜���c���Ă��Ȃ����m�F���Ă��������B"
        DxaWriteHeavyDetail wsDetail, detailRow, "�����N/�R�����g", ws.Name, "�����N=" & Format$(hyperlinkCount, "#,##0"), "�R�����g=" & Format$(commentCount, "#,##0"), DxaStatusByNumber(hyperlinkCount + commentCount, 200, 1000), "�s�v�ȃ����N�A�R�����g�A�������c���Ă��Ȃ����m�F���Ă��������B"
        DxaWriteHeavyDetail wsDetail, detailRow, "�W�v�I�u�W�F�N�g", ws.Name, "�s�{�b�g=" & Format$(pivotCount, "#,##0"), "�e�[�u��=" & Format$(tableCount, "#,##0"), "���", "�s�{�b�g��e�[�u���������ꍇ�͍X�V�͈͂�L���b�V�����m�F���Ă��������B"
    Next ws

    Dim externalLinkCount As Double
    externalLinkCount = DxaCountExternalLinks(srcWb)

    Dim nameCount As Double
    Dim brokenNameCount As Double
    Dim externalNameCount As Double
    DxaCountNames srcWb, nameCount, brokenNameCount, externalNameCount

    Dim styleCount As Double
    styleCount = DxaSafeStyleCount(srcWb)

    Dim fileSizeText As String
    Dim fileSizeMB As Double
    fileSizeMB = DxaWorkbookFileSizeMB(srcWb)
    If fileSizeMB >= 0 Then
        fileSizeText = Format$(fileSizeMB, "0.00") & " MB"
    Else
        fileSizeText = "���ۑ��܂��͎擾�s��"
    End If

    Dim r As Long
    r = 5
    DxaWriteHeavySummary wsSummary, r, "�t�@�C���T�C�Y", DxaStatusByFileSize(fileSizeMB), fileSizeText, "�t�@�C���T�C�Y���傫���ꍇ�͉摜�A�����t�������A���g�p�͈́A�s�v�X�^�C�����m�F���Ă��������B"
    DxaWriteHeavySummary wsSummary, r, "�V�[�g��", DxaStatusByNumber(srcWb.Worksheets.Count, 30, 80), CStr(srcWb.Worksheets.Count), "�V�[�g���������ꍇ�͕s�v�V�[�g���\���V�[�g���m�F���Ă��������B"
    DxaWriteHeavySummary wsSummary, r, "��\���V�[�g��", DxaStatusByNumber(totalHiddenSheets, 1, 10), Format$(totalHiddenSheets, "#,##0"), "�s�v�Ȕ�\��/VeryHidden�V�[�g���Ȃ����m�F���Ă��������B"
    DxaWriteHeavySummary wsSummary, r, "UsedRange�����", DxaStatusByNumber(totalBloatedUsedRange, 1, 5), Format$(totalBloatedUsedRange, "#,##0"), "���f�[�^�͈͂��UsedRange���L���V�[�g�́A���g�p�͈̓��Z�b�g���ł��B"
    DxaWriteHeavySummary wsSummary, r, "��K��UsedRange�V�[�g", DxaStatusByNumber(totalLargeSheets, 1, 5), Format$(totalLargeSheets, "#,##0"), "�g�p�͈͂����ɑ傫���V�[�g�͏d���Ȃ錴���ł��B"
    DxaWriteHeavySummary wsSummary, r, "�����Z����", DxaStatusByNumber(totalFormula, 50000, 200000), Format$(totalFormula, "#,##0"), "�����������ꍇ�A�l�\��t���E�v�Z�͈͌��������������Ă��������B"
    DxaWriteHeavySummary wsSummary, r, "�������֐����萔", DxaStatusByNumber(totalVolatile, 1, 100), Format$(totalVolatile, "#,##0"), "�������֐��͍Čv�Z���ׂ��������߁A�K�v�����m�F���Ă��������B"
    DxaWriteHeavySummary wsSummary, r, "�����t��������", DxaStatusByNumber(totalFormatConditions, 500, 3000), Format$(totalFormatConditions, "#,##0"), "�����t�����������B���Ă���ꍇ�͐������Ă��������B"
    DxaWriteHeavySummary wsSummary, r, "���͋K���ΏۃZ����", DxaStatusByNumber(totalValidations, 10000, 100000), Format$(totalValidations, "#,##0"), "���͋K�����L�͈͂ɐݒ肳��Ă���ꍇ�͔͈͂��������Ă��������B"
    DxaWriteHeavySummary wsSummary, r, "�}�`��", DxaStatusByNumber(totalShapes, 200, 1000), Format$(totalShapes, "#,##0"), "�s�v�Ȑ}�`�ⓧ���I�u�W�F�N�g���Ȃ����m�F���Ă��������B"
    DxaWriteHeavySummary wsSummary, r, "�摜��", DxaStatusByNumber(totalPictures, 50, 200), Format$(totalPictures, "#,##0"), "�摜�������ꍇ�͈��k��s�v�摜�폜���������Ă��������B"
    DxaWriteHeavySummary wsSummary, r, "�O�������N��", DxaStatusByNumber(externalLinkCount, 1, 10), Format$(externalLinkCount, "#,##0"), "�s�v�ȊO�������N���c���Ă��Ȃ����m�F���Ă��������B"
    DxaWriteHeavySummary wsSummary, r, "���O��`��", DxaStatusByNumber(nameCount, 200, 1000), Format$(nameCount, "#,##0"), "�s�v�Ȗ��O��`�������Ă��Ȃ����m�F���Ă��������B"
    DxaWriteHeavySummary wsSummary, r, "�Q�Ɛ؂ꖼ�O��`��", DxaStatusByNumber(brokenNameCount, 1, 10), Format$(brokenNameCount, "#,##0"), "#REF!���܂ޖ��O��`�͍폜���ł��B"
    DxaWriteHeavySummary wsSummary, r, "�O���Q�Ɩ��O��`��", DxaStatusByNumber(externalNameCount, 1, 10), Format$(externalNameCount, "#,##0"), "���O��`���̊O���Q�Ƃ͊O�������N�x���̌����ɂȂ�ꍇ������܂��B"
    DxaWriteHeavySummary wsSummary, r, "�X�^�C����", DxaStatusByNumber(styleCount, 500, 2000), Format$(styleCount, "#,##0"), "�s�v�X�^�C�������B���Ă���ꍇ�A�t�@�C����剻�̌����ɂȂ�ꍇ������܂��B"

    wsSummary.Columns("A:D").AutoFit
    wsDetail.Columns("A:G").AutoFit
    wsSummary.Range("A4:D4").AutoFilter
    wsDetail.Range("A1:G1").AutoFilter
    wsSummary.Activate
    wsSummary.Range("A1").Select

    Application.StatusBar = False
    Application.ScreenUpdating = True

    MsgBox "�d��Excel�f�f���������܂����B���ʂ͕ʃu�b�N�ɏo�͂��܂����B", vbInformation, "DelaxTools"
    Exit Sub

EH:
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "�d��Excel�f�f�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DelaxTools"
End Sub

Private Sub DxaPrepareHeavySummarySheet(ByVal ws As Worksheet, ByVal srcWb As Workbook)
    ws.Range("A1").Value = "�d��Excel�f�f"
    ws.Range("A1").Font.Bold = True
    ws.Range("A1").Font.Size = 16
    ws.Range("A2").Value = "�Ώۃu�b�N"
    ws.Range("B2").Value = srcWb.Name
    ws.Range("A3").Value = "�f�f����"
    ws.Range("B3").Value = Now
    ws.Range("B3").NumberFormatLocal = "yyyy/mm/dd hh:mm:ss"
    ws.Range("A4:D4").Value = Array("�f�f����", "����", "����/�l", "�����Ή�")
    ws.Range("A4:D4").Font.Bold = True
End Sub

Private Sub DxaPrepareHeavyDetailSheet(ByVal ws As Worksheet)
    ws.Range("A1:G1").Value = Array("No", "�J�e�S��", "�V�[�g��", "�Ώ�", "�l1", "����", "�����Ή�")
    ws.Range("A1:G1").Font.Bold = True
End Sub

Private Sub DxaWriteHeavySummary(ByVal ws As Worksheet, ByRef rowNo As Long, ByVal itemName As String, ByVal statusText As String, ByVal valueText As String, ByVal recommendation As String)
    ws.Cells(rowNo, 1).Value = itemName
    ws.Cells(rowNo, 2).Value = statusText
    ws.Cells(rowNo, 3).Value = valueText
    ws.Cells(rowNo, 4).Value = recommendation
    DxaApplyStatusColor ws.Cells(rowNo, 2), statusText
    rowNo = rowNo + 1
End Sub

Private Sub DxaWriteHeavyDetail(ByVal ws As Worksheet, ByRef rowNo As Long, ByVal category As String, ByVal sheetName As String, ByVal targetName As String, ByVal valueText As String, ByVal statusText As String, ByVal recommendation As String)
    ws.Cells(rowNo, 1).Value = rowNo - 1
    ws.Cells(rowNo, 2).Value = category
    ws.Cells(rowNo, 3).Value = sheetName
    ws.Cells(rowNo, 4).Value = targetName
    ws.Cells(rowNo, 5).Value = valueText
    ws.Cells(rowNo, 6).Value = statusText
    ws.Cells(rowNo, 7).Value = recommendation
    DxaApplyStatusColor ws.Cells(rowNo, 6), statusText
    rowNo = rowNo + 1
End Sub

Private Sub DxaApplyStatusColor(ByVal cell As Range, ByVal statusText As String)
    On Error Resume Next
    Select Case statusText
        Case "�x��"
            cell.Interior.Color = RGB(255, 199, 206)
            cell.Font.Color = RGB(156, 0, 6)
        Case "����"
            cell.Interior.Color = RGB(255, 235, 156)
            cell.Font.Color = RGB(156, 101, 0)
        Case "OK"
            cell.Interior.Color = RGB(198, 239, 206)
            cell.Font.Color = RGB(0, 97, 0)
        Case Else
            cell.Interior.Color = RGB(217, 225, 242)
    End Select
End Sub

Private Function DxaStatusByNumber(ByVal value As Double, ByVal cautionThreshold As Double, ByVal warningThreshold As Double) As String
    If value >= warningThreshold Then
        DxaStatusByNumber = "�x��"
    ElseIf value >= cautionThreshold Then
        DxaStatusByNumber = "����"
    Else
        DxaStatusByNumber = "OK"
    End If
End Function

Private Function DxaStatusByFileSize(ByVal mb As Double) As String
    If mb < 0 Then
        DxaStatusByFileSize = "���"
    ElseIf mb >= 50 Then
        DxaStatusByFileSize = "�x��"
    ElseIf mb >= 10 Then
        DxaStatusByFileSize = "����"
    Else
        DxaStatusByFileSize = "OK"
    End If
End Function

Private Function DxaStatusBySheetVisible(ByVal ws As Worksheet) As String
    If ws.Visible = xlSheetVisible Then
        DxaStatusBySheetVisible = "OK"
    Else
        DxaStatusBySheetVisible = "����"
    End If
End Function

Private Function DxaSheetVisibleText(ByVal ws As Worksheet) As String
    Select Case ws.Visible
        Case xlSheetVisible
            DxaSheetVisibleText = "�\��"
        Case xlSheetHidden
            DxaSheetVisibleText = "��\��"
        Case xlSheetVeryHidden
            DxaSheetVisibleText = "VeryHidden"
        Case Else
            DxaSheetVisibleText = CStr(ws.Visible)
    End Select
End Function

Private Function DxaGetActualLastCell(ByVal ws As Worksheet, ByRef lastRow As Long, ByRef lastCol As Long) As Boolean
    On Error GoTo EH
    Dim c As Range
    Set c = ws.Cells.Find(What:="*", After:=ws.Range("A1"), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, MatchCase:=False)
    If c Is Nothing Then
        lastRow = 0
        lastCol = 0
        DxaGetActualLastCell = False
        Exit Function
    End If
    lastRow = c.Row
    Set c = ws.Cells.Find(What:="*", After:=ws.Range("A1"), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious, MatchCase:=False)
    lastCol = c.Column
    DxaGetActualLastCell = True
    Exit Function
EH:
    lastRow = 0
    lastCol = 0
    DxaGetActualLastCell = False
End Function

Private Function DxaCountSpecialCells(ByVal ws As Worksheet, ByVal cellType As Long) As Double
    On Error GoTo EH
    Dim rng As Range
    Set rng = ws.UsedRange.SpecialCells(cellType)
    DxaCountSpecialCells = CDbl(rng.CountLarge)
    Exit Function
EH:
    DxaCountSpecialCells = 0
End Function

Private Function DxaCountFormatConditions(ByVal ws As Worksheet) As Double
    On Error GoTo EH
    DxaCountFormatConditions = CDbl(ws.Cells.FormatConditions.Count)
    Exit Function
EH:
    DxaCountFormatConditions = 0
End Function

Private Function DxaSafeShapeCount(ByVal ws As Worksheet) As Double
    On Error Resume Next
    DxaSafeShapeCount = CDbl(ws.Shapes.Count)
End Function

Private Function DxaSafePictureCount(ByVal ws As Worksheet) As Double
    On Error GoTo EH
    Dim shp As Shape
    Dim n As Double
    For Each shp In ws.Shapes
        If shp.Type = msoPicture Or shp.Type = msoLinkedPicture Then n = n + 1
    Next shp
    DxaSafePictureCount = n
    Exit Function
EH:
    DxaSafePictureCount = 0
End Function

Private Function DxaSafeHyperlinkCount(ByVal ws As Worksheet) As Double
    On Error Resume Next
    DxaSafeHyperlinkCount = CDbl(ws.Hyperlinks.Count)
End Function

Private Function DxaSafeCommentCount(ByVal ws As Worksheet) As Double
    On Error Resume Next
    Dim n As Double
    n = 0
    n = n + CDbl(ws.Comments.Count)
    Err.Clear
    n = n + CDbl(ws.CommentsThreaded.Count)
    DxaSafeCommentCount = n
End Function

Private Function DxaSafePivotCount(ByVal ws As Worksheet) As Double
    On Error Resume Next
    DxaSafePivotCount = CDbl(ws.PivotTables.Count)
End Function

Private Function DxaSafeTableCount(ByVal ws As Worksheet) As Double
    On Error Resume Next
    DxaSafeTableCount = CDbl(ws.ListObjects.Count)
End Function

Private Function DxaSafeStyleCount(ByVal wb As Workbook) As Double
    On Error Resume Next
    DxaSafeStyleCount = CDbl(wb.Styles.Count)
End Function

Private Function DxaWorkbookFileSizeMB(ByVal wb As Workbook) As Double
    On Error GoTo EH
    If Len(wb.FullName) = 0 Then
        DxaWorkbookFileSizeMB = -1
    ElseIf Len(Dir$(wb.FullName)) = 0 Then
        DxaWorkbookFileSizeMB = -1
    Else
        DxaWorkbookFileSizeMB = CDbl(FileLen(wb.FullName)) / 1024# / 1024#
    End If
    Exit Function
EH:
    DxaWorkbookFileSizeMB = -1
End Function

Private Function DxaCountExternalLinks(ByVal wb As Workbook) As Double
    On Error GoTo EH
    Dim links As Variant
    links = wb.LinkSources(Type:=xlLinkTypeExcelLinks)
    If IsEmpty(links) Then
        DxaCountExternalLinks = 0
    Else
        DxaCountExternalLinks = CDbl(UBound(links) - LBound(links) + 1)
    End If
    Exit Function
EH:
    DxaCountExternalLinks = 0
End Function

Private Sub DxaCountNames(ByVal wb As Workbook, ByRef nameCount As Double, ByRef brokenNameCount As Double, ByRef externalNameCount As Double)
    On Error Resume Next
    Dim nm As Name
    Dim refText As String
    nameCount = 0
    brokenNameCount = 0
    externalNameCount = 0
    For Each nm In wb.Names
        nameCount = nameCount + 1
        Err.Clear
        refText = nm.RefersTo
        If InStr(1, refText, "#REF!", vbTextCompare) > 0 Then brokenNameCount = brokenNameCount + 1
        If InStr(1, refText, "[", vbTextCompare) > 0 And InStr(1, refText, "]", vbTextCompare) > 0 Then externalNameCount = externalNameCount + 1
    Next nm
End Sub

Private Function DxaCountVolatileFormulas(ByVal ws As Worksheet) As Double
    On Error GoTo EH
    Dim rng As Range
    Set rng = ws.UsedRange.SpecialCells(xlCellTypeFormulas)
    If rng Is Nothing Then
        DxaCountVolatileFormulas = 0
        Exit Function
    End If

    Dim volatileWords As Variant
    volatileWords = Array("NOW(", "TODAY(", "RAND(", "RANDBETWEEN(", "OFFSET(", "INDIRECT(", "CELL(", "INFO(")

    Dim total As Double
    Dim word As Variant
    For Each word In volatileWords
        total = total + DxaCountFormulaFindHits(rng, CStr(word))
    Next word
    DxaCountVolatileFormulas = total
    Exit Function
EH:
    DxaCountVolatileFormulas = 0
End Function

Private Function DxaCountFormulaFindHits(ByVal rng As Range, ByVal token As String) As Double
    On Error GoTo EH
    Dim firstAddress As String
    Dim c As Range
    Dim n As Double
    Set c = rng.Find(What:=token, After:=rng.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlNext, MatchCase:=False)
    If c Is Nothing Then
        DxaCountFormulaFindHits = 0
        Exit Function
    End If
    firstAddress = c.Address(External:=True)
    Do
        n = n + 1
        Set c = rng.FindNext(c)
        If c Is Nothing Then Exit Do
    Loop While c.Address(External:=True) <> firstAddress
    DxaCountFormulaFindHits = n
    Exit Function
EH:
    DxaCountFormulaFindHits = 0
End Function

'============================================================
' Backlog�K���g�`���[�g�x���@�\ v107
' Backlog����G�N�X�|�[�g�����K���g�`���[�g�����₷�����`���܂��B
' �z��`���FA�`L�񂪉ۑ���AM��ȍ~�����t�K���g
'============================================================
Public Sub DxaBacklogFormatGantt(ByVal control As Object)
    On Error GoTo EH

    Dim ws As Worksheet
    Set ws = ActiveSheet
    If ws Is Nothing Then Exit Sub

    Dim headerRow As Long, dataFirstRow As Long, lastRow As Long, lastCol As Long, dateStartCol As Long
    If Not DxaBacklogDetectLayout(ws, headerRow, dataFirstRow, lastRow, lastCol, dateStartCol) Then Exit Sub

    Application.ScreenUpdating = False
    Application.StatusBar = "DelaxTools: Backlog�K���g�𐮌`���Ă��܂�..."

    DxaBacklogFormatIssueColumns ws, headerRow, dataFirstRow, lastRow, lastCol, dateStartCol
    DxaBacklogFormatDateColumns ws, headerRow, dataFirstRow, lastRow, lastCol, dateStartCol
    DxaBacklogHighlightRows ws, dataFirstRow, lastRow, lastCol
    DxaBacklogFreezeGantt ws, dataFirstRow, dateStartCol

    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "Backlog�K���g���`���������܂����B", vbInformation, "DelaxTools"
    Exit Sub
EH:
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "Backlog�K���g���`�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DelaxTools"
End Sub

Public Sub DxaBacklogCreateGanttSummary(ByVal control As Object)
    On Error GoTo EH

    Dim ws As Worksheet
    Set ws = ActiveSheet
    If ws Is Nothing Then Exit Sub

    Dim headerRow As Long, dataFirstRow As Long, lastRow As Long, lastCol As Long, dateStartCol As Long
    If Not DxaBacklogDetectLayout(ws, headerRow, dataFirstRow, lastRow, lastCol, dateStartCol) Then Exit Sub

    Application.ScreenUpdating = False
    Application.StatusBar = "DelaxTools: Backlog�K���g�T�}���[���쐬���Ă��܂�..."

    Dim outWs As Worksheet
    Set outWs = DxaBacklogRecreateSheet(ws.Parent, "Backlog�K���g�T�}���[")
    DxaBacklogWriteSummary ws, outWs, dataFirstRow, lastRow

    outWs.Activate
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "Backlog�K���g�T�}���[���쐬���܂����B", vbInformation, "DelaxTools"
    Exit Sub
EH:
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "Backlog�K���g�T�}���[�쐬�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DelaxTools"
End Sub

Public Sub DxaBacklogCreateDelayList(ByVal control As Object)
    On Error GoTo EH

    Dim ws As Worksheet
    Set ws = ActiveSheet
    If ws Is Nothing Then Exit Sub

    Dim headerRow As Long, dataFirstRow As Long, lastRow As Long, lastCol As Long, dateStartCol As Long
    If Not DxaBacklogDetectLayout(ws, headerRow, dataFirstRow, lastRow, lastCol, dateStartCol) Then Exit Sub

    Application.ScreenUpdating = False
    Application.StatusBar = "DelaxTools: Backlog�x���ꗗ���쐬���Ă��܂�..."

    Dim outWs As Worksheet
    Set outWs = DxaBacklogRecreateSheet(ws.Parent, "Backlog�x���ꗗ")
    DxaBacklogWriteDelayList ws, outWs, dataFirstRow, lastRow

    outWs.Activate
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "Backlog�x���ꗗ���쐬���܂����B", vbInformation, "DelaxTools"
    Exit Sub
EH:
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "Backlog�x���ꗗ�쐬�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DelaxTools"
End Sub

Public Sub DxaBacklogCreateMeetingView(ByVal control As Object)
    On Error GoTo EH

    Dim ws As Worksheet
    Set ws = ActiveSheet
    If ws Is Nothing Then Exit Sub

    Dim headerRow As Long, dataFirstRow As Long, lastRow As Long, lastCol As Long, dateStartCol As Long
    If Not DxaBacklogDetectLayout(ws, headerRow, dataFirstRow, lastRow, lastCol, dateStartCol) Then Exit Sub

    Application.ScreenUpdating = False
    Application.StatusBar = "DelaxTools: Backlog��c�p�r���[���쐬���Ă��܂�..."

    Dim outWs As Worksheet
    Set outWs = DxaBacklogRecreateSheet(ws.Parent, "Backlog��c�p")
    DxaBacklogWriteMeetingView ws, outWs, dataFirstRow, lastRow

    outWs.Activate
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "Backlog��c�p�r���[���쐬���܂����B", vbInformation, "DelaxTools"
    Exit Sub
EH:
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "Backlog��c�p�r���[�쐬�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DelaxTools"
End Sub

Public Sub DxaBacklogCreateAssigneeLoad(ByVal control As Object)
    On Error GoTo EH

    Dim ws As Worksheet
    Set ws = ActiveSheet
    If ws Is Nothing Then Exit Sub

    Dim headerRow As Long, dataFirstRow As Long, lastRow As Long, lastCol As Long, dateStartCol As Long
    If Not DxaBacklogDetectLayout(ws, headerRow, dataFirstRow, lastRow, lastCol, dateStartCol) Then Exit Sub

    Application.ScreenUpdating = False
    Application.StatusBar = "DelaxTools: Backlog�S���ҕʕ��ׂ��쐬���Ă��܂�..."

    Dim outWs As Worksheet
    Set outWs = DxaBacklogRecreateSheet(ws.Parent, "Backlog�S���ҕʕ���")
    DxaBacklogWriteAssigneeLoad ws, outWs, dataFirstRow, lastRow

    outWs.Activate
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "Backlog�S���ҕʕ��ׂ��쐬���܂����B", vbInformation, "DelaxTools"
    Exit Sub
EH:
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "Backlog�S���ҕʕ��׍쐬�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DelaxTools"
End Sub

Private Function DxaBacklogDetectLayout(ByVal ws As Worksheet, ByRef headerRow As Long, ByRef dataFirstRow As Long, ByRef lastRow As Long, ByRef lastCol As Long, ByRef dateStartCol As Long) As Boolean
    Dim r As Long
    headerRow = 0
    For r = 1 To 20
        If InStr(1, CStr(ws.Cells(r, 1).Value), "�L�[", vbTextCompare) > 0 And _
           InStr(1, CStr(ws.Cells(r, 3).Value), "����", vbTextCompare) > 0 Then
            headerRow = r
            Exit For
        End If
    Next

    If headerRow = 0 Then headerRow = 4
    dataFirstRow = headerRow + 1
    dateStartCol = 13

    lastRow = DxaBacklogLastUsedRow(ws)
    lastCol = DxaBacklogLastUsedCol(ws)
    If lastRow < dataFirstRow Or lastCol < 12 Then
        MsgBox "Backlog�K���g�o�͌`���𔻒�ł��܂���ł����BA�`L��ɉۑ��񂪂���V�[�g���A�N�e�B�u�ɂ��Ď��s���Ă��������B", vbExclamation, "DelaxTools"
        Exit Function
    End If

    If lastCol < dateStartCol Then lastCol = dateStartCol
    DxaBacklogDetectLayout = True
End Function

Private Function DxaBacklogLastUsedRow(ByVal ws As Worksheet) As Long
    Dim c As Range
    On Error Resume Next
    Set c = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByRows, SearchDirection:=xlPrevious, MatchCase:=False)
    On Error GoTo 0
    If c Is Nothing Then DxaBacklogLastUsedRow = 1 Else DxaBacklogLastUsedRow = c.Row
End Function

Private Function DxaBacklogLastUsedCol(ByVal ws As Worksheet) As Long
    Dim c As Range
    On Error Resume Next
    Set c = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlFormulas, LookAt:=xlPart, SearchOrder:=xlByColumns, SearchDirection:=xlPrevious, MatchCase:=False)
    On Error GoTo 0
    If c Is Nothing Then DxaBacklogLastUsedCol = 1 Else DxaBacklogLastUsedCol = c.Column
End Function

Private Sub DxaBacklogFormatIssueColumns(ByVal ws As Worksheet, ByVal headerRow As Long, ByVal dataFirstRow As Long, ByVal lastRow As Long, ByVal lastCol As Long, ByVal dateStartCol As Long)
    With ws
        .Rows(headerRow).Font.Bold = True
        .Rows(headerRow).Interior.Color = RGB(217, 225, 242)
        .Range(.Cells(headerRow, 1), .Cells(headerRow, lastCol)).AutoFilter
        .Columns("A:A").ColumnWidth = 14
        .Columns("B:B").ColumnWidth = 9
        .Columns("C:C").ColumnWidth = 55
        .Columns("C:C").WrapText = True
        .Columns("D:F").ColumnWidth = 12
        .Columns("G:G").ColumnWidth = 14
        .Columns("H:I").ColumnWidth = 12
        .Columns("H:I").NumberFormatLocal = "yyyy/mm/dd"
        .Columns("J:K").ColumnWidth = 10
        .Columns("L:L").ColumnWidth = 10
        .Rows(dataFirstRow & ":" & lastRow).RowHeight = 24
        .Range(.Cells(headerRow, 1), .Cells(lastRow, 12)).Borders.LineStyle = xlContinuous
    End With
End Sub

Private Sub DxaBacklogFormatDateColumns(ByVal ws As Worksheet, ByVal headerRow As Long, ByVal dataFirstRow As Long, ByVal lastRow As Long, ByVal lastCol As Long, ByVal dateStartCol As Long)
    Dim c As Long
    For c = dateStartCol To lastCol
        ws.Columns(c).ColumnWidth = 3.5
        Dim d As Date
        If DxaBacklogColumnDate(ws, c, headerRow, d) Then
            If Weekday(d, vbMonday) >= 6 Then
                ws.Range(ws.Cells(1, c), ws.Cells(lastRow, c)).Interior.Color = RGB(242, 242, 242)
            End If
            If DateValue(d) = Date Then
                ws.Range(ws.Cells(1, c), ws.Cells(lastRow, c)).Interior.Color = RGB(255, 242, 204)
                ws.Range(ws.Cells(1, c), ws.Cells(lastRow, c)).Borders(xlEdgeLeft).Weight = xlThick
                ws.Range(ws.Cells(1, c), ws.Cells(lastRow, c)).Borders(xlEdgeRight).Weight = xlThick
            End If
            If Day(d) = 1 Then
                ws.Range(ws.Cells(1, c), ws.Cells(lastRow, c)).Borders(xlEdgeLeft).Weight = xlMedium
            End If
        End If
    Next
    ws.Range(ws.Cells(1, dateStartCol), ws.Cells(headerRow, lastCol)).HorizontalAlignment = xlCenter
End Sub

Private Function DxaBacklogColumnDate(ByVal ws As Worksheet, ByVal colNo As Long, ByVal headerRow As Long, ByRef d As Date) As Boolean
    Dim r As Long
    For r = 1 To headerRow
        If IsDate(ws.Cells(r, colNo).Value) Then
            d = CDate(ws.Cells(r, colNo).Value)
            DxaBacklogColumnDate = True
            Exit Function
        End If
    Next
End Function

Private Sub DxaBacklogHighlightRows(ByVal ws As Worksheet, ByVal dataFirstRow As Long, ByVal lastRow As Long, ByVal lastCol As Long)
    Dim r As Long
    For r = dataFirstRow To lastRow
        If Len(Trim$(CStr(ws.Cells(r, 1).Value))) = 0 And Len(Trim$(CStr(ws.Cells(r, 3).Value))) = 0 Then GoTo ContinueRow

        Dim statusText As String
        statusText = CStr(ws.Cells(r, 12).Value)

        If DxaBacklogIsCompleted(statusText) Then
            ws.Range(ws.Cells(r, 1), ws.Cells(r, 12)).Interior.Color = RGB(217, 217, 217)
        ElseIf DxaBacklogIsOverdue(ws.Cells(r, 9).Value, statusText) Then
            ws.Range(ws.Cells(r, 1), ws.Cells(r, 12)).Interior.Color = RGB(255, 199, 206)
        ElseIf DxaBacklogIsDueWithin(ws.Cells(r, 9).Value, statusText, 3) Then
            ws.Range(ws.Cells(r, 1), ws.Cells(r, 12)).Interior.Color = RGB(244, 176, 132)
        ElseIf DxaBacklogIsDueWithin(ws.Cells(r, 9).Value, statusText, 7) Then
            ws.Range(ws.Cells(r, 1), ws.Cells(r, 12)).Interior.Color = RGB(255, 242, 204)
        End If

        If Len(Trim$(CStr(ws.Cells(r, 7).Value))) = 0 Then
            ws.Cells(r, 7).Interior.Color = RGB(255, 199, 206)
        End If
        If Not IsDate(ws.Cells(r, 8).Value) Then
            ws.Cells(r, 8).Interior.Color = RGB(255, 199, 206)
        End If
        If Not IsDate(ws.Cells(r, 9).Value) Then
            ws.Cells(r, 9).Interior.Color = RGB(255, 199, 206)
        ElseIf IsDate(ws.Cells(r, 8).Value) Then
            If CDate(ws.Cells(r, 9).Value) < CDate(ws.Cells(r, 8).Value) Then
                ws.Cells(r, 9).Interior.Color = RGB(255, 0, 0)
                ws.Cells(r, 9).Font.Color = RGB(255, 255, 255)
            End If
        End If
ContinueRow:
    Next
End Sub

Private Sub DxaBacklogFreezeGantt(ByVal ws As Worksheet, ByVal dataFirstRow As Long, ByVal dateStartCol As Long)
    On Error Resume Next
    ws.Activate
    ActiveWindow.FreezePanes = False
    ws.Cells(dataFirstRow, dateStartCol).Select
    ActiveWindow.FreezePanes = True
    On Error GoTo 0
End Sub

Private Function DxaBacklogIsCompleted(ByVal statusText As String) As Boolean
    Dim s As String
    s = Trim$(statusText)
    DxaBacklogIsCompleted = (InStr(1, s, "����", vbTextCompare) > 0 Or InStr(1, s, "�I��", vbTextCompare) > 0 Or InStr(1, s, "Closed", vbTextCompare) > 0)
End Function

Private Function DxaBacklogIsOverdue(ByVal dueValue As Variant, ByVal statusText As String) As Boolean
    If DxaBacklogIsCompleted(statusText) Then Exit Function
    If Not IsDate(dueValue) Then Exit Function
    DxaBacklogIsOverdue = (DateValue(CDate(dueValue)) < Date)
End Function

Private Function DxaBacklogIsDueWithin(ByVal dueValue As Variant, ByVal statusText As String, ByVal days As Long) As Boolean
    If DxaBacklogIsCompleted(statusText) Then Exit Function
    If Not IsDate(dueValue) Then Exit Function
    Dim d As Date
    d = DateValue(CDate(dueValue))
    DxaBacklogIsDueWithin = (d >= Date And d <= DateAdd("d", days, Date))
End Function

Private Function DxaBacklogDueStatus(ByVal dueValue As Variant, ByVal statusText As String) As String
    If DxaBacklogIsCompleted(statusText) Then
        DxaBacklogDueStatus = "����"
    ElseIf Not IsDate(dueValue) Then
        DxaBacklogDueStatus = "���������ݒ�"
    ElseIf DateValue(CDate(dueValue)) < Date Then
        DxaBacklogDueStatus = "��������"
    ElseIf DateValue(CDate(dueValue)) <= DateAdd("d", 3, Date) Then
        DxaBacklogDueStatus = "����3���ȓ�"
    ElseIf DateValue(CDate(dueValue)) <= DateAdd("d", 7, Date) Then
        DxaBacklogDueStatus = "����7���ȓ�"
    Else
        DxaBacklogDueStatus = "�ʏ�"
    End If
End Function

Private Function DxaBacklogOverdueDays(ByVal dueValue As Variant, ByVal statusText As String) As Long
    If Not DxaBacklogIsOverdue(dueValue, statusText) Then Exit Function
    DxaBacklogOverdueDays = DateDiff("d", DateValue(CDate(dueValue)), Date)
End Function

Private Function DxaBacklogAssignee(ByVal ws As Worksheet, ByVal rowNo As Long) As String
    DxaBacklogAssignee = Trim$(CStr(ws.Cells(rowNo, 7).Value))
    If Len(DxaBacklogAssignee) = 0 Then DxaBacklogAssignee = "���S��"
End Function

Private Function DxaBacklogRecreateSheet(ByVal wb As Workbook, ByVal sheetName As String) As Worksheet
    Application.DisplayAlerts = False
    On Error Resume Next
    wb.Worksheets(sheetName).Delete
    On Error GoTo 0
    Application.DisplayAlerts = True

    Dim ws As Worksheet
    Set ws = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))
    ws.Name = sheetName
    Set DxaBacklogRecreateSheet = ws
End Function

Private Sub DxaBacklogWriteSummary(ByVal srcWs As Worksheet, ByVal outWs As Worksheet, ByVal dataFirstRow As Long, ByVal lastRow As Long)
    Dim total As Long, completed As Long, processing As Long, notStarted As Long, overdue As Long, due3 As Long, due7 As Long
    Dim noAssignee As Long, noStart As Long, noDue As Long, invalidDue As Long
    Dim statusCounts As Object
    Set statusCounts = CreateObject("Scripting.Dictionary")

    Dim r As Long
    For r = dataFirstRow To lastRow
        If Len(Trim$(CStr(srcWs.Cells(r, 1).Value))) = 0 And Len(Trim$(CStr(srcWs.Cells(r, 3).Value))) = 0 Then GoTo ContinueRow
        total = total + 1
        Dim st As String
        st = Trim$(CStr(srcWs.Cells(r, 12).Value))
        If Len(st) = 0 Then st = "��Ԗ��ݒ�"
        If statusCounts.Exists(st) Then statusCounts(st) = CLng(statusCounts(st)) + 1 Else statusCounts.Add st, 1
        If DxaBacklogIsCompleted(st) Then completed = completed + 1
        If InStr(1, st, "������", vbTextCompare) > 0 Then processing = processing + 1
        If InStr(1, st, "���Ή�", vbTextCompare) > 0 Then notStarted = notStarted + 1
        If DxaBacklogIsOverdue(srcWs.Cells(r, 9).Value, st) Then overdue = overdue + 1
        If DxaBacklogIsDueWithin(srcWs.Cells(r, 9).Value, st, 3) Then due3 = due3 + 1
        If DxaBacklogIsDueWithin(srcWs.Cells(r, 9).Value, st, 7) Then due7 = due7 + 1
        If Len(Trim$(CStr(srcWs.Cells(r, 7).Value))) = 0 Then noAssignee = noAssignee + 1
        If Not IsDate(srcWs.Cells(r, 8).Value) Then noStart = noStart + 1
        If Not IsDate(srcWs.Cells(r, 9).Value) Then noDue = noDue + 1
        If IsDate(srcWs.Cells(r, 8).Value) And IsDate(srcWs.Cells(r, 9).Value) Then
            If CDate(srcWs.Cells(r, 9).Value) < CDate(srcWs.Cells(r, 8).Value) Then invalidDue = invalidDue + 1
        End If
ContinueRow:
    Next

    outWs.Range("A1:B1").Value = Array("����", "����")
    outWs.Range("A1:B1").Font.Bold = True
    outWs.Cells(2, 1).Value = "�S�ۑ萔": outWs.Cells(2, 2).Value = total
    outWs.Cells(3, 1).Value = "����": outWs.Cells(3, 2).Value = completed
    outWs.Cells(4, 1).Value = "������": outWs.Cells(4, 2).Value = processing
    outWs.Cells(5, 1).Value = "���Ή�": outWs.Cells(5, 2).Value = notStarted
    outWs.Cells(6, 1).Value = "��������": outWs.Cells(6, 2).Value = overdue
    outWs.Cells(7, 1).Value = "����3���ȓ�": outWs.Cells(7, 2).Value = due3
    outWs.Cells(8, 1).Value = "����7���ȓ�": outWs.Cells(8, 2).Value = due7
    outWs.Cells(9, 1).Value = "�S���Җ��ݒ�": outWs.Cells(9, 2).Value = noAssignee
    outWs.Cells(10, 1).Value = "�J�n�����ݒ�": outWs.Cells(10, 2).Value = noStart
    outWs.Cells(11, 1).Value = "���������ݒ�": outWs.Cells(11, 2).Value = noDue
    outWs.Cells(12, 1).Value = "���������J�n�����O": outWs.Cells(12, 2).Value = invalidDue

    outWs.Range("D1:E1").Value = Array("���", "����")
    outWs.Range("D1:E1").Font.Bold = True
    Dim rowOut As Long
    rowOut = 2
    Dim k As Variant
    For Each k In statusCounts.Keys
        outWs.Cells(rowOut, 4).Value = CStr(k)
        outWs.Cells(rowOut, 5).Value = CLng(statusCounts(k))
        rowOut = rowOut + 1
    Next

    outWs.Columns("A:E").AutoFit
    outWs.Range("A1:E1").Interior.Color = RGB(217, 225, 242)
End Sub

Private Sub DxaBacklogWriteDelayList(ByVal srcWs As Worksheet, ByVal outWs As Worksheet, ByVal dataFirstRow As Long, ByVal lastRow As Long)
    outWs.Range("A1:I1").Value = Array("No", "�ۑ�L�[", "����", "�S����", "���", "�J�n��", "������", "���ߓ���", "�m�F")
    outWs.Range("A1:I1").Font.Bold = True
    outWs.Range("A1:I1").Interior.Color = RGB(217, 225, 242)

    Dim rowOut As Long
    rowOut = 2
    Dim r As Long
    For r = dataFirstRow To lastRow
        Dim st As String
        st = CStr(srcWs.Cells(r, 12).Value)
        If DxaBacklogIsOverdue(srcWs.Cells(r, 9).Value, st) Then
            outWs.Cells(rowOut, 1).Value = rowOut - 1
            outWs.Cells(rowOut, 2).Value = srcWs.Cells(r, 1).Value
            outWs.Cells(rowOut, 3).Value = srcWs.Cells(r, 3).Value
            outWs.Cells(rowOut, 4).Value = DxaBacklogAssignee(srcWs, r)
            outWs.Cells(rowOut, 5).Value = st
            outWs.Cells(rowOut, 6).Value = srcWs.Cells(r, 8).Value
            outWs.Cells(rowOut, 7).Value = srcWs.Cells(r, 9).Value
            outWs.Cells(rowOut, 8).Value = DxaBacklogOverdueDays(srcWs.Cells(r, 9).Value, st)
            outWs.Cells(rowOut, 9).Value = "���s�ֈړ�"
            On Error Resume Next
            outWs.Hyperlinks.Add Anchor:=outWs.Cells(rowOut, 9), Address:="", SubAddress:="'" & srcWs.Name & "'!A" & r, TextToDisplay:="���s�ֈړ�"
            On Error GoTo 0
            rowOut = rowOut + 1
        End If
    Next

    If rowOut = 2 Then outWs.Cells(2, 1).Value = "�������߉ۑ�͂���܂���B"
    outWs.Columns("A:I").AutoFit
    outWs.Range("A1:I1").AutoFilter
End Sub

Private Sub DxaBacklogWriteMeetingView(ByVal srcWs As Worksheet, ByVal outWs As Worksheet, ByVal dataFirstRow As Long, ByVal lastRow As Long)
    outWs.Range("A1:J1").Value = Array("No", "�ۑ�L�[", "����", "�S����", "���", "�J�n��", "������", "�x����", "�\�莞��", "���ю���")
    outWs.Range("A1:J1").Font.Bold = True
    outWs.Range("A1:J1").Interior.Color = RGB(217, 225, 242)

    Dim rowOut As Long
    rowOut = 2
    Dim r As Long
    For r = dataFirstRow To lastRow
        If Len(Trim$(CStr(srcWs.Cells(r, 1).Value))) = 0 And Len(Trim$(CStr(srcWs.Cells(r, 3).Value))) = 0 Then GoTo ContinueRow
        Dim st As String
        st = CStr(srcWs.Cells(r, 12).Value)
        If DxaBacklogIsCompleted(st) Then GoTo ContinueRow

        outWs.Cells(rowOut, 1).Value = rowOut - 1
        outWs.Cells(rowOut, 2).Value = srcWs.Cells(r, 1).Value
        outWs.Cells(rowOut, 3).Value = srcWs.Cells(r, 3).Value
        outWs.Cells(rowOut, 4).Value = DxaBacklogAssignee(srcWs, r)
        outWs.Cells(rowOut, 5).Value = st
        outWs.Cells(rowOut, 6).Value = srcWs.Cells(r, 8).Value
        outWs.Cells(rowOut, 7).Value = srcWs.Cells(r, 9).Value
        outWs.Cells(rowOut, 8).Value = DxaBacklogDueStatus(srcWs.Cells(r, 9).Value, st)
        outWs.Cells(rowOut, 9).Value = srcWs.Cells(r, 10).Value
        outWs.Cells(rowOut, 10).Value = srcWs.Cells(r, 11).Value
        On Error Resume Next
        outWs.Hyperlinks.Add Anchor:=outWs.Cells(rowOut, 2), Address:="", SubAddress:="'" & srcWs.Name & "'!A" & r, TextToDisplay:=CStr(srcWs.Cells(r, 1).Value)
        On Error GoTo 0
        rowOut = rowOut + 1
ContinueRow:
    Next

    If rowOut = 2 Then outWs.Cells(2, 1).Value = "��c�p�ɕ\�����関�����ۑ�͂���܂���B"
    outWs.Columns("A:J").AutoFit
    outWs.Range("A1:J1").AutoFilter
End Sub

Private Sub DxaBacklogWriteAssigneeLoad(ByVal srcWs As Worksheet, ByVal outWs As Worksheet, ByVal dataFirstRow As Long, ByVal lastRow As Long)
    Dim dict As Object
    Set dict = CreateObject("Scripting.Dictionary")

    Dim r As Long
    For r = dataFirstRow To lastRow
        If Len(Trim$(CStr(srcWs.Cells(r, 1).Value))) = 0 And Len(Trim$(CStr(srcWs.Cells(r, 3).Value))) = 0 Then GoTo ContinueRow
        Dim assignee As String
        assignee = DxaBacklogAssignee(srcWs, r)
        If Not dict.Exists(assignee) Then dict.Add assignee, Array(0#, 0#, 0#, 0#, 0#, 0#)

        Dim a As Variant
        a = dict(assignee)
        a(0) = CDbl(a(0)) + 1
        a(1) = CDbl(a(1)) + DxaBacklogToDouble(srcWs.Cells(r, 10).Value)
        a(2) = CDbl(a(2)) + DxaBacklogToDouble(srcWs.Cells(r, 11).Value)
        If Not DxaBacklogIsCompleted(CStr(srcWs.Cells(r, 12).Value)) Then a(3) = CDbl(a(3)) + 1
        If DxaBacklogIsOverdue(srcWs.Cells(r, 9).Value, CStr(srcWs.Cells(r, 12).Value)) Then a(4) = CDbl(a(4)) + 1
        If DxaBacklogIsDueWithin(srcWs.Cells(r, 9).Value, CStr(srcWs.Cells(r, 12).Value), 7) Then a(5) = CDbl(a(5)) + 1
        dict(assignee) = a
ContinueRow:
    Next

    outWs.Range("A1:G1").Value = Array("�S����", "�ۑ萔", "�\�莞��", "���ю���", "������", "��������", "����7���ȓ�")
    outWs.Range("A1:G1").Font.Bold = True
    outWs.Range("A1:G1").Interior.Color = RGB(217, 225, 242)

    Dim rowOut As Long
    rowOut = 2
    Dim k As Variant
    For Each k In dict.Keys
        Dim v As Variant
        v = dict(k)
        outWs.Cells(rowOut, 1).Value = CStr(k)
        outWs.Cells(rowOut, 2).Value = v(0)
        outWs.Cells(rowOut, 3).Value = v(1)
        outWs.Cells(rowOut, 4).Value = v(2)
        outWs.Cells(rowOut, 5).Value = v(3)
        outWs.Cells(rowOut, 6).Value = v(4)
        outWs.Cells(rowOut, 7).Value = v(5)
        rowOut = rowOut + 1
    Next

    outWs.Columns("A:G").AutoFit
    outWs.Range("A1:G1").AutoFilter
End Sub

Private Function DxaBacklogToDouble(ByVal v As Variant) As Double
    On Error GoTo EH
    If IsNumeric(v) Then DxaBacklogToDouble = CDbl(v)
    Exit Function
EH:
    DxaBacklogToDouble = 0
End Function

 ' ============================================================
' BITS�Αӕ\�擾
' BITS Remote Time-card System�փ��O�C�����A�Ǘ��ꗗ����Ώێ҂̋Αӈꗗ�֑J�ڂ��āA
' ���t�E�o�Ύ����E�ދΎ������擾���܂��B
' �F�؏��̓��[�U�[�m�F��ɕۑ��ł��܂��B�ۑ����̃p�X���[�h��Windows DPAPI�Ń��[�U�[�P�ʂɈÍ������܂��B
' ============================================================
Public Sub DxaImportTimecardNormalWork(ByVal control As Object)
    ' �ʏ�Ζ��F�ދΎ����� 17:30�`18:14 �� 17:30 �Ƃ��Ĉ����A18:15�ȍ~��15���P�ʂŐ؂�̂Ă܂��B
    DxaImportTimecardFromWebCore 2, "�ʏ�Ζ�"
End Sub

Public Sub DxaImportTimecardShiftWork(ByVal control As Object)
    ' �V�t�g�Ζ��F�ދΎ����͏��15���P�ʂŐ؂�̂Ă܂��B
    DxaImportTimecardFromWebCore 1, "�V�t�g�Ζ�"
End Sub

Public Sub DxaConfigureTimecardTargetName(ByVal control As Object)
    ' �Αӎ擾���ɗD�挟������ΏێҖ������O�ۑ����܂��B
    ' v157: �ΏێҐݒ��ʂ���s�v�Ȑ����g�ƃ^�C�g����DelaxTools�\�L���폜���܂��B
    On Error GoTo EH

    DxaOpenTimecardTargetSettingsSheet
    Exit Sub

EH:
    MsgBox "�Αӎ擾�ΏێҖ��̐ݒ�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DelaxTools"
End Sub

Public Sub DxaOpenTimecardTargetSettingsSheet()
    On Error GoTo EH

    Dim wb As Workbook
    Set wb = ActiveWorkbook
    If wb Is Nothing Then
        Set wb = Workbooks.Add
    End If

    Dim ws As Worksheet
    Set ws = DxaGetOrCreateTimecardTargetSettingsSheet(wb)

    DxaRenderTimecardTargetSettingsSheet ws
    ws.Activate
    ws.Range("B8").Select
    Exit Sub

EH:
    MsgBox "�Αӎ擾�ΏێҐݒ��ʂ��J���܂���ł����B" & vbCrLf & Err.Description, vbExclamation, "DelaxTools"
End Sub

Public Sub DxaSaveTimecardTargetNamesFromSheet()
    On Error GoTo EH

    Dim ws As Worksheet
    Set ws = DxaGetTimecardTargetSettingsSheet()
    If ws Is Nothing Then
        MsgBox "�ΑӑΏێҐݒ�V�[�g��������܂���B�ΏێҐݒ�{�^������J�������Ă��������B", vbExclamation, "DelaxTools"
        Exit Sub
    End If

    Dim targetNames As Collection
    Set targetNames = New Collection

    Dim r As Long
    For r = 8 To 57
        Call DxaAddTimecardTargetName(targetNames, CStr(ws.Cells(r, 2).Value))
    Next

    If targetNames.Count = 0 Then
        If MsgBox("�ΏێҖ������͂���Ă��܂���B�ۑ��ςݑΏێҖ������ׂč폜���܂����H", vbQuestion + vbYesNo, "DelaxTools �ΑӑΏێҐݒ�") = vbYes Then
            If DxaDeleteTimecardSavedTargetName() Then
                ws.Range("B8:B57").ClearContents
                MsgBox "�ۑ��ςݑΏێҖ����폜���܂����B", vbInformation, "DelaxTools"
            Else
                MsgBox "�ۑ��ςݑΏێҖ��̍폜�Ɏ��s���܂����B", vbExclamation, "DelaxTools"
            End If
        End If
        Exit Sub
    End If

    If DxaSaveTimecardSavedTargetName(DxaJoinTimecardTargetNames(targetNames)) Then
        DxaRenderTimecardTargetSettingsSheet ws
        MsgBox "�Αӎ擾�ΏێҖ���ۑ����܂����B" & vbCrLf & vbCrLf & DxaJoinTimecardTargetNamesForMessage(DxaJoinTimecardTargetNames(targetNames)), vbInformation, "DelaxTools"
    Else
        MsgBox "�Αӎ擾�ΏێҖ��̕ۑ��Ɏ��s���܂����B", vbExclamation, "DelaxTools"
    End If
    Exit Sub

EH:
    MsgBox "�Αӎ擾�ΏێҖ��̕ۑ��ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DelaxTools"
End Sub

Public Sub DxaClearTimecardTargetNamesFromSheet()
    On Error GoTo EH

    Dim ws As Worksheet
    Set ws = DxaGetTimecardTargetSettingsSheet()
    If ws Is Nothing Then Exit Sub

    If MsgBox("�ۑ��ςݑΏێҖ������ׂč폜���܂����H", vbQuestion + vbYesNo, "DelaxTools �ΑӑΏێҐݒ�") <> vbYes Then Exit Sub

    If DxaDeleteTimecardSavedTargetName() Then
        ws.Range("B8:B57").ClearContents
        MsgBox "�ۑ��ςݑΏێҖ����폜���܂����B", vbInformation, "DelaxTools"
    Else
        MsgBox "�ۑ��ςݑΏێҖ��̍폜�Ɏ��s���܂����B", vbExclamation, "DelaxTools"
    End If
    Exit Sub

EH:
    MsgBox "�Αӎ擾�ΏێҖ��̍폜�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DelaxTools"
End Sub

Private Function DxaGetOrCreateTimecardTargetSettingsSheet(ByVal wb As Workbook) As Worksheet
    Dim ws As Worksheet
    For Each ws In wb.Worksheets
        If ws.Name = "�ΑӑΏێҐݒ�" Then
            Set DxaGetOrCreateTimecardTargetSettingsSheet = ws
            Exit Function
        End If
    Next

    Set ws = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))
    ws.Name = "�ΑӑΏێҐݒ�"
    Set DxaGetOrCreateTimecardTargetSettingsSheet = ws
End Function

Private Function DxaGetTimecardTargetSettingsSheet() As Worksheet
    On Error GoTo EH

    Dim wb As Workbook
    Set wb = ActiveWorkbook
    If wb Is Nothing Then Exit Function

    Dim ws As Worksheet
    For Each ws In wb.Worksheets
        If ws.Name = "�ΑӑΏێҐݒ�" Then
            Set DxaGetTimecardTargetSettingsSheet = ws
            Exit Function
        End If
    Next
    Exit Function

EH:
    Set DxaGetTimecardTargetSettingsSheet = Nothing
End Function

Private Sub DxaRenderTimecardTargetSettingsSheet(ByVal ws As Worksheet)
    On Error GoTo EH

    Application.ScreenUpdating = False

    ws.Cells.Clear
    DxaDeleteTimecardSettingsShapes ws

    ws.Range("A1:F1").Merge
    ws.Range("A1").Value = "�Αӎ擾 �ΏێҐݒ�"
    With ws.Range("A1")
        .Font.Size = 18
        .Font.Bold = True
        .Font.Color = RGB(255, 255, 255)
        .Interior.Color = RGB(31, 78, 121)
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
    End With
    ws.Rows(1).RowHeight = 34

    ws.Range("A3:F5").Merge
    ws.Range("A3").Value = "�ʏ�Ζ��擾�E�V�t�g�Ζ��擾�ŗD�挟������Ώێ҂�o�^���܂��B" & vbCrLf & _
                           "B���1�������͂��āA�E���́m�ۑ��n�������Ă��������B�󔒂�d���͕ۑ����ɐ������܂��B" & vbCrLf & _
                           "�擾���́A�o�^�ςݑΏێ҂̒�����ԍ��őI���ł��܂��B"
    With ws.Range("A3")
        .Font.Size = 10
        .Font.Color = RGB(64, 64, 64)
        .Interior.Color = RGB(242, 246, 252)
        .WrapText = True
        .VerticalAlignment = xlCenter
    End With

    ws.Range("A7").Value = "No"
    ws.Range("B7").Value = "�ΏێҖ�"
    ws.Range("C7").Value = "����"
    ws.Range("A7:C7").Font.Bold = True
    ws.Range("A7:C7").Font.Color = RGB(255, 255, 255)
    ws.Range("A7:C7").Interior.Color = RGB(68, 114, 196)
    ws.Range("A7:C57").Borders.LineStyle = xlContinuous
    ws.Range("A7:C57").Borders.Color = RGB(210, 220, 235)

    Dim r As Long
    For r = 8 To 57
        ws.Cells(r, 1).Value = r - 7
        ws.Cells(r, 3).Value = ""
    Next

    Dim saved As Collection
    Set saved = DxaParseTimecardTargetNames(DxaLoadTimecardSavedTargetName())

    Dim i As Long
    For i = 1 To saved.Count
        If i > 50 Then Exit For
        ws.Cells(7 + i, 2).Value = CStr(saved(i))
    Next

    ws.Columns("A").ColumnWidth = 6
    ws.Columns("B").ColumnWidth = 28
    ws.Columns("C").ColumnWidth = 32
    ws.Columns("D").ColumnWidth = 3
    ws.Columns("E").ColumnWidth = 16
    ws.Columns("F").ColumnWidth = 16
    ws.Range("A8:A57").HorizontalAlignment = xlCenter
    ws.Range("B8:B57").Interior.Color = RGB(255, 255, 255)
    ws.Range("B8:B57").Font.Size = 11

    ws.Range("E7:F7").Merge
    ws.Range("E7").Value = "����"
    ws.Range("E7").Font.Bold = True
    ws.Range("E7").Font.Color = RGB(255, 255, 255)
    ws.Range("E7").Interior.Color = RGB(68, 114, 196)
    ws.Range("E7").HorizontalAlignment = xlCenter

    DxaAddTimecardSettingsButton ws, "DxaTimecardSaveButton", "�ۑ�", ws.Range("E9").Left, ws.Range("E9").Top, 120, 30, "DxaSaveTimecardTargetNamesFromSheet", RGB(31, 78, 121), RGB(255, 255, 255)
    DxaAddTimecardSettingsButton ws, "DxaTimecardClearButton", "���ׂč폜", ws.Range("E12").Left, ws.Range("E12").Top, 120, 30, "DxaClearTimecardTargetNamesFromSheet", RGB(128, 128, 128), RGB(255, 255, 255)

    ws.Activate
    ActiveWindow.DisplayGridlines = False
    ws.Range("A7:C57").AutoFilter

CleanExit:
    Application.ScreenUpdating = True
    Exit Sub

EH:
    Application.ScreenUpdating = True
    Err.Raise Err.Number, Err.Source, Err.Description
End Sub

Private Sub DxaDeleteTimecardSettingsShapes(ByVal ws As Worksheet)
    On Error Resume Next
    ws.Shapes("DxaTimecardSaveButton").Delete
    ws.Shapes("DxaTimecardClearButton").Delete
    On Error GoTo 0
End Sub

Private Sub DxaAddTimecardSettingsButton(ByVal ws As Worksheet, ByVal shapeName As String, ByVal caption As String, ByVal buttonLeft As Double, ByVal buttonTop As Double, ByVal buttonWidth As Double, ByVal buttonHeight As Double, ByVal macroName As String, ByVal fillColor As Long, ByVal fontColor As Long)
    On Error GoTo EH

    Dim shp As Shape
    Set shp = ws.Shapes.AddShape(5, buttonLeft, buttonTop, buttonWidth, buttonHeight)
    shp.Name = shapeName
    shp.TextFrame.Characters.Text = caption
    shp.TextFrame.Characters.Font.Bold = True
    shp.TextFrame.Characters.Font.Size = 11
    shp.TextFrame.Characters.Font.Color = fontColor
    shp.TextFrame.HorizontalAlignment = xlHAlignCenter
    shp.TextFrame.VerticalAlignment = xlVAlignCenter
    shp.Fill.ForeColor.RGB = fillColor
    shp.Line.ForeColor.RGB = fillColor
    shp.OnAction = "'" & ThisWorkbook.Name & "'!" & macroName
    Exit Sub

EH:
    ' �{�^���쐬�Ɏ��s���Ă��A�ݒ�V�[�g���̂͗��p�ł���悤�ɂ��܂��B
End Sub

Public Sub DxaImportTimecardFromClipboard(ByVal control As Object)
    ' �݊��p�F���{�^������Ă΂ꂽ�ꍇ�͒ʏ�Ζ��Ƃ���Web�擾���܂��B
    DxaImportTimecardFromWebCore 2, "�ʏ�Ζ�"
End Sub

Private Sub DxaImportTimecardFromWebCore(ByVal endRoundMode As Long, ByVal workTypeLabel As String)
    On Error GoTo EH

    Dim email As String
    Dim password As String
    Dim loginUrl As String
    Dim managedListUrl As String
    Dim savedEmail As String
    Dim savedPassword As String
    Dim usedSavedCredentials As Boolean
    Dim savedAnswer As VbMsgBoxResult

    loginUrl = "https://staffsvc.bits.co.jp/AttendanceMgt/TimeScreen.jsp"
    managedListUrl = "https://staffsvc.bits.co.jp/AttendanceMgt/GetManagedList"

    If DxaLoadTimecardSavedCredentials(savedEmail, savedPassword) Then
        savedAnswer = MsgBox("�ۑ��ς݂̃��O�C�������g�p���܂����H" & vbCrLf & vbCrLf & _
                             "���[���A�h���X: " & savedEmail, _
                             vbYesNoCancel + vbQuestion, "DelaxTools �Αӎ擾")
        If savedAnswer = vbCancel Then Exit Sub
        If savedAnswer = vbYes Then
            email = savedEmail
            password = savedPassword
            usedSavedCredentials = True
        End If
    End If

    If Len(email) = 0 Then
        email = DxaPromptRequiredText("���[���A�h���X����͂��Ă��������B", "DelaxTools �Αӎ擾", savedEmail)
        If Len(email) = 0 Then Exit Sub
    End If

    If Len(password) = 0 Then
        password = DxaPromptRequiredText("�p�X���[�h����͂��Ă��������B", "DelaxTools �Αӎ擾")
        If Len(password) = 0 Then Exit Sub
    End If

    Application.StatusBar = "DelaxTools: �ΑӃT�C�g�֐ڑ����Ă��܂�..."

    Dim displayItems As Collection
    Set displayItems = DxaFetchTimecardDisplayItems(loginUrl, managedListUrl, email, password)

    If displayItems Is Nothing Or displayItems.Count = 0 Then
        MsgBox "�Αӈꗗ��ʂ��擾�ł��܂���ł����B" & vbCrLf & vbCrLf & _
               "���[���A�h���X�A�p�X���[�h�A�T�C�g���̉�ʍ\�����m�F���Ă��������B", vbExclamation, "DelaxTools"
        GoTo CleanExit
    End If

    Dim item As Variant
    Dim html As String
    Dim targetName As String
    Dim records As Collection
    Dim successCount As Long
    Dim failedText As String

    For Each item In displayItems
        targetName = CStr(item(0))
        html = CStr(item(2))

        If Len(Trim$(html)) = 0 Then
            failedText = failedText & targetName & "�F�Αӈꗗ��ʂ��擾�ł��܂���ł����B" & vbCrLf
        Else
            Set records = DxaParseTimecardRecords(html)
            If records Is Nothing Or records.Count = 0 Then
                failedText = failedText & targetName & "�F���t�A�o�Ύ����A�ދΎ��������o�ł��܂���ł����B" & vbCrLf
            Else
                DxaWriteTimecardRecords records, endRoundMode, targetName
                successCount = successCount + 1
            End If
        End If
    Next

    If successCount = 0 Then
        MsgBox "�Αӈꗗ��ʂ�����t�A�o�Ύ����A�ދΎ��������o�ł��܂���ł����B" & vbCrLf & vbCrLf & _
               "�Ώێ҂̋Αӈꗗ��ʂ��\������Ă��邩�A�T�C�g����HTML�\�����m�F���Ă��������B" & vbCrLf & vbCrLf & _
               failedText, vbExclamation, "DelaxTools"
        GoTo CleanExit
    End If

    If Len(failedText) > 0 Then
        MsgBox "�Αӎ擾�͈ꕔ�������܂����B" & vbCrLf & vbCrLf & _
               "�擾����: " & CStr(successCount) & "��" & vbCrLf & vbCrLf & _
               "�擾�ł��Ȃ������Ώێ�:" & vbCrLf & failedText, vbExclamation, "DelaxTools"
    End If

    If Not usedSavedCredentials Then
        If MsgBox("������͂������[���A�h���X�ƃp�X���[�h������PC�ɕۑ����܂����H" & vbCrLf & vbCrLf & _
                  "���񂩂���͂��ȗ��ł��܂��B" & vbCrLf & _
                  "�p�X���[�h��Windows�̃��[�U�[�P�ʂňÍ������ĕۑ����܂��B", _
                  vbYesNo + vbQuestion, "DelaxTools �Αӎ擾") = vbYes Then
            If DxaSaveTimecardCredentials(email, password) Then
                MsgBox "���O�C������ۑ����܂����B", vbInformation, "DelaxTools"
            Else
                MsgBox "���O�C�����̕ۑ��Ɏ��s���܂����B" & vbCrLf & _
                       "�Αӎ擾�̌��ʂ͏o�͍ς݂ł��B", vbExclamation, "DelaxTools"
            End If
        End If
    End If

CleanExit:
    Application.StatusBar = False
    Exit Sub

EH:
    Application.StatusBar = False
    MsgBox "�Αӕ\�擾�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DelaxTools"
End Sub

Private Function DxaPromptRequiredText(ByVal prompt As String, ByVal title As String, Optional ByVal defaultValue As String = "") As String
    Dim s As String
    s = InputBox(prompt, title, defaultValue)
    s = Trim$(s)
    DxaPromptRequiredText = s
End Function

Private Function DxaLoadTimecardSavedCredentials(ByRef email As String, ByRef password As String) As Boolean
    On Error GoTo EH

    Dim path As String
    path = DxaTimecardCredentialFilePath()
    If Len(path) = 0 Then Exit Function
    If Len(Dir$(path)) = 0 Then Exit Function

    Dim emailEncoded As String
    Dim passwordEncoded As String
    Dim lineText As String
    Dim ff As Integer

    ff = FreeFile
    Open path For Input As #ff
    Do Until EOF(ff)
        Line Input #ff, lineText
        If Left$(lineText, 6) = "Email=" Then
            emailEncoded = Mid$(lineText, 7)
        ElseIf Left$(lineText, 9) = "Password=" Then
            passwordEncoded = Mid$(lineText, 10)
        End If
    Loop
    Close #ff

    If Len(emailEncoded) = 0 Or Len(passwordEncoded) = 0 Then Exit Function

    Dim emailBytes() As Byte
    Dim protectedPasswordBytes() As Byte
    Dim passwordBytes() As Byte

    emailBytes = DxaBase64ToBytes(emailEncoded)
    protectedPasswordBytes = DxaBase64ToBytes(passwordEncoded)
    passwordBytes = DxaDpapiUnprotectBytes(protectedPasswordBytes)

    email = DxaUtf16BytesToString(emailBytes)
    password = DxaUtf16BytesToString(passwordBytes)

    DxaLoadTimecardSavedCredentials = (Len(email) > 0 And Len(password) > 0)
    Exit Function

EH:
    On Error Resume Next
    If ff <> 0 Then Close #ff
    DxaLoadTimecardSavedCredentials = False
End Function

Private Function DxaSaveTimecardCredentials(ByVal email As String, ByVal password As String) As Boolean
    On Error GoTo EH

    Dim path As String
    path = DxaTimecardCredentialFilePath()
    If Len(path) = 0 Then Exit Function

    Dim emailBytes() As Byte
    Dim passwordBytes() As Byte
    Dim protectedPasswordBytes() As Byte

    emailBytes = DxaStringToUtf16Bytes(email)
    passwordBytes = DxaStringToUtf16Bytes(password)
    protectedPasswordBytes = DxaDpapiProtectBytes(passwordBytes)

    If DxaByteArrayLength(emailBytes) = 0 Then Exit Function
    If DxaByteArrayLength(protectedPasswordBytes) = 0 Then Exit Function

    Dim ff As Integer
    ff = FreeFile
    Open path For Output As #ff
    Print #ff, "Version=1"
    Print #ff, "Email=" & DxaBytesToBase64(emailBytes)
    Print #ff, "Password=" & DxaBytesToBase64(protectedPasswordBytes)
    Close #ff

    DxaSaveTimecardCredentials = True
    Exit Function

EH:
    On Error Resume Next
    If ff <> 0 Then Close #ff
    DxaSaveTimecardCredentials = False
End Function

Private Function DxaTimecardCredentialFilePath() As String
    On Error GoTo EH

    Dim appData As String
    appData = Environ$("APPDATA")
    If Len(appData) = 0 Then Exit Function

    Dim folderPath As String
    folderPath = appData & "\DelaxTools"
    If Len(Dir$(folderPath, vbDirectory)) = 0 Then MkDir folderPath

    DxaTimecardCredentialFilePath = folderPath & "\timecard_credentials.dat"
    Exit Function

EH:
    DxaTimecardCredentialFilePath = ""
End Function

Private Function DxaLoadTimecardSavedTargetName() As String
    On Error GoTo EH

    Dim path As String
    path = DxaTimecardTargetNameFilePath()
    If Len(path) = 0 Then Exit Function
    If Len(Dir$(path)) = 0 Then Exit Function

    Dim targetNames As Collection
    Set targetNames = New Collection

    Dim lineText As String
    Dim ff As Integer

    ff = FreeFile
    Open path For Input As #ff
    Do Until EOF(ff)
        Line Input #ff, lineText
        If Left$(lineText, 11) = "TargetName=" Then
            Call DxaAddTimecardTargetName(targetNames, DxaUtf16BytesToString(DxaBase64ToBytes(Mid$(lineText, 12))))
        ElseIf Left$(lineText, 10) = "TargetName" And InStr(1, lineText, "=", vbTextCompare) > 0 Then
            Call DxaAddTimecardTargetName(targetNames, DxaUtf16BytesToString(DxaBase64ToBytes(Mid$(lineText, InStr(1, lineText, "=", vbTextCompare) + 1))))
        End If
    Loop
    Close #ff

    DxaLoadTimecardSavedTargetName = DxaJoinTimecardTargetNames(targetNames)
    Exit Function

EH:
    On Error Resume Next
    If ff <> 0 Then Close #ff
    DxaLoadTimecardSavedTargetName = ""
End Function

Private Function DxaSaveTimecardSavedTargetName(ByVal targetName As String) As Boolean
    On Error GoTo EH

    Dim targetNames As Collection
    Set targetNames = DxaParseTimecardTargetNames(targetName)
    If targetNames.Count = 0 Then Exit Function

    Dim path As String
    path = DxaTimecardTargetNameFilePath()
    If Len(path) = 0 Then Exit Function

    Dim ff As Integer
    ff = FreeFile
    Open path For Output As #ff
    Print #ff, "Version=2"

    Dim i As Long
    For i = 1 To targetNames.Count
        Dim targetBytes() As Byte
        targetBytes = DxaStringToUtf16Bytes(CStr(targetNames(i)))
        If DxaByteArrayLength(targetBytes) > 0 Then
            Print #ff, "TargetName" & CStr(i) & "=" & DxaBytesToBase64(targetBytes)
        End If
    Next

    Close #ff

    DxaSaveTimecardSavedTargetName = True
    Exit Function

EH:
    On Error Resume Next
    If ff <> 0 Then Close #ff
    DxaSaveTimecardSavedTargetName = False
End Function

Private Function DxaDeleteTimecardSavedTargetName() As Boolean
    On Error GoTo EH

    Dim path As String
    path = DxaTimecardTargetNameFilePath()
    If Len(path) = 0 Then Exit Function
    If Len(Dir$(path)) > 0 Then Kill path

    DxaDeleteTimecardSavedTargetName = True
    Exit Function

EH:
    DxaDeleteTimecardSavedTargetName = False
End Function

Private Function DxaParseTimecardTargetNames(ByVal targetText As String) As Collection
    On Error GoTo EH

    Dim result As Collection
    Set result = New Collection

    Dim s As String
    s = CStr(targetText)
    s = Replace$(s, vbCrLf, vbLf)
    s = Replace$(s, vbCr, vbLf)
    s = Replace$(s, "�A", vbLf)
    s = Replace$(s, "�C", vbLf)
    s = Replace$(s, ",", vbLf)
    s = Replace$(s, "�G", vbLf)
    s = Replace$(s, ";", vbLf)
    s = Replace$(s, "�^", vbLf)
    s = Replace$(s, "/", vbLf)
    s = Replace$(s, "�b", vbLf)
    s = Replace$(s, "|", vbLf)

    Dim parts As Variant
    parts = Split(s, vbLf)

    Dim i As Long
    For i = LBound(parts) To UBound(parts)
        Call DxaAddTimecardTargetName(result, CStr(parts(i)))
    Next

    Set DxaParseTimecardTargetNames = result
    Exit Function

EH:
    Set DxaParseTimecardTargetNames = New Collection
End Function

Private Sub DxaAddTimecardTargetName(ByVal targetNames As Collection, ByVal targetName As String)
    On Error Resume Next

    Dim normalizedName As String
    normalizedName = DxaNormalizeSpaces(Trim$(targetName))
    If Len(normalizedName) = 0 Then Exit Sub

    Dim newKey As String
    newKey = DxaNormalizeNameForMatch(normalizedName)

    Dim i As Long
    For i = 1 To targetNames.Count
        If DxaNormalizeNameForMatch(CStr(targetNames(i))) = newKey Then Exit Sub
    Next

    targetNames.Add normalizedName
End Sub

Private Function DxaJoinTimecardTargetNames(ByVal targetNames As Collection) As String
    On Error GoTo EH

    Dim s As String
    Dim i As Long
    For i = 1 To targetNames.Count
        If Len(s) > 0 Then s = s & vbCrLf
        s = s & CStr(targetNames(i))
    Next

    DxaJoinTimecardTargetNames = s
    Exit Function

EH:
    DxaJoinTimecardTargetNames = ""
End Function

Private Function DxaJoinTimecardTargetNamesInline(ByVal targetNamesText As String) As String
    On Error GoTo EH

    Dim targetNames As Collection
    Set targetNames = DxaParseTimecardTargetNames(targetNamesText)

    Dim s As String
    Dim i As Long
    For i = 1 To targetNames.Count
        If Len(s) > 0 Then s = s & ", "
        s = s & CStr(targetNames(i))
    Next

    DxaJoinTimecardTargetNamesInline = s
    Exit Function

EH:
    DxaJoinTimecardTargetNamesInline = ""
End Function

Private Function DxaJoinTimecardTargetNamesForMessage(ByVal targetNamesText As String) As String
    On Error GoTo EH

    Dim targetNames As Collection
    Set targetNames = DxaParseTimecardTargetNames(targetNamesText)

    Dim s As String
    Dim i As Long
    For i = 1 To targetNames.Count
        If Len(s) > 0 Then s = s & vbCrLf
        s = s & CStr(i) & ": " & CStr(targetNames(i))
    Next

    DxaJoinTimecardTargetNamesForMessage = s
    Exit Function

EH:
    DxaJoinTimecardTargetNamesForMessage = ""
End Function

Private Function DxaTimecardTargetNameCount(ByVal targetNamesText As String) As Long
    On Error GoTo EH

    Dim targetNames As Collection
    Set targetNames = DxaParseTimecardTargetNames(targetNamesText)
    DxaTimecardTargetNameCount = targetNames.Count
    Exit Function

EH:
    DxaTimecardTargetNameCount = 0
End Function

Private Function DxaTimecardTargetNameFilePath() As String
    On Error GoTo EH

    Dim appData As String
    appData = Environ$("APPDATA")
    If Len(appData) = 0 Then Exit Function

    Dim folderPath As String
    folderPath = appData & "\DelaxTools"
    If Len(Dir$(folderPath, vbDirectory)) = 0 Then MkDir folderPath

    DxaTimecardTargetNameFilePath = folderPath & "\timecard_target_name.dat"
    Exit Function

EH:
    DxaTimecardTargetNameFilePath = ""
End Function

Private Function DxaStringToUtf16Bytes(ByVal valueText As String) As Byte()
    Dim bytes() As Byte
    Dim byteCount As Long

    byteCount = LenB(valueText)
    If byteCount <= 0 Then Exit Function

    ReDim bytes(0 To byteCount - 1)
    DxaCopyMemory VarPtr(bytes(0)), StrPtr(valueText), byteCount
    DxaStringToUtf16Bytes = bytes
End Function

Private Function DxaUtf16BytesToString(ByRef bytes() As Byte) As String
    On Error GoTo EH

    Dim byteCount As Long
    byteCount = DxaByteArrayLength(bytes)
    If byteCount <= 0 Then Exit Function

    Dim charCount As Long
    charCount = byteCount \ 2
    If charCount <= 0 Then Exit Function

    Dim valueText As String
    valueText = String$(charCount, vbNullChar)
    DxaCopyMemory StrPtr(valueText), VarPtr(bytes(LBound(bytes))), byteCount
    DxaUtf16BytesToString = valueText
    Exit Function

EH:
    DxaUtf16BytesToString = ""
End Function

Private Function DxaDpapiProtectBytes(ByRef plainBytes() As Byte) As Byte()
    On Error GoTo EH

    Dim byteCount As Long
    byteCount = DxaByteArrayLength(plainBytes)
    If byteCount <= 0 Then Exit Function

    Dim inBlob As DxaDataBlob
    Dim outBlob As DxaDataBlob
    Dim resultBytes() As Byte

    inBlob.cbData = byteCount
    inBlob.pbData = VarPtr(plainBytes(LBound(plainBytes)))

    If DxaCryptProtectData(inBlob, 0, 0, 0, 0, 0, outBlob) <> 0 Then
        If outBlob.cbData > 0 Then
            ReDim resultBytes(0 To outBlob.cbData - 1)
            DxaCopyMemory VarPtr(resultBytes(0)), outBlob.pbData, outBlob.cbData
            DxaDpapiProtectBytes = resultBytes
        End If
        If outBlob.pbData <> 0 Then Call DxaLocalFree(outBlob.pbData)
    End If
    Exit Function

EH:
    On Error Resume Next
    If outBlob.pbData <> 0 Then Call DxaLocalFree(outBlob.pbData)
End Function

Private Function DxaDpapiUnprotectBytes(ByRef protectedBytes() As Byte) As Byte()
    On Error GoTo EH

    Dim byteCount As Long
    byteCount = DxaByteArrayLength(protectedBytes)
    If byteCount <= 0 Then Exit Function

    Dim inBlob As DxaDataBlob
    Dim outBlob As DxaDataBlob
    Dim resultBytes() As Byte

    inBlob.cbData = byteCount
    inBlob.pbData = VarPtr(protectedBytes(LBound(protectedBytes)))

    If DxaCryptUnprotectData(inBlob, 0, 0, 0, 0, 0, outBlob) <> 0 Then
        If outBlob.cbData > 0 Then
            ReDim resultBytes(0 To outBlob.cbData - 1)
            DxaCopyMemory VarPtr(resultBytes(0)), outBlob.pbData, outBlob.cbData
            DxaDpapiUnprotectBytes = resultBytes
        End If
        If outBlob.pbData <> 0 Then Call DxaLocalFree(outBlob.pbData)
    End If
    Exit Function

EH:
    On Error Resume Next
    If outBlob.pbData <> 0 Then Call DxaLocalFree(outBlob.pbData)
End Function

Private Function DxaBytesToBase64(ByRef bytes() As Byte) As String
    On Error GoTo EH

    If DxaByteArrayLength(bytes) = 0 Then Exit Function

    Dim dom As Object
    Dim node As Object

    Set dom = CreateObject("MSXML2.DOMDocument.6.0")
    Set node = dom.createElement("b64")
    node.DataType = "bin.base64"
    node.nodeTypedValue = bytes
    DxaBytesToBase64 = Replace$(Replace$(node.Text, vbCr, ""), vbLf, "")
    Exit Function

EH:
    DxaBytesToBase64 = ""
End Function

Private Function DxaBase64ToBytes(ByVal base64Text As String) As Byte()
    On Error GoTo EH

    Dim dom As Object
    Dim node As Object
    Dim bytes() As Byte

    If Len(base64Text) = 0 Then Exit Function

    Set dom = CreateObject("MSXML2.DOMDocument.6.0")
    Set node = dom.createElement("b64")
    node.DataType = "bin.base64"
    node.Text = base64Text
    bytes = node.nodeTypedValue
    DxaBase64ToBytes = bytes
    Exit Function

EH:
End Function

Private Function DxaByteArrayLength(ByRef bytes() As Byte) As Long
    On Error GoTo EH
    DxaByteArrayLength = UBound(bytes) - LBound(bytes) + 1
    Exit Function
EH:
    DxaByteArrayLength = 0
End Function

Private Sub DxaWriteTimecardRecords(ByVal records As Collection, ByVal endRoundMode As Long, Optional ByVal targetName As String = "")
    On Error GoTo EH

    Dim wb As Workbook
    Set wb = ActiveWorkbook
    If wb Is Nothing Then Set wb = Workbooks.Add

    Application.ScreenUpdating = False
    Application.DisplayAlerts = False

    Dim ws As Worksheet
    Dim sheetName As String
    sheetName = DxaBuildTimecardSheetName(targetName)

    On Error Resume Next
    Set ws = wb.Worksheets(sheetName)
    On Error GoTo EH
    If Not ws Is Nothing Then ws.Delete

    Set ws = wb.Worksheets.Add(After:=wb.Worksheets(wb.Worksheets.Count))
    ws.Name = sheetName

    Application.DisplayAlerts = True

    ws.Range("A1:E1").Value = Array("���t", "�o�Ύ���", "�ދΎ���", "�擾�o�Ύ���", "�擾�ދΎ���")
    ws.Range("A1:E1").Font.Bold = True
    ws.Range("A1:E1").Interior.Color = RGB(217, 225, 242)
    ws.Columns("A:E").NumberFormatLocal = "@"

    Dim r As Long
    r = 2

    Dim rec As Variant
    Dim rawStart As String
    Dim rawEnd As String
    Dim roundedStart As String
    Dim roundedEnd As String

    For Each rec In records
        rawStart = CStr(rec(1))
        rawEnd = CStr(rec(2))
        roundedStart = DxaRoundTimecardStart(rawStart)
        roundedEnd = DxaRoundTimecardEnd(rawEnd, endRoundMode)

        ws.Cells(r, 1).Value = CStr(rec(0))
        ws.Cells(r, 2).Value = DxaTimecardOutputText(roundedStart)
        ws.Cells(r, 3).Value = DxaTimecardOutputText(roundedEnd)
        ws.Cells(r, 4).Value = DxaTimecardOutputText(rawStart)
        ws.Cells(r, 5).Value = DxaTimecardOutputText(rawEnd)
        r = r + 1
    Next

    ws.Columns("A:E").AutoFit
    ws.Range("A1:E1").AutoFilter
    ws.Activate
    ws.Range("A1").Select

CleanExit:
    Application.DisplayAlerts = True
    Application.ScreenUpdating = True
    Exit Sub

EH:
    Application.DisplayAlerts = True
    Application.ScreenUpdating = True
    Err.Raise Err.Number, Err.Source, Err.Description
End Sub

Private Function DxaFetchTimecardDisplayItems(ByVal timeScreenUrl As String, ByVal managedListUrl As String, ByVal email As String, ByVal password As String) As Collection
    On Error GoTo EH

    Dim cookies As String
    Dim firstHtml As String
    Dim loginHtml As String
    Dim loginPageUrl As String
    Dim loginAction As String
    Dim loginMethod As String
    Dim loginBody As String
    Dim loggedInHtml As String
    Dim timeScreenHtml As String
    Dim managerAction As String
    Dim managerBody As String
    Dim managerHtml As String
    Dim listHtml As String

    firstHtml = DxaHttpRequest("GET", timeScreenUrl, "", cookies, "")

    If DxaLooksLikeManagedList(firstHtml) Then
        listHtml = firstHtml
    ElseIf DxaLooksLikeTimeScreen(firstHtml) Then
        timeScreenHtml = firstHtml
    Else
        loginHtml = DxaResolveTimecardLoginHtml(timeScreenUrl, firstHtml, cookies, loginPageUrl)

        If Len(loginHtml) > 0 Then
            loginAction = DxaExtractFormAction(loginHtml)
            If Len(loginAction) = 0 Then loginAction = loginPageUrl
            loginAction = DxaResolveUrl(loginPageUrl, loginAction)

            loginMethod = DxaExtractFormMethod(loginHtml)
            If Len(loginMethod) = 0 Then loginMethod = "POST"

            loginBody = DxaBuildLoginPostBody(loginHtml, email, password)
            loggedInHtml = DxaSubmitTimecardLoginForm(timeScreenUrl, managedListUrl, loginPageUrl, loginHtml, loginMethod, loginAction, loginBody, cookies)

            If DxaLooksLikeManagedList(loggedInHtml) Then
                listHtml = loggedInHtml
            ElseIf DxaLooksLikeTimeScreen(loggedInHtml) Then
                timeScreenHtml = loggedInHtml
            ElseIf Len(DxaTrimHtml(loggedInHtml)) > 0 And Not DxaLooksLikeSessionError(loggedInHtml) And Not DxaLooksLikeLoginForm(loggedInHtml) Then
                timeScreenHtml = DxaHttpRequest("GET", timeScreenUrl, "", cookies, "")
            End If
        Else
            loggedInHtml = firstHtml
        End If
    End If

    If Len(listHtml) = 0 Then
        If Len(timeScreenHtml) = 0 Or Not DxaLooksLikeTimeScreen(timeScreenHtml) Then
            timeScreenHtml = DxaHttpRequest("GET", timeScreenUrl, "", cookies, "")
        End If

        If DxaLooksLikeManagedList(timeScreenHtml) Then
            listHtml = timeScreenHtml
        End If
    End If

    If Len(listHtml) = 0 Or Not DxaLooksLikeManagedList(listHtml) Then
        If Len(timeScreenHtml) = 0 Or Not DxaLooksLikeTimeScreen(timeScreenHtml) Then
            timeScreenHtml = DxaHttpRequest("GET", timeScreenUrl, "", cookies, "")
        End If

        If DxaLooksLikeManagedList(timeScreenHtml) Then
            listHtml = timeScreenHtml
        ElseIf DxaLooksLikeTimeScreen(timeScreenHtml) Then
            managerAction = managedListUrl
            Dim cookiesBeforeManager As String
            cookiesBeforeManager = cookies
            managerHtml = DxaSubmitTimecardManagerButton(timeScreenUrl, managedListUrl, timeScreenHtml, cookies)

            If DxaLooksLikeManagedList(managerHtml) Then
                listHtml = managerHtml
            Else
                cookies = cookiesBeforeManager
                listHtml = DxaHttpRequest("GET", managedListUrl, "", cookies, "", timeScreenUrl)
            End If
        End If
    End If

    If Len(listHtml) = 0 Or Not DxaLooksLikeManagedList(listHtml) Then
        Dim debugPath As String
        debugPath = DxaSaveTimecardDebugHtml("get_managed_list", listHtml)
        If Len(firstHtml) > 0 Then Call DxaSaveTimecardDebugHtml("first_access", firstHtml)
        If Len(loginHtml) > 0 Then Call DxaSaveTimecardDebugHtml("login_form", loginHtml)
        If Len(loggedInHtml) > 0 Then Call DxaSaveTimecardDebugHtml("login_post_result", loggedInHtml)
        If Len(timeScreenHtml) > 0 Then Call DxaSaveTimecardDebugHtml("time_screen_after_login", timeScreenHtml)
        If Len(managerHtml) > 0 Then Call DxaSaveTimecardDebugHtml("manager_post_result", managerHtml)
        Err.Raise vbObjectError + 621, "DelaxTools", "�Ǘ��ꗗ��ʂ��擾�ł��܂���ł����B" & vbCrLf & _
                 "�������� TimeScreen.jsp �� ���O�C����� �� ���O�C�� �� TimeScreen.jsp �� GetManagedList �ł��B" & vbCrLf & _
                 "�m�F�pHTML�𕡐��ۑ����܂����Bfirst_access / login_script / login_form / login_post_result / time_screen_after_login / manager_post_result ���m�F���Ă��������B" & vbCrLf & _
                 "�m�F�pHTML: " & debugPath
    End If

    Dim candidates As Collection
    Set candidates = DxaParseTimecardUserCandidates(listHtml)

    If candidates Is Nothing Or candidates.Count = 0 Then
        Dim debugListPath As String
        debugListPath = DxaSaveTimecardDebugHtml("managed_list", listHtml)
        Err.Raise vbObjectError + 622, "DelaxTools", "�Ǘ��ꗗ����Αӎ擾�Ώێ҂����o�ł��܂���ł����B" & vbCrLf & _
                 "�Ǘ��ꗗ��ʂ͎擾�ł��Ă��܂����A�Ώێ҃{�^����HTML�\�����z��ƈقȂ�\��������܂��B" & vbCrLf & _
                 "�m�F�pHTML: " & debugListPath
    End If

    Dim selectedUsers As Collection
    Set selectedUsers = DxaResolveTimecardSelectedUsers(candidates)
    If selectedUsers Is Nothing Or selectedUsers.Count = 0 Then
        Set DxaFetchTimecardDisplayItems = New Collection
        Exit Function
    End If

    Dim result As Collection
    Set result = New Collection

    Dim item As Variant
    Dim targetName As String
    Dim userValue As String
    Dim html As String
    For Each item In selectedUsers
        targetName = CStr(item(0))
        userValue = CStr(item(1))
        Application.StatusBar = "DelaxTools: " & targetName & " ����̋Αӈꗗ���擾���Ă��܂�..."
        html = DxaFetchTimecardDisplayHtmlByUserValue(managedListUrl, cookies, userValue, listHtml)
        result.Add Array(targetName, userValue, html)
    Next

    Set DxaFetchTimecardDisplayItems = result
    Exit Function

EH:
    Set DxaFetchTimecardDisplayItems = New Collection
    Err.Raise Err.Number, Err.Source, Err.Description
End Function

Private Function DxaFetchTimecardDisplayHtml(ByVal timeScreenUrl As String, ByVal managedListUrl As String, ByVal email As String, ByVal password As String) As String
    On Error GoTo EH

    Dim cookies As String
    Dim firstHtml As String
    Dim loginHtml As String
    Dim loginPageUrl As String
    Dim loginAction As String
    Dim loginMethod As String
    Dim loginBody As String
    Dim loggedInHtml As String
    Dim timeScreenHtml As String
    Dim managerAction As String
    Dim managerBody As String
    Dim managerHtml As String
    Dim listHtml As String

    ' v152:
    ' 1. �܂��w��URL TimeScreen.jsp �ɃA�N�Z�X���܂��B
    ' 2. �Z�b�V�����؂��ʂ��Ԃ����ꍇ�́A���O�C���{�^��������GET/POST�A�܂���Login�nURL�������ă��O�C���t�H�[�����擾���܂��B
    ' 3. ���O�C���t�H�[����hidden���ڂ͕ێ����ACHECK_SESSION_ID����hidden�l�����[���A�h���X�ŏ㏑�����Ȃ��悤�ɂ��܂��B
    ' 4. ���O�C�����TimeScreen.jsp���Ď擾���A�Ǘ��{�^��������̑J�ڐ�ł���GetManagedList���擾���܂��B
    firstHtml = DxaHttpRequest("GET", timeScreenUrl, "", cookies, "")

    If DxaLooksLikeManagedList(firstHtml) Then
        listHtml = firstHtml
    ElseIf DxaLooksLikeTimeScreen(firstHtml) Then
        timeScreenHtml = firstHtml
    Else
        loginHtml = DxaResolveTimecardLoginHtml(timeScreenUrl, firstHtml, cookies, loginPageUrl)

        If Len(loginHtml) > 0 Then
            loginAction = DxaExtractFormAction(loginHtml)
            If Len(loginAction) = 0 Then loginAction = loginPageUrl
            loginAction = DxaResolveUrl(loginPageUrl, loginAction)

            loginMethod = DxaExtractFormMethod(loginHtml)
            If Len(loginMethod) = 0 Then loginMethod = "POST"

            loginBody = DxaBuildLoginPostBody(loginHtml, email, password)
            loggedInHtml = DxaSubmitTimecardLoginForm(timeScreenUrl, managedListUrl, loginPageUrl, loginHtml, loginMethod, loginAction, loginBody, cookies)

            If DxaLooksLikeManagedList(loggedInHtml) Then
                listHtml = loggedInHtml
            ElseIf DxaLooksLikeTimeScreen(loggedInHtml) Then
                timeScreenHtml = loggedInHtml
            ElseIf Len(DxaTrimHtml(loggedInHtml)) > 0 And Not DxaLooksLikeSessionError(loggedInHtml) And Not DxaLooksLikeLoginForm(loggedInHtml) Then
                timeScreenHtml = DxaHttpRequest("GET", timeScreenUrl, "", cookies, "")
            End If
        Else
            loggedInHtml = firstHtml
        End If
    End If

    ' ���O�C����́ATimeScreen.jsp���Ď擾���Ă���Ǘ��ꗗ�֐i�݂܂��B
    If Len(listHtml) = 0 Then
        If Len(timeScreenHtml) = 0 Or Not DxaLooksLikeTimeScreen(timeScreenHtml) Then
            timeScreenHtml = DxaHttpRequest("GET", timeScreenUrl, "", cookies, "")
        End If

        If DxaLooksLikeManagedList(timeScreenHtml) Then
            listHtml = timeScreenHtml
        End If
    End If

    If Len(listHtml) = 0 Or Not DxaLooksLikeManagedList(listHtml) Then
        ' v152: Do not call GetManagedList by direct GET before simulating the manager button.
        ' The real browser flow is TimeScreen.jsp -> POST mainForm to GetManagedList.
        If Len(timeScreenHtml) = 0 Or Not DxaLooksLikeTimeScreen(timeScreenHtml) Then
            timeScreenHtml = DxaHttpRequest("GET", timeScreenUrl, "", cookies, "")
        End If

        If DxaLooksLikeManagedList(timeScreenHtml) Then
            listHtml = timeScreenHtml
        ElseIf DxaLooksLikeTimeScreen(timeScreenHtml) Then
            managerAction = managedListUrl
            Dim cookiesBeforeManager As String
            cookiesBeforeManager = cookies
            managerHtml = DxaSubmitTimecardManagerButton(timeScreenUrl, managedListUrl, timeScreenHtml, cookies)

            If DxaLooksLikeManagedList(managerHtml) Then
                listHtml = managerHtml
            Else
                ' Last fallback only. Restore the cookie state before trying direct GET.
                cookies = cookiesBeforeManager
                listHtml = DxaHttpRequest("GET", managedListUrl, "", cookies, "", timeScreenUrl)
            End If
        End If
    End If

    If Len(listHtml) = 0 Or Not DxaLooksLikeManagedList(listHtml) Then
        Dim debugPath As String
        debugPath = DxaSaveTimecardDebugHtml("get_managed_list", listHtml)
        If Len(firstHtml) > 0 Then Call DxaSaveTimecardDebugHtml("first_access", firstHtml)
        If Len(loginHtml) > 0 Then Call DxaSaveTimecardDebugHtml("login_form", loginHtml)
        If Len(loggedInHtml) > 0 Then Call DxaSaveTimecardDebugHtml("login_post_result", loggedInHtml)
        If Len(timeScreenHtml) > 0 Then Call DxaSaveTimecardDebugHtml("time_screen_after_login", timeScreenHtml)
        If Len(managerHtml) > 0 Then Call DxaSaveTimecardDebugHtml("manager_post_result", managerHtml)
        Err.Raise vbObjectError + 621, "DelaxTools", "�Ǘ��ꗗ��ʂ��擾�ł��܂���ł����B" & vbCrLf & _
                 "�������� TimeScreen.jsp �� ���O�C����� �� ���O�C�� �� TimeScreen.jsp �� GetManagedList �ł��B" & vbCrLf & _
                 "v157�ł͑ΏێҐݒ��ʂ��ȑf�����Ă��܂��B" & vbCrLf & _
                 "�m�F�pHTML�𕡐��ۑ����܂����Bfirst_access / login_script / login_form / login_post_result / time_screen_after_login / manager_post_result ���m�F���Ă��������B" & vbCrLf & _
                 "�m�F�pHTML: " & debugPath
    End If

    Dim candidates As Collection
    Set candidates = DxaParseTimecardUserCandidates(listHtml)

    If candidates Is Nothing Or candidates.Count = 0 Then
        Dim debugListPath As String
        debugListPath = DxaSaveTimecardDebugHtml("managed_list", listHtml)
        Err.Raise vbObjectError + 622, "DelaxTools", "�Ǘ��ꗗ����Αӎ擾�Ώێ҂����o�ł��܂���ł����B" & vbCrLf & _
                 "�Ǘ��ꗗ��ʂ͎擾�ł��Ă��܂����A�Ώێ҃{�^����HTML�\�����z��ƈقȂ�\��������܂��B" & vbCrLf & _
                 "�m�F�pHTML: " & debugListPath
    End If

    Dim userValue As String
    userValue = DxaPromptTimecardUserSelection(candidates)
    If Len(userValue) = 0 Then
        DxaFetchTimecardDisplayHtml = ""
        Exit Function
    End If

    DxaFetchTimecardDisplayHtml = DxaFetchTimecardDisplayHtmlByUserValue(managedListUrl, cookies, userValue, listHtml)
    Exit Function

EH:
    DxaFetchTimecardDisplayHtml = ""
    Err.Raise Err.Number, Err.Source, Err.Description
End Function

Private Function DxaLooksLikeTimeScreen(ByVal html As String) As Boolean
    ' v152:
    ' �Ǘ��ꗗHTML�ɂ� TimeScreen ������� ManagerForm.js ���̖߂���񂪊܂܂�邽�߁A
    ' TimeScreen / FUNCTION_TIME_SCREEN �̕����񂾂��ł͑ō���ʂƔ��肵�܂���B
    ' ��ɊǗ��ꗗ�̋������������O���A���̂����Łu�Ǘ��{�^�������ō���ʁv�𔻒肵�܂��B
    If Len(DxaTrimHtml(html)) = 0 Then Exit Function
    If DxaLooksLikeSessionError(html) Then Exit Function
    If DxaLooksLikeLoginForm(html) Then Exit Function

    Dim hasManagedListMarker As Boolean
    hasManagedListMarker = (InStr(1, html, "userAttDataBtn", vbTextCompare) > 0) _
                        Or (InStr(1, html, "inputUserDataBtn", vbTextCompare) > 0) _
                        Or (InStr(1, html, "userListArea", vbTextCompare) > 0) _
                        Or ((InStr(1, html, "�Ј��ԍ�", vbTextCompare) > 0) And (InStr(1, html, "����", vbTextCompare) > 0))
    If hasManagedListMarker Then Exit Function

    Dim hasManagerButton As Boolean
    hasManagerButton = (InStr(1, html, "name=""manager""", vbTextCompare) > 0) _
                    Or (InStr(1, html, "name='manager'", vbTextCompare) > 0) _
                    Or (InStr(1, html, "id=""manager""", vbTextCompare) > 0) _
                    Or (InStr(1, html, "id='manager'", vbTextCompare) > 0) _
                    Or (InStr(1, html, "value=""manager""", vbTextCompare) > 0) _
                    Or (InStr(1, html, "value='manager'", vbTextCompare) > 0)

    Dim hasTimeScreenOnlyMarker As Boolean
    hasTimeScreenOnlyMarker = (InStr(1, html, "�^�C���J�[�h��ō�", vbTextCompare) > 0) _
                           Or (InStr(1, html, "class=""workPlace""", vbTextCompare) > 0) _
                           Or (InStr(1, html, "id=""place""", vbTextCompare) > 0) _
                           Or (InStr(1, html, "TimeScreen.js", vbTextCompare) > 0)

    DxaLooksLikeTimeScreen = hasManagerButton Or hasTimeScreenOnlyMarker
End Function

Private Function DxaLooksLikeSessionError(ByVal html As String) As Boolean
    DxaLooksLikeSessionError = (InStr(1, html, "�Z�b�V�������L���ł͂���܂���", vbTextCompare) > 0) _
                            Or (InStr(1, html, "FUNCTION_ERROR", vbTextCompare) > 0) _
                            Or (InStr(1, html, "Error.js", vbTextCompare) > 0)
End Function

Private Function DxaLooksLikeLoginForm(ByVal html As String) As Boolean
    Dim hasPassword As Boolean
    hasPassword = (InStr(1, html, "type=""password""", vbTextCompare) > 0) _
               Or (InStr(1, html, "type='password'", vbTextCompare) > 0) _
               Or (InStr(1, html, "password", vbTextCompare) > 0 And InStr(1, html, "<form", vbTextCompare) > 0) _
               Or (InStr(1, html, "�p�X���[�h", vbTextCompare) > 0 And InStr(1, html, "<form", vbTextCompare) > 0)

    Dim hasLoginMarker As Boolean
    hasLoginMarker = (InStr(1, html, "���O�C��", vbTextCompare) > 0) _
                  Or (InStr(1, html, "login", vbTextCompare) > 0) _
                  Or (InStr(1, html, "mail", vbTextCompare) > 0) _
                  Or (InStr(1, html, "email", vbTextCompare) > 0) _
                  Or (InStr(1, html, "���[��", vbTextCompare) > 0) _
                  Or (InStr(1, html, "���[�U�[", vbTextCompare) > 0) _
                  Or (InStr(1, html, "���[�U", vbTextCompare) > 0)

    DxaLooksLikeLoginForm = hasPassword And hasLoginMarker
End Function

Private Function DxaResolveTimecardLoginHtml(ByVal timeScreenUrl As String, ByVal firstHtml As String, ByRef cookies As String, ByRef loginPageUrl As String) As String
    On Error Resume Next

    If DxaLooksLikeLoginForm(firstHtml) Then
        loginPageUrl = timeScreenUrl
        DxaResolveTimecardLoginHtml = firstHtml
        Exit Function
    End If

    Dim html As String

    ' �Z�b�V����������ʂ̏ꍇ�́A��ʏ�́u���O�C���v�{�^���� Error.js �̑J�ڐ��D�悵�ĉ�͂��܂��B
    html = DxaTryOpenLoginFromSessionError(timeScreenUrl, firstHtml, cookies, loginPageUrl)
    If DxaLooksLikeLoginForm(html) Then
        DxaResolveTimecardLoginHtml = html
        Exit Function
    End If

    ' �Œ�����L�߂Ɏ����܂��B�T�C�g����JSP/Servlet�����ς���Ă��Ǐ]���₷�����܂��B
    Dim candidates As Variant
    candidates = Array( _
        "/AttendanceMgt/Access", _
        "/AttendanceMgt/Login.jsp", _
        "/AttendanceMgt/Login", _
        "/AttendanceMgt/LoginScreen.jsp", _
        "/AttendanceMgt/LoginScreen", _
        "/AttendanceMgt/LoginInit.jsp", _
        "/AttendanceMgt/LoginInit", _
        "/AttendanceMgt/LoginAction", _
        "/AttendanceMgt/LoginController", _
        "/AttendanceMgt/LoginServlet", _
        "/AttendanceMgt/Index.jsp", _
        "/AttendanceMgt/Index", _
        "/AttendanceMgt/index.jsp", _
        "/AttendanceMgt/index", _
        "/AttendanceMgt/" _
    )

    html = DxaTryOpenLoginCandidateUrls(timeScreenUrl, firstHtml, cookies, loginPageUrl, candidates)
    If DxaLooksLikeLoginForm(html) Then
        DxaResolveTimecardLoginHtml = html
        Exit Function
    End If

    loginPageUrl = timeScreenUrl
    DxaResolveTimecardLoginHtml = ""
End Function

Private Function DxaTryOpenLoginFromSessionError(ByVal timeScreenUrl As String, ByVal errorHtml As String, ByRef cookies As String, ByRef loginPageUrl As String) As String
    On Error Resume Next

    If Not DxaLooksLikeSessionError(errorHtml) Then Exit Function

    Dim html As String

    ' 1. �܂��̓u���E�U�̒ʏ�submit�ɋ߂��`�ŁAhidden���ڂ݂̂𑗐M���܂��B
    html = DxaTrySubmitSessionErrorForm(timeScreenUrl, errorHtml, cookies, loginPageUrl)
    If DxaLooksLikeLoginForm(html) Then
        DxaTryOpenLoginFromSessionError = html
        Exit Function
    End If

    ' 2. Error.js���� action / location.href �Ȃǂ��烍�O�C����ʂ�URL�𐄒肵�܂��B
    html = DxaTryOpenLoginFromSessionScripts(timeScreenUrl, errorHtml, cookies, loginPageUrl)
    If DxaLooksLikeLoginForm(html) Then
        DxaTryOpenLoginFromSessionError = html
        Exit Function
    End If
End Function

Private Function DxaTrySubmitSessionErrorForm(ByVal timeScreenUrl As String, ByVal errorHtml As String, ByRef cookies As String, ByRef loginPageUrl As String) As String
    On Error Resume Next

    Dim actionUrl As String
    Dim methodName As String
    Dim body As String
    Dim html As String

    actionUrl = DxaExtractFormAction(errorHtml)
    If Len(actionUrl) = 0 Then actionUrl = timeScreenUrl
    actionUrl = DxaResolveUrl(timeScreenUrl, actionUrl)

    methodName = DxaExtractFormMethod(errorHtml)
    If Len(methodName) = 0 Then methodName = "GET"

    ' button��name���Ȃ���ʂł́A�u���E�U��login=login�𑗐M���܂���B
    ' ���̂��ߍŏ���hidden���ڂ����ő���܂��B
    body = DxaDictionaryToPostBody(DxaExtractInputDictionary(errorHtml))
    html = DxaHttpSubmitForm(methodName, actionUrl, body, cookies)
    If DxaLooksLikeLoginForm(html) Then
        loginPageUrl = actionUrl
        DxaTrySubmitSessionErrorForm = html
        Exit Function
    End If

    ' �݊��p�F�������Ɠ��� login=login �t���������܂��B
    body = DxaBuildPostBodyWithButton(errorHtml, "login", "login")
    html = DxaHttpSubmitForm(methodName, actionUrl, body, cookies)
    If DxaLooksLikeLoginForm(html) Then
        loginPageUrl = actionUrl
        DxaTrySubmitSessionErrorForm = html
        Exit Function
    End If

    ' FUNCTION_NAME�����O�C���n�ɍ����ւ���p�^�[���������܂��B
    Dim fnNames As Variant
    fnNames = Array("FUNCTION_LOGIN", "FUNCTION_LOGIN_SCREEN", "FUNCTION_LOGIN_INIT", "FUNCTION_SHOW_LOGIN", "FUNCTION_ERROR_LOGIN", "LOGIN", "login")

    Dim i As Long
    Dim dict As Object
    For i = LBound(fnNames) To UBound(fnNames)
        Set dict = DxaExtractInputDictionary(errorHtml)
        dict("FUNCTION_NAME") = CStr(fnNames(i))
        body = DxaDictionaryToPostBody(dict)

        html = DxaHttpSubmitForm(methodName, actionUrl, body, cookies)
        If DxaLooksLikeLoginForm(html) Then
            loginPageUrl = actionUrl
            DxaTrySubmitSessionErrorForm = html
            Exit Function
        End If
    Next
End Function

Private Function DxaTryOpenLoginFromSessionScripts(ByVal timeScreenUrl As String, ByVal errorHtml As String, ByRef cookies As String, ByRef loginPageUrl As String) As String
    On Error Resume Next

    Dim scriptUrls As Collection
    Set scriptUrls = DxaExtractScriptSrcUrls(timeScreenUrl, errorHtml)
    If scriptUrls Is Nothing Then Exit Function

    Dim allCandidates As Collection
    Set allCandidates = New Collection

    Dim i As Long
    Dim jsUrl As String
    Dim jsText As String
    For i = 1 To scriptUrls.Count
        jsUrl = CStr(scriptUrls(i))
        jsText = DxaHttpRequest("GET", jsUrl, "", cookies, "")
        If Len(jsText) > 0 Then
            Call DxaSaveTimecardDebugHtml("login_script_" & CStr(i), jsText)
            Call DxaAddLoginCandidatesFromScript(allCandidates, timeScreenUrl, jsText)
        End If
    Next

    Dim candidates As Variant
    candidates = DxaCollectionToStringArray(allCandidates)
    If IsEmpty(candidates) Then Exit Function

    DxaTryOpenLoginFromSessionScripts = DxaTryOpenLoginCandidateUrls(timeScreenUrl, errorHtml, cookies, loginPageUrl, candidates)
End Function

Private Function DxaTryOpenLoginCandidateUrls(ByVal timeScreenUrl As String, ByVal baseHtml As String, ByRef cookies As String, ByRef loginPageUrl As String, ByVal candidates As Variant) As String
    On Error Resume Next

    Dim i As Long
    Dim url As String
    Dim html As String
    Dim baseBody As String
    Dim loginBody As String

    baseBody = DxaDictionaryToPostBody(DxaExtractInputDictionary(baseHtml))
    loginBody = DxaBuildPostBodyWithButton(baseHtml, "login", "login")

    For i = LBound(candidates) To UBound(candidates)
        url = DxaResolveUrl(timeScreenUrl, CStr(candidates(i)))
        If Len(url) > 0 Then
            html = DxaHttpRequest("GET", url, "", cookies, "")
            If DxaLooksLikeLoginForm(html) Then
                loginPageUrl = url
                DxaTryOpenLoginCandidateUrls = html
                Exit Function
            End If

            If Len(baseBody) > 0 Then
                html = DxaHttpRequest("GET", DxaAppendQueryString(url, baseBody), "", cookies, "")
                If DxaLooksLikeLoginForm(html) Then
                    loginPageUrl = url
                    DxaTryOpenLoginCandidateUrls = html
                    Exit Function
                End If

                html = DxaHttpRequest("POST", url, baseBody, cookies, "application/x-www-form-urlencoded")
                If DxaLooksLikeLoginForm(html) Then
                    loginPageUrl = url
                    DxaTryOpenLoginCandidateUrls = html
                    Exit Function
                End If
            End If

            If Len(loginBody) > 0 Then
                html = DxaHttpRequest("POST", url, loginBody, cookies, "application/x-www-form-urlencoded")
                If DxaLooksLikeLoginForm(html) Then
                    loginPageUrl = url
                    DxaTryOpenLoginCandidateUrls = html
                    Exit Function
                End If
            End If

            Dim fnNames As Variant
            fnNames = Array("FUNCTION_LOGIN", "FUNCTION_LOGIN_SCREEN", "FUNCTION_LOGIN_INIT", "FUNCTION_SHOW_LOGIN", "FUNCTION_ERROR_LOGIN", "LOGIN", "login")

            Dim k As Long
            Dim dict As Object
            Dim fnBody As String
            For k = LBound(fnNames) To UBound(fnNames)
                Set dict = DxaExtractInputDictionary(baseHtml)
                dict("FUNCTION_NAME") = CStr(fnNames(k))
                fnBody = DxaDictionaryToPostBody(dict)

                html = DxaHttpRequest("GET", DxaAppendQueryString(url, fnBody), "", cookies, "")
                If DxaLooksLikeLoginForm(html) Then
                    loginPageUrl = url
                    DxaTryOpenLoginCandidateUrls = html
                    Exit Function
                End If

                html = DxaHttpRequest("POST", url, fnBody, cookies, "application/x-www-form-urlencoded")
                If DxaLooksLikeLoginForm(html) Then
                    loginPageUrl = url
                    DxaTryOpenLoginCandidateUrls = html
                    Exit Function
                End If
            Next
        End If
    Next

    If Len(html) > 0 Then Call DxaSaveTimecardDebugHtml("login_attempt_last", html)
End Function

Private Function DxaExtractScriptSrcUrls(ByVal baseUrl As String, ByVal html As String) As Collection
    On Error GoTo EH

    Dim result As Collection
    Set result = New Collection

    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = True
    re.Pattern = "<script[^>]*src\s*=\s*([""'])(.*?)\1"

    Dim ms As Object
    Set ms = re.Execute(html)

    Dim m As Object
    For Each m In ms
        Call DxaAddUniqueString(result, DxaResolveUrl(baseUrl, CStr(m.SubMatches(1))))
    Next

    Set DxaExtractScriptSrcUrls = result
    Exit Function
EH:
    Set DxaExtractScriptSrcUrls = New Collection
End Function

Private Sub DxaAddLoginCandidatesFromScript(ByVal candidates As Collection, ByVal baseUrl As String, ByVal jsText As String)
    On Error Resume Next

    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = True
    re.Pattern = """([^""]+)""|'([^']+)'"

    Dim ms As Object
    Set ms = re.Execute(jsText)

    Call DxaAddFormActionAssignmentsFromScript(candidates, baseUrl, jsText)

    Dim m As Object
    For Each m In ms
        Dim s As String
        s = CStr(m.SubMatches(0))
        If Len(s) = 0 Then s = CStr(m.SubMatches(1))
        s = Trim$(s)

        If DxaLooksLikeLoginUrlCandidate(s) Then
            Call DxaAddUniqueString(candidates, DxaResolveUrl(baseUrl, s))
        End If
    Next

    ' JS������URL�𕶎���Ŏ����Ă��Ȃ��ꍇ�ɔ������⏕���ł��B
    ' Error.js�ł� document.mainForm.action = "/AttendanceMgt/Access" �Ń��O�C����ʂ֑J�ڂ��܂��B
    Call DxaAddUniqueString(candidates, DxaResolveUrl(baseUrl, "/AttendanceMgt/Access"))
    Call DxaAddUniqueString(candidates, DxaResolveUrl(baseUrl, "/AttendanceMgt/Login"))
    Call DxaAddUniqueString(candidates, DxaResolveUrl(baseUrl, "/AttendanceMgt/Login.jsp"))
    Call DxaAddUniqueString(candidates, DxaResolveUrl(baseUrl, "/AttendanceMgt/LoginScreen"))
    Call DxaAddUniqueString(candidates, DxaResolveUrl(baseUrl, "/AttendanceMgt/LoginScreen.jsp"))
End Sub

Private Function DxaLooksLikeLoginUrlCandidate(ByVal text As String) As Boolean
    Dim s As String
    s = Trim$(text)
    If Len(s) = 0 Then Exit Function
    If Left$(s, 1) = "#" Then Exit Function
    If Left$(s, 1) = "." Then Exit Function
    If InStr(1, s, " ", vbTextCompare) > 0 Then Exit Function
    If InStr(1, s, "function", vbTextCompare) > 0 Then Exit Function
    If InStr(1, s, "click", vbTextCompare) > 0 Then Exit Function

    If InStr(1, s, "AttendanceMgt/Access", vbTextCompare) > 0 _
       Or StrComp(s, "/AttendanceMgt/Access", vbTextCompare) = 0 _
       Or StrComp(s, "Access", vbTextCompare) = 0 Then
        DxaLooksLikeLoginUrlCandidate = True
    ElseIf InStr(1, s, "login", vbTextCompare) > 0 Then
        DxaLooksLikeLoginUrlCandidate = True
    ElseIf InStr(1, s, "Login", vbTextCompare) > 0 Then
        DxaLooksLikeLoginUrlCandidate = True
    ElseIf InStr(1, s, "���O�C��", vbTextCompare) > 0 Then
        DxaLooksLikeLoginUrlCandidate = True
    End If
End Function

Private Sub DxaAddUniqueString(ByVal items As Collection, ByVal value As String)
    On Error Resume Next
    Dim s As String
    s = Trim$(value)
    If Len(s) = 0 Then Exit Sub

    Dim i As Long
    For i = 1 To items.Count
        If StrComp(CStr(items(i)), s, vbTextCompare) = 0 Then Exit Sub
    Next
    items.Add s
End Sub

Private Function DxaCollectionToStringArray(ByVal items As Collection) As Variant
    If items Is Nothing Then
        DxaCollectionToStringArray = Empty
        Exit Function
    End If
    If items.Count = 0 Then
        DxaCollectionToStringArray = Empty
        Exit Function
    End If

    Dim arr() As String
    ReDim arr(0 To items.Count - 1)

    Dim i As Long
    For i = 1 To items.Count
        arr(i - 1) = CStr(items(i))
    Next

    DxaCollectionToStringArray = arr
End Function

Private Function DxaHttpSubmitForm(ByVal methodName As String, ByVal actionUrl As String, ByVal body As String, ByRef cookies As String) As String
    If UCase$(Trim$(methodName)) = "GET" Then
        DxaHttpSubmitForm = DxaHttpRequest("GET", DxaAppendQueryString(actionUrl, body), "", cookies, "")
    Else
        DxaHttpSubmitForm = DxaHttpRequest("POST", actionUrl, body, cookies, "application/x-www-form-urlencoded")
    End If
End Function
Private Function DxaSubmitTimecardManagerButton(ByVal timeScreenUrl As String, ByVal managedListUrl As String, ByVal timeScreenHtml As String, ByRef cookies As String) As String
    On Error Resume Next

    Dim candidates As Collection
    Set candidates = New Collection

    ' v148�d�v:
    ' �Ǘ��{�^���ȊO��URL���΂Ɍ��֓���Ȃ��B
    ' TimeScreen.js�ɂ͏o�΁E�ދ΁E�Ζ��n�ݒ�E�����̋Αӈꗗ�Ȃǂ�action���܂܂�邽�߁A
    ' �������@�B�I�Ɍ��֓����ƁA�ʃ{�^�������̏����ɂȂ�댯������܂��B
    ' �����ł̓��[�U�[�m�F�ς݂̊Ǘ��J�ڐ� GetManagedList �݂̂�Ώۂɂ��܂��B
    Call DxaAddUniqueString(candidates, managedListUrl)
    Call DxaAddUniqueString(candidates, DxaResolveUrl(timeScreenUrl, "/AttendanceMgt/GetManagedList"))

    ' TimeScreen.js���� manager �{�^���ɕR�Â� GetManagedList ���L�ڂ���Ă���ꍇ�̂݌��֒ǉ����܂��B
    Dim scriptUrls As Collection
    Set scriptUrls = DxaExtractScriptSrcUrls(timeScreenUrl, timeScreenHtml)

    Dim i As Long
    Dim jsUrl As String
    Dim jsText As String
    If Not scriptUrls Is Nothing Then
        For i = 1 To scriptUrls.Count
            jsUrl = CStr(scriptUrls(i))
            jsText = DxaHttpRequest("GET", jsUrl, "", cookies, "")
            If Len(jsText) > 0 Then
                Call DxaSaveTimecardDebugHtml("time_screen_script_" & CStr(i), jsText)
                Call DxaAddManagerCandidatesFromScript(candidates, timeScreenUrl, jsText)
            End If
        Next
    End If

    Dim baseBody As String
    Dim managerBody As String
    Dim dict As Object

    Set dict = DxaExtractInputDictionary(timeScreenHtml)
    Call DxaNormalizeTimeScreenFormDictionary(dict)
    baseBody = DxaDictionaryToPostBody(dict)

    If Len(baseBody) > 0 Then Call DxaSaveTimecardDebugHtml("manager_post_body", baseBody)

    Dim bodies As Collection
    Set bodies = New Collection
    ' v152:
    ' ���[�U�[��DevTools�Ŋm�F����GetManagedList��Form Data�Ɠ������ڂ����𑗐M���܂��B
    ' ���u���E�U��POST�ɂ� manager=manager �� FUNCTION_NAME�����ւ��͊܂܂�Ă��Ȃ��������߁A
    ' �����p�^�[���͑��炸�ATimeScreen.jsp��mainForm�l�����̂܂܎g�p���܂��B
    If Len(baseBody) > 0 Then bodies.Add baseBody

    Dim actionUrl As String
    Dim html As String
    Dim lastHtml As String
    Dim j As Long
    Dim trialCookies As String

    For i = 1 To candidates.Count
        actionUrl = CStr(candidates(i))
        If Len(actionUrl) = 0 Then GoTo ContinueCandidate
        If Not DxaLooksLikeManagerUrlCandidate(actionUrl) Then GoTo ContinueCandidate

        For j = 1 To bodies.Count
            trialCookies = cookies
            html = DxaHttpRequest("POST", actionUrl, CStr(bodies(j)), trialCookies, "application/x-www-form-urlencoded", timeScreenUrl)
            If Len(DxaTrimHtml(html)) > 0 Then lastHtml = html
            If DxaLooksLikeManagedList(html) Then
                cookies = trialCookies
                DxaSubmitTimecardManagerButton = html
                Exit Function
            End If
        Next

ContinueCandidate:
    Next

    If Len(lastHtml) > 0 Then Call DxaSaveTimecardDebugHtml("manager_post_result", lastHtml)
    DxaSubmitTimecardManagerButton = lastHtml
End Function

Private Sub DxaAddManagerCandidatesFromScript(ByVal candidates As Collection, ByVal baseUrl As String, ByVal jsText As String)
    On Error Resume Next

    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = True
    re.Pattern = """([^""]+)""|'([^']+)'"

    Dim ms As Object
    Set ms = re.Execute(jsText)

    Dim m As Object
    For Each m In ms
        Dim s As String
        s = CStr(m.SubMatches(0))
        If Len(s) = 0 Then s = CStr(m.SubMatches(1))
        s = Trim$(s)

        If DxaLooksLikeManagerUrlCandidate(s) Then
            Call DxaAddUniqueString(candidates, DxaResolveUrl(baseUrl, s))
        End If
    Next
End Sub

Private Function DxaLooksLikeManagerUrlCandidate(ByVal text As String) As Boolean
    Dim s As String
    s = Trim$(text)
    If Len(s) = 0 Then Exit Function
    If Left$(s, 1) = "#" Then Exit Function
    If Left$(s, 1) = "." Then Exit Function
    If InStr(1, s, " ", vbTextCompare) > 0 Then Exit Function
    If InStr(1, s, "function", vbTextCompare) > 0 Then Exit Function
    If InStr(1, s, "click", vbTextCompare) > 0 Then Exit Function

    DxaLooksLikeManagerUrlCandidate = (InStr(1, s, "GetManagedList", vbTextCompare) > 0) _
                                   Or (InStr(1, s, "ManagedList", vbTextCompare) > 0) _
                                   Or (InStr(1, s, "manager", vbTextCompare) > 0 And InStr(1, s, "AttendanceMgt", vbTextCompare) > 0)
End Function

Private Function DxaAppendQueryString(ByVal url As String, ByVal body As String) As String
    If Len(body) = 0 Then
        DxaAppendQueryString = url
    ElseIf InStr(1, url, "?", vbTextCompare) > 0 Then
        DxaAppendQueryString = url & "&" & body
    Else
        DxaAppendQueryString = url & "?" & body
    End If
End Function
Private Function DxaFetchTimecardDisplayHtmlByUserValue(ByVal managedListUrl As String, ByRef cookies As String, ByVal userValue As String, ByVal listHtml As String) As String
    On Error GoTo EH

    Dim displayUrl As String
    displayUrl = DxaResolveUrl(managedListUrl, "/AttendanceMgt/DisplayList")

    ' v152:
    ' ManagerForm.js �̎�����́A�I�����ꂽ userAttDataBtn.value �� hidden �� dispUserId �ɃZ�b�g���A
    ' mainForm �� /AttendanceMgt/DisplayList �� POST ����`�ł��B
    ' button �����̂��̂� Form Data �ɓ���Ȃ����߁A�܂����̎��u���E�U������POST�����s���܂��B
    Dim body As String
    Dim html As String

    body = DxaBuildManagedListUserDisplayBody(listHtml, userValue)
    If Len(body) > 0 Then Call DxaSaveTimecardDebugHtml("display_list_post_body", body)

    html = DxaHttpRequest("POST", displayUrl, body, cookies, "application/x-www-form-urlencoded", managedListUrl)
    If DxaLooksLikeAttendanceDisplay(html) Then
        DxaFetchTimecardDisplayHtmlByUserValue = html
        Exit Function
    End If

    If Len(DxaTrimHtml(html)) > 0 Then Call DxaSaveTimecardDebugHtml("display_list_post_result", html)

    ' Fallbacks for older/alternate HTML structures.
    Dim endpoints As Variant
    endpoints = Array(displayUrl, managedListUrl)

    Dim postNames As Variant
    postNames = Array("dispUserId", "userAttDataBtn", "inputUserDataBtn", "targetUserId", "userId", "id")

    Dim i As Long
    Dim j As Long

    For i = LBound(endpoints) To UBound(endpoints)
        For j = LBound(postNames) To UBound(postNames)
            body = DxaBuildPostBodyWithButton(listHtml, CStr(postNames(j)), userValue)
            html = DxaHttpRequest("POST", CStr(endpoints(i)), body, cookies, "application/x-www-form-urlencoded", managedListUrl)
            If DxaLooksLikeAttendanceDisplay(html) Then
                DxaFetchTimecardDisplayHtmlByUserValue = html
                Exit Function
            End If
        Next
    Next

    html = DxaHttpRequest("GET", displayUrl & "?dispUserId=" & DxaUrlEncode(userValue), "", cookies, "", managedListUrl)
    If DxaLooksLikeAttendanceDisplay(html) Then
        DxaFetchTimecardDisplayHtmlByUserValue = html
        Exit Function
    End If

    html = DxaHttpRequest("GET", displayUrl & "?userAttDataBtn=" & DxaUrlEncode(userValue), "", cookies, "", managedListUrl)
    If DxaLooksLikeAttendanceDisplay(html) Then
        DxaFetchTimecardDisplayHtmlByUserValue = html
        Exit Function
    End If

    Err.Raise vbObjectError + 622, "DelaxTools", "�Ώێ҂̋Αӈꗗ��ʂ֑J�ڂł��܂���ł����B�T�C�g���̑��M���ڂ��ύX����Ă���\��������܂��B" & vbCrLf & _
             "�m�F�pHTML�Ƃ��� display_list_post_body / display_list_post_result ��ۑ����Ă���ꍇ������܂��B"
    Exit Function

EH:
    DxaFetchTimecardDisplayHtmlByUserValue = ""
    Err.Raise Err.Number, Err.Source, Err.Description
End Function

Private Function DxaBuildManagedListUserDisplayBody(ByVal listHtml As String, ByVal userValue As String) As String
    On Error Resume Next

    Dim dict As Object
    Set dict = DxaExtractInputDictionary(listHtml)

    If dict Is Nothing Then Set dict = CreateObject("Scripting.Dictionary")

    dict("dispUserId") = userValue
    If Not dict.Exists("monthFlg") Then dict("monthFlg") = "thisMonth"
    If Not dict.Exists("FUNCTION_NAME") Then dict("FUNCTION_NAME") = "FUNCTION_MANAGER_FORM"

    DxaBuildManagedListUserDisplayBody = DxaDictionaryToPostBody(dict)
End Function

Private Function DxaLooksLikeManagedList(ByVal html As String) As Boolean
    ' v152:
    ' �O�񃍃O�ł� manager_post_result �ɊǗ��ꗗHTML���Ԃ��Ă��܂������A
    ' �����̃X�N���v�g���� TimeScreen �����񂪊܂܂ꂽ���� TimeScreen.jsp �ƌ딻�肵�Ă��܂����B
    ' ���̂��߁A�Ǘ��ꗗ�̋����������ɕ]�����A�Y������ΊǗ��ꗗ�Ƃ��Ĉ����܂��B
    If Len(DxaTrimHtml(html)) = 0 Then Exit Function
    If DxaLooksLikeSessionError(html) Then Exit Function
    If DxaLooksLikeLoginForm(html) Then Exit Function

    Dim hasUserButton As Boolean
    hasUserButton = (InStr(1, html, "userAttDataBtn", vbTextCompare) > 0) _
                 Or (InStr(1, html, "inputUserDataBtn", vbTextCompare) > 0)

    Dim hasManagedHeaders As Boolean
    hasManagedHeaders = ((InStr(1, html, "�Ј��ԍ�", vbTextCompare) > 0) And (InStr(1, html, "����", vbTextCompare) > 0)) _
                     Or ((InStr(1, html, "����ԍ�", vbTextCompare) > 0) And (InStr(1, html, "�Αӈꗗ", vbTextCompare) > 0)) _
                     Or ((InStr(1, html, "�����ԍ�", vbTextCompare) > 0) And (InStr(1, html, "�Α�", vbTextCompare) > 0)) _
                     Or ((InStr(1, html, "userListArea", vbTextCompare) > 0) And (InStr(1, html, "<tr", vbTextCompare) > 0)) _
                     Or ((InStr(1, html, "userName", vbTextCompare) > 0) And (InStr(1, html, "<tr", vbTextCompare) > 0))

    Dim hasAttendanceListButtonInTable As Boolean
    hasAttendanceListButtonInTable = (InStr(1, html, "�Αӈꗗ", vbTextCompare) > 0) _
                                  And (InStr(1, html, "<tr", vbTextCompare) > 0) _
                                  And ((InStr(1, html, "�Ј��ԍ�", vbTextCompare) > 0) _
                                    Or (InStr(1, html, "����", vbTextCompare) > 0) _
                                    Or (InStr(1, html, "userAttDataBtn", vbTextCompare) > 0) _
                                    Or (InStr(1, html, "inputUserDataBtn", vbTextCompare) > 0))

    If hasUserButton Or hasManagedHeaders Or hasAttendanceListButtonInTable Then
        DxaLooksLikeManagedList = True
        Exit Function
    End If

    If DxaLooksLikeTimeScreen(html) Then Exit Function
End Function

Private Function DxaSaveTimecardDebugHtml(ByVal stageName As String, ByVal html As String) As String
    On Error GoTo EH
    Dim folderPath As String
    folderPath = Environ$("APPDATA") & "\DelaxTools\logs"
    DxaEnsureFolder folderPath

    Dim path As String
    path = folderPath & "\timecard_" & stageName & "_" & Format$(Now, "yyyymmdd_hhnnss") & ".html"

    Dim stm As Object
    Set stm = CreateObject("ADODB.Stream")
    stm.Type = 2
    stm.Charset = "utf-8"
    stm.Open
    stm.WriteText html
    stm.SaveToFile path, 2
    stm.Close

    DxaSaveTimecardDebugHtml = path
    Exit Function
EH:
    DxaSaveTimecardDebugHtml = "(�ۑ����s)"
End Function

Private Function DxaExtractFormAction(ByVal html As String) As String
    On Error Resume Next
    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = False
    re.IgnoreCase = True
    re.Pattern = "<form[^>]*>"

    Dim ms As Object
    Set ms = re.Execute(html)
    If ms.Count > 0 Then DxaExtractFormAction = DxaExtractAttributeValue(CStr(ms(0).Value), "action")
End Function


Private Function DxaExtractFormMethod(ByVal html As String) As String
    On Error Resume Next
    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = False
    re.IgnoreCase = True
    re.Pattern = "<form[^>]*>"

    Dim ms As Object
    Set ms = re.Execute(html)
    If ms.Count > 0 Then DxaExtractFormMethod = UCase$(DxaExtractAttributeValue(CStr(ms(0).Value), "method"))
End Function

Private Function DxaSubmitTimecardLoginForm(ByVal timeScreenUrl As String, ByVal managedListUrl As String, ByVal loginPageUrl As String, ByVal loginHtml As String, ByVal preferredMethod As String, ByVal formActionUrl As String, ByVal loginBody As String, ByRef cookies As String) As String
    On Error Resume Next

    Dim candidates As Collection
    Set candidates = New Collection

    Call DxaAddLoginFormSubmitCandidates(candidates, loginPageUrl, loginHtml, cookies)

    ' Browser click on the login button normally changes mainForm.action in LoginForm.js.
    ' Therefore, script-derived actions and common login endpoints must be tried before the blank form action resolved to /Access.
    Call DxaAddUniqueString(candidates, DxaResolveUrl(loginPageUrl, "/AttendanceMgt/Login"))
    Call DxaAddUniqueString(candidates, DxaResolveUrl(loginPageUrl, "/AttendanceMgt/LoginAction"))
    Call DxaAddUniqueString(candidates, DxaResolveUrl(loginPageUrl, "/AttendanceMgt/LoginController"))
    Call DxaAddUniqueString(candidates, DxaResolveUrl(loginPageUrl, "/AttendanceMgt/LoginServlet"))
    Call DxaAddUniqueString(candidates, DxaResolveUrl(loginPageUrl, "/AttendanceMgt/UserLogin"))
    Call DxaAddUniqueString(candidates, DxaResolveUrl(loginPageUrl, "/AttendanceMgt/CheckLogin"))
    Call DxaAddUniqueString(candidates, DxaResolveUrl(loginPageUrl, "/AttendanceMgt/LoginCheck"))
    Call DxaAddUniqueString(candidates, DxaResolveUrl(loginPageUrl, "/AttendanceMgt/LoginAuth"))
    Call DxaAddUniqueString(candidates, DxaResolveUrl(loginPageUrl, "/AttendanceMgt/Auth"))
    If Len(formActionUrl) > 0 Then Call DxaAddUniqueString(candidates, formActionUrl)
    Call DxaAddUniqueString(candidates, DxaResolveUrl(loginPageUrl, "/AttendanceMgt/Access"))

    Dim methods As Variant
    methods = Array(preferredMethod, "POST", "GET")

    Dim i As Long
    Dim j As Long
    Dim actionUrl As String
    Dim methodName As String
    Dim html As String
    Dim checkHtml As String
    Dim listHtml As String
    Dim lastHtml As String

    For i = 1 To candidates.Count
        actionUrl = CStr(candidates(i))
        If Len(actionUrl) = 0 Then GoTo ContinueCandidate

        For j = LBound(methods) To UBound(methods)
            methodName = UCase$(Trim$(CStr(methods(j))))
            If Len(methodName) = 0 Then methodName = "POST"
            If j > LBound(methods) Then
                If UCase$(Trim$(CStr(methods(j)))) = UCase$(Trim$(CStr(methods(j - 1)))) Then GoTo ContinueMethod
            End If

            html = DxaHttpSubmitForm(methodName, actionUrl, loginBody, cookies)
            If Len(DxaTrimHtml(html)) > 0 Then lastHtml = html

            If DxaLooksLikeManagedList(html) Or DxaLooksLikeTimeScreen(html) Then
                DxaSubmitTimecardLoginForm = html
                Exit Function
            End If

            listHtml = DxaHttpRequest("GET", managedListUrl, "", cookies, "")
            If DxaLooksLikeManagedList(listHtml) Then
                DxaSubmitTimecardLoginForm = listHtml
                Exit Function
            End If

            checkHtml = DxaHttpRequest("GET", timeScreenUrl, "", cookies, "")
            If DxaLooksLikeManagedList(checkHtml) Or DxaLooksLikeTimeScreen(checkHtml) Then
                DxaSubmitTimecardLoginForm = checkHtml
                Exit Function
            End If

ContinueMethod:
        Next
ContinueCandidate:
    Next

    If Len(lastHtml) > 0 Then Call DxaSaveTimecardDebugHtml("login_post_result", lastHtml)
    DxaSubmitTimecardLoginForm = lastHtml
End Function

Private Sub DxaAddLoginFormSubmitCandidates(ByVal candidates As Collection, ByVal loginPageUrl As String, ByVal loginHtml As String, ByRef cookies As String)
    On Error Resume Next

    Dim scriptUrls As Collection
    Set scriptUrls = DxaExtractScriptSrcUrls(loginPageUrl, loginHtml)
    If scriptUrls Is Nothing Then Exit Sub

    Dim i As Long
    Dim jsUrl As String
    Dim jsText As String

    For i = 1 To scriptUrls.Count
        jsUrl = CStr(scriptUrls(i))
        jsText = DxaHttpRequest("GET", jsUrl, "", cookies, "")
        If Len(jsText) > 0 Then
            Call DxaSaveTimecardDebugHtml("login_form_script_" & CStr(i), jsText)
            Call DxaAddFormActionAssignmentsFromScript(candidates, loginPageUrl, jsText)
            Call DxaAddLoginCandidatesFromScript(candidates, loginPageUrl, jsText)
        End If
    Next
End Sub

Private Sub DxaAddFormActionAssignmentsFromScript(ByVal candidates As Collection, ByVal baseUrl As String, ByVal jsText As String)
    On Error Resume Next

    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = True
    re.Pattern = "mainForm\.action\s*=\s*([""'])(.*?)\1"

    Dim ms As Object
    Set ms = re.Execute(jsText)

    Dim m As Object
    For Each m In ms
        Dim actionText As String
        actionText = Trim$(CStr(m.SubMatches(1)))
        If Len(actionText) > 0 Then
            If Left$(actionText, 1) = "/" Or LCase$(Left$(actionText, 4)) = "http" Or InStr(1, actionText, "AttendanceMgt", vbTextCompare) > 0 Then
                Call DxaAddUniqueString(candidates, DxaResolveUrl(baseUrl, actionText))
            End If
        End If
    Next
End Sub

Private Function DxaTrimHtml(ByVal html As String) As String
    Dim s As String
    s = Replace$(html, ChrW$(&HFEFF), "")
    s = Replace$(s, vbCr, "")
    s = Replace$(s, vbLf, "")
    s = Replace$(s, vbTab, "")
    DxaTrimHtml = Trim$(s)
End Function

Private Function DxaBuildLoginPostBody(ByVal html As String, ByVal email As String, ByVal password As String) As String
    On Error GoTo EH

    Dim dict As Object
    Set dict = DxaExtractInputDictionary(html)

    Dim emailKey As String
    Dim passKey As String
    emailKey = DxaFindLoginInputName(html, False)
    passKey = DxaFindLoginInputName(html, True)

    If Len(emailKey) > 0 Then
        dict(emailKey) = email
    Else
        ' ���O�C��ID����name���擾�ł��Ȃ��ꍇ�̂݁A��ʓI�Ȗ��O��ǉ����܂��B
        ' ����hidden�l�iCHECK_SESSION_ID�Ȃǁj�͏㏑�����܂���B
        dict("Email") = email
        dict("email") = email
        dict("MailAddress") = email
        dict("mailAddress") = email
        dict("UserId") = email
        dict("userId") = email
        dict("LoginId") = email
        dict("loginId") = email
        dict("UserName") = email
        dict("userName") = email
        dict("Account") = email
        dict("account") = email
    End If

    If Len(passKey) > 0 Then
        dict(passKey) = password
    Else
        dict("Password") = password
        dict("password") = password
        dict("PassWord") = password
        dict("passWord") = password
        dict("LoginPassword") = password
        dict("loginPassword") = password
        dict("UserPassword") = password
        dict("userPassword") = password
        dict("Pass") = password
        dict("pass") = password
    End If

    DxaAddLoginSubmitButton dict, html

    DxaBuildLoginPostBody = DxaDictionaryToPostBody(dict)
    Exit Function

EH:
    DxaBuildLoginPostBody = "Email=" & DxaUrlEncode(email) & "&MailAddress=" & DxaUrlEncode(email) & "&Password=" & DxaUrlEncode(password) & "&password=" & DxaUrlEncode(password)
End Function

Private Function DxaFindLoginInputName(ByVal html As String, ByVal wantPassword As Boolean) As String
    On Error GoTo EH

    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = True
    re.Pattern = "<input[^>]*>"

    Dim ms As Object
    Set ms = re.Execute(html)

    Dim m As Object
    For Each m In ms
        Dim tagHtml As String
        Dim nm As String
        Dim typ As String
        Dim lowerName As String

        tagHtml = CStr(m.Value)
        nm = DxaExtractAttributeValue(tagHtml, "name")
        typ = LCase$(DxaExtractAttributeValue(tagHtml, "type"))
        lowerName = LCase$(nm)

        If Len(nm) > 0 Then
            If wantPassword Then
                If typ = "password" Or InStr(1, lowerName, "password", vbTextCompare) > 0 Or InStr(1, lowerName, "pass", vbTextCompare) > 0 Then
                    DxaFindLoginInputName = nm
                    Exit Function
                End If
            Else
                If typ <> "hidden" And typ <> "password" Then
                    If InStr(1, lowerName, "session", vbTextCompare) = 0 _
                       And InStr(1, lowerName, "check", vbTextCompare) = 0 _
                       And InStr(1, lowerName, "function", vbTextCompare) = 0 _
                       And InStr(1, lowerName, "token", vbTextCompare) = 0 _
                       And InStr(1, lowerName, "csrf", vbTextCompare) = 0 _
                       And InStr(1, lowerName, "password", vbTextCompare) = 0 _
                       And InStr(1, lowerName, "pass", vbTextCompare) = 0 Then

                        If typ = "email" _
                           Or InStr(1, lowerName, "mail", vbTextCompare) > 0 _
                           Or InStr(1, lowerName, "email", vbTextCompare) > 0 _
                           Or InStr(1, lowerName, "login", vbTextCompare) > 0 _
                           Or InStr(1, lowerName, "user", vbTextCompare) > 0 _
                           Or InStr(1, lowerName, "account", vbTextCompare) > 0 _
                           Or InStr(1, lowerName, "employee", vbTextCompare) > 0 _
                           Or InStr(1, lowerName, "staff", vbTextCompare) > 0 _
                           Or InStr(1, lowerName, "id", vbTextCompare) > 0 Then
                            DxaFindLoginInputName = nm
                            Exit Function
                        End If
                    End If
                End If
            End If
        End If
    Next
    Exit Function

EH:
    DxaFindLoginInputName = ""
End Function

Private Sub DxaAddLoginSubmitButton(ByVal dict As Object, ByVal html As String)
    On Error Resume Next

    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = True
    re.Pattern = "<button[\s\S]*?</button>|<input[^>]*>"

    Dim ms As Object
    Set ms = re.Execute(html)

    Dim m As Object
    For Each m In ms
        Dim tagHtml As String
        Dim lowerTag As String
        Dim nm As String
        Dim val As String

        tagHtml = CStr(m.Value)
        lowerTag = LCase$(tagHtml)

        If InStr(1, lowerTag, "login", vbTextCompare) > 0 Or InStr(1, tagHtml, "���O�C��", vbTextCompare) > 0 Then
            nm = DxaExtractAttributeValue(tagHtml, "name")
            If Len(nm) > 0 Then
                val = DxaExtractAttributeValue(tagHtml, "value")
                If Len(val) = 0 Then val = "login"
                dict(nm) = val
                Exit Sub
            End If
        End If
    Next
End Sub
Private Sub DxaNormalizeTimeScreenFormDictionary(ByVal dict As Object)
    On Error Resume Next

    ' TimeScreen.js �͉�ʃ��[�h���� PC/�^�u���b�g�̏ꍇ terminalFlg=0 ��ݒ肵�܂��B
    ' VBA��HTTP���M�ł�JavaScript�����s����Ȃ����߁A���ݒ�̂܂ܑ����GetManagedList����
    ' �V�X�e���G���[�ɂȂ�\��������܂��B�Ǘ��{�^���������̃u���E�U��Ԃɍ��킹�܂��B
    If dict Is Nothing Then Exit Sub

    If dict.Exists("terminalFlg") Then
        If Len(Trim$(CStr(dict("terminalFlg")))) = 0 Then dict("terminalFlg") = "0"
    Else
        dict("terminalFlg") = "0"
    End If

    If dict.Exists("managerFlg") Then
        If Len(Trim$(CStr(dict("managerFlg")))) = 0 Then dict("managerFlg") = "2"
    Else
        dict("managerFlg") = "2"
    End If
End Sub

Private Function DxaBuildPostBodyWithButton(ByVal html As String, ByVal buttonName As String, ByVal buttonValue As String) As String
    Dim dict As Object
    Set dict = DxaExtractInputDictionary(html)
    dict(buttonName) = buttonValue
    DxaBuildPostBodyWithButton = DxaDictionaryToPostBody(dict)
End Function

Private Function DxaExtractInputDictionary(ByVal html As String) As Object
    On Error Resume Next

    Dim dict As Object
    Set dict = CreateObject("Scripting.Dictionary")

    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = True
    re.Pattern = "<input[^>]*>|<textarea[\s\S]*?</textarea>|<select[\s\S]*?</select>"

    Dim ms As Object
    Set ms = re.Execute(html)

    Dim m As Object
    For Each m In ms
        Dim tagHtml As String
        Dim lowerTag As String
        Dim nm As String
        Dim val As String

        tagHtml = CStr(m.Value)
        lowerTag = LCase$(tagHtml)
        nm = DxaExtractAttributeValue(tagHtml, "name")

        If Len(nm) > 0 Then
            If Left$(lowerTag, 9) = "<textarea" Then
                val = DxaExtractTextareaValue(tagHtml)
            ElseIf Left$(lowerTag, 7) = "<select" Then
                val = DxaExtractSelectedOptionValue(tagHtml)
            Else
                val = DxaExtractAttributeValue(tagHtml, "value")
            End If
            dict(nm) = val
        End If
    Next

    Set DxaExtractInputDictionary = dict
End Function

Private Function DxaExtractTextareaValue(ByVal tagHtml As String) As String
    On Error GoTo EH

    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = False
    re.IgnoreCase = True
    re.Pattern = "<textarea[^>]*>([\s\S]*?)</textarea>"

    Dim ms As Object
    Set ms = re.Execute(tagHtml)
    If ms.Count > 0 Then
        DxaExtractTextareaValue = DxaHtmlDecodeBasic(CStr(ms(0).SubMatches(0)))
    Else
        DxaExtractTextareaValue = ""
    End If
    Exit Function
EH:
    DxaExtractTextareaValue = ""
End Function

Private Function DxaExtractSelectedOptionValue(ByVal tagHtml As String) As String
    On Error GoTo EH

    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = True
    re.Pattern = "<option[^>]*>"

    Dim ms As Object
    Set ms = re.Execute(tagHtml)

    Dim m As Object
    Dim firstVal As String
    For Each m In ms
        Dim optionHtml As String
        Dim val As String
        optionHtml = CStr(m.Value)
        val = DxaExtractAttributeValue(optionHtml, "value")
        If Len(firstVal) = 0 Then firstVal = val
        If InStr(1, optionHtml, "selected", vbTextCompare) > 0 Then
            DxaExtractSelectedOptionValue = val
            Exit Function
        End If
    Next

    DxaExtractSelectedOptionValue = firstVal
    Exit Function
EH:
    DxaExtractSelectedOptionValue = ""
End Function

Private Function DxaFindInputNameLike(ByVal dict As Object, ByVal includeWords As Variant, ByVal excludeWords As Variant) As String
    On Error Resume Next

    Dim key As Variant
    For Each key In dict.Keys
        Dim lowerKey As String
        lowerKey = LCase$(CStr(key))

        Dim excluded As Boolean
        Dim w As Variant
        For Each w In excludeWords
            If InStr(1, lowerKey, LCase$(CStr(w)), vbTextCompare) > 0 Then excluded = True
        Next

        If Not excluded Then
            For Each w In includeWords
                If InStr(1, lowerKey, LCase$(CStr(w)), vbTextCompare) > 0 Then
                    DxaFindInputNameLike = CStr(key)
                    Exit Function
                End If
            Next
        End If
    Next
End Function

Private Function DxaDictionaryToPostBody(ByVal dict As Object) As String
    On Error Resume Next

    Dim body As String
    Dim key As Variant
    For Each key In dict.Keys
        If Len(body) > 0 Then body = body & "&"
        body = body & DxaUrlEncode(CStr(key)) & "=" & DxaUrlEncode(CStr(dict(key)))
    Next

    DxaDictionaryToPostBody = body
End Function

Private Function DxaTimecardWebV156Marker() As String
    DxaTimecardWebV156Marker = "v161"
End Function

Private Function DxaParseTimecardUserCandidates(ByVal html As String) As Collection
    On Error GoTo EH

    Dim result As Collection
    Set result = New Collection

    Dim seen As Object
    Set seen = CreateObject("Scripting.Dictionary")

    ' v152:
    ' GetManagedList ��HTML�� <tr> �����^�O�ł͂Ȃ����� <tr> �ŋ�؂���\���ɂȂ��Ă��邽�߁A
    ' <tr>...</tr> �O��̉�͂ł͌����E���܂���B
    ' ���̂��߁A�܂��u4��td + userAttDataBtn�v�𒼐ڌ��o���܂��B
    Dim reDirect As Object
    Set reDirect = CreateObject("VBScript.RegExp")
    reDirect.Global = True
    reDirect.IgnoreCase = True
    reDirect.Pattern = "<td[^>]*>([\s\S]*?)</td>\s*<td[^>]*>([\s\S]*?)</td>\s*<td[^>]*>([\s\S]*?)</td>\s*<td[^>]*>([\s\S]*?)</td>\s*<td[^>]*>[\s\S]*?<button[^>]*userAttDataBtn[^>]*>"

    Dim msDirect As Object
    Set msDirect = reDirect.Execute(html)

    Dim m As Object
    For Each m In msDirect
        Dim blockHtml As String
        Dim userValue As String
        Dim displayName As String
        Dim rowSummary As String

        blockHtml = CStr(m.Value)
        userValue = DxaExtractButtonValue(blockHtml, "userAttDataBtn")
        If Len(userValue) = 0 Then userValue = DxaExtractFirstButtonValue(blockHtml)

        displayName = Trim$(DxaHtmlDecodeBasic(DxaStripHtmlTags(CStr(m.SubMatches(3)))))
        rowSummary = DxaNormalizeSpaces(DxaStripHtmlTags(blockHtml))

        Call DxaAddTimecardUserCandidate(result, seen, displayName, userValue, rowSummary)
    Next

    If result.Count > 0 Then
        Set DxaParseTimecardUserCandidates = result
        Exit Function
    End If

    ' Fallback 1: valid table row HTML.
    Dim reRow As Object
    Set reRow = CreateObject("VBScript.RegExp")
    reRow.Global = True
    reRow.IgnoreCase = True
    reRow.Pattern = "<tr[\s\S]*?</tr>"

    Dim rows As Object
    Set rows = reRow.Execute(html)

    Dim row As Object
    For Each row In rows
        Dim rowHtml As String
        rowHtml = CStr(row.Value)

        userValue = DxaExtractButtonValue(rowHtml, "userAttDataBtn")
        If Len(userValue) = 0 Then userValue = DxaExtractButtonValue(rowHtml, "inputUserDataBtn")
        If Len(userValue) = 0 Then userValue = DxaExtractFirstButtonValue(rowHtml)

        If Len(userValue) > 0 Then
            displayName = DxaExtractTdTextByClass(rowHtml, "userName")
            If Len(displayName) = 0 Then displayName = DxaExtractTimecardUserNameFromRow(rowHtml)
            rowSummary = DxaNormalizeSpaces(DxaStripHtmlTags(rowHtml))
            Call DxaAddTimecardUserCandidate(result, seen, displayName, userValue, rowSummary)
        End If
    Next

    If result.Count > 0 Then
        Set DxaParseTimecardUserCandidates = result
        Exit Function
    End If

    ' Fallback 2: button�ʒu�̒��O�ɂ���Ō��td�������Ƃ��č̗p���܂��B
    Dim reButton As Object
    Set reButton = CreateObject("VBScript.RegExp")
    reButton.Global = True
    reButton.IgnoreCase = True
    reButton.Pattern = "<(button|input)[^>]*userAttDataBtn[^>]*>"

    Dim buttons As Object
    Set buttons = reButton.Execute(html)

    For Each m In buttons
        Dim tagHtml As String
        Dim buttonPos As Long
        Dim contextStart As Long
        Dim beforeHtml As String
        Dim contextHtml As String

        tagHtml = CStr(m.Value)
        userValue = DxaExtractAttributeValue(tagHtml, "value")

        buttonPos = CLng(m.FirstIndex) + 1
        contextStart = buttonPos - 1200
        If contextStart < 1 Then contextStart = 1

        beforeHtml = Mid$(html, contextStart, buttonPos - contextStart)
        contextHtml = Mid$(html, contextStart, 1600)
        displayName = DxaExtractLastTdText(beforeHtml)
        rowSummary = DxaNormalizeSpaces(DxaStripHtmlTags(contextHtml))

        Call DxaAddTimecardUserCandidate(result, seen, displayName, userValue, rowSummary)
    Next

    Set DxaParseTimecardUserCandidates = result
    Exit Function

EH:
    Set DxaParseTimecardUserCandidates = New Collection
End Function

Private Sub DxaAddTimecardUserCandidate(ByVal result As Collection, ByVal seen As Object, ByVal displayName As String, ByVal userValue As String, ByVal rowSummary As String)
    On Error Resume Next

    displayName = DxaNormalizeSpaces(displayName)
    userValue = Trim$(CStr(userValue))
    rowSummary = DxaNormalizeSpaces(rowSummary)

    If Len(userValue) = 0 Then Exit Sub
    If Len(displayName) = 0 Then displayName = rowSummary
    If Len(displayName) = 0 Then Exit Sub

    If Not seen Is Nothing Then
        If seen.Exists(userValue) Then Exit Sub
        seen.Add userValue, True
    End If

    result.Add Array(displayName, userValue, rowSummary)
End Sub

Private Function DxaExtractLastTdText(ByVal html As String) As String
    On Error GoTo EH

    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = True
    re.Pattern = "<td[^>]*>([\s\S]*?)</td>"

    Dim ms As Object
    Set ms = re.Execute(html)

    Dim m As Object
    For Each m In ms
        DxaExtractLastTdText = Trim$(DxaHtmlDecodeBasic(DxaStripHtmlTags(CStr(m.SubMatches(0)))))
    Next
    Exit Function

EH:
    DxaExtractLastTdText = ""
End Function

Private Function DxaExtractTimecardUserNameFromRow(ByVal rowHtml As String) As String
    On Error Resume Next

    Dim texts As Collection
    Set texts = DxaExtractTdTexts(rowHtml)

    ' �Ǘ��ꗗ�́u�����ԍ��A������/��Ж��A�Ј��ԍ��A�����A�Αӈꗗ...�v�̏��ŏo�͂����z��ł��B
    If Not texts Is Nothing Then
        If texts.Count >= 4 Then
            DxaExtractTimecardUserNameFromRow = Trim$(CStr(texts(4)))
            If Len(DxaExtractTimecardUserNameFromRow) > 0 Then Exit Function
        End If
    End If

    Dim rowText As String
    rowText = DxaNormalizeSpaces(DxaStripHtmlTags(rowHtml))
    DxaExtractTimecardUserNameFromRow = rowText
End Function

Private Function DxaExtractTdTexts(ByVal rowHtml As String) As Collection
    On Error GoTo EH

    Dim result As Collection
    Set result = New Collection

    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = True
    re.Pattern = "<td[^>]*>([\s\S]*?)</td>"

    Dim ms As Object
    Set ms = re.Execute(rowHtml)

    Dim m As Object
    For Each m In ms
        result.Add Trim$(DxaHtmlDecodeBasic(DxaStripHtmlTags(CStr(m.SubMatches(0)))))
    Next

    Set DxaExtractTdTexts = result
    Exit Function

EH:
    Set DxaExtractTdTexts = New Collection
End Function

Private Function DxaResolveTimecardSelectedUsers(ByVal candidates As Collection) As Collection
    On Error GoTo EH

    Dim result As Collection
    Set result = New Collection

    Dim savedTargetName As String
    savedTargetName = DxaLoadTimecardSavedTargetName()

    Dim savedTargetNames As Collection
    Set savedTargetNames = DxaParseTimecardTargetNames(savedTargetName)

    Dim selectedValues As Object
    Set selectedValues = CreateObject("Scripting.Dictionary")

    If Not savedTargetNames Is Nothing And savedTargetNames.Count > 0 Then
        Dim i As Long
        Dim targetText As String
        Dim rec As Variant
        Dim failedText As String

        For i = 1 To savedTargetNames.Count
            targetText = CStr(savedTargetNames(i))
            rec = DxaResolveTimecardCandidateForTarget(candidates, targetText)
            If IsArray(rec) Then
                If Not selectedValues.Exists(CStr(rec(1))) Then
                    result.Add rec
                    selectedValues(CStr(rec(1))) = True
                End If
            Else
                failedText = failedText & targetText & vbCrLf
            End If
        Next

        If Len(failedText) > 0 Then
            MsgBox "�ۑ��ςݑΏێҖ��̂����A�Ǘ��ꗗ�ň�v�������ł��Ȃ����O������܂����B" & vbCrLf & vbCrLf & _
                   failedText & vbCrLf & _
                   "�擾�ł���Ώێ҂̂ݏ����𑱍s���܂��B", vbExclamation, "DelaxTools �Αӎ擾"
        End If

        If result.Count > 0 Then
            Set DxaResolveTimecardSelectedUsers = result
            Exit Function
        End If
    End If

    Dim userValue As String
    userValue = DxaPromptTimecardUserSelection(candidates)
    If Len(userValue) > 0 Then
        result.Add Array(DxaFindTimecardCandidateNameByValue(candidates, userValue), userValue)
    End If

    Set DxaResolveTimecardSelectedUsers = result
    Exit Function

EH:
    Set DxaResolveTimecardSelectedUsers = New Collection
End Function

Private Function DxaResolveTimecardCandidateForTarget(ByVal candidates As Collection, ByVal targetText As String) As Variant
    On Error GoTo EH

    Dim indexes() As Long
    Dim scores() As Double
    Dim count As Long
    ReDim indexes(1 To candidates.Count)
    ReDim scores(1 To candidates.Count)

    Dim i As Long
    Dim rec As Variant
    Dim score As Double

    For i = 1 To candidates.Count
        rec = candidates(i)
        score = DxaTimecardNameMatchScore(CStr(rec(0)), targetText)
        If score > 0# Then
            count = count + 1
            indexes(count) = i
            scores(count) = score
        End If
    Next

    If count = 0 Then Exit Function

    DxaSortTimecardCandidateIndexes indexes, scores, count

    Dim shouldAutoSelect As Boolean
    If count = 1 Then
        shouldAutoSelect = True
    ElseIf scores(1) >= 1000# Then
        shouldAutoSelect = True
    ElseIf scores(1) >= 800# And scores(1) > scores(2) Then
        shouldAutoSelect = True
    End If

    If shouldAutoSelect Then
        rec = candidates(indexes(1))
        DxaResolveTimecardCandidateForTarget = Array(CStr(rec(0)), CStr(rec(1)))
        Exit Function
    End If

    Dim maxShow As Long
    maxShow = count
    If maxShow > 20 Then maxShow = 20

    Dim prompt As String
    prompt = "�ۑ��ςݑΏێҖ��Ɉ�v�����₪��������܂��B" & vbCrLf & _
             "�ۑ��ςݑΏێҖ�: " & targetText & vbCrLf & _
             "�擾�Ώێ҂�ԍ��őI�����Ă��������B" & vbCrLf & _
             "�󗓂̏ꍇ�A���̑Ώێ҂̓X�L�b�v���܂��B" & vbCrLf & vbCrLf

    For i = 1 To maxShow
        rec = candidates(indexes(i))
        prompt = prompt & CStr(i) & ": " & CStr(rec(0)) & vbCrLf
        If Len(prompt) > 1800 Then Exit For
    Next

    Dim choiceText As String
    choiceText = Trim$(InputBox(prompt, "DelaxTools �Αӎ擾", "1"))
    If Len(choiceText) = 0 Then Exit Function
    If Not IsNumeric(choiceText) Then Exit Function

    Dim choiceNo As Long
    choiceNo = CLng(choiceText)
    If choiceNo < 1 Or choiceNo > maxShow Then Exit Function

    rec = candidates(indexes(choiceNo))
    DxaResolveTimecardCandidateForTarget = Array(CStr(rec(0)), CStr(rec(1)))
    Exit Function

EH:
End Function

Private Function DxaFindTimecardCandidateNameByValue(ByVal candidates As Collection, ByVal userValue As String) As String
    On Error GoTo EH

    Dim rec As Variant
    For Each rec In candidates
        If CStr(rec(1)) = CStr(userValue) Then
            DxaFindTimecardCandidateNameByValue = CStr(rec(0))
            Exit Function
        End If
    Next

    DxaFindTimecardCandidateNameByValue = "�Αӈꗗ"
    Exit Function

EH:
    DxaFindTimecardCandidateNameByValue = "�Αӈꗗ"
End Function

Private Function DxaBuildTimecardSheetName(ByVal targetName As String) As String
    On Error GoTo EH

    Dim baseName As String
    If Len(Trim$(targetName)) = 0 Then
        baseName = "�Αӈꗗ"
    Else
        baseName = "�Αӈꗗ_" & DxaSanitizeWorksheetName(targetName)
    End If

    If Len(baseName) > 31 Then baseName = Left$(baseName, 31)
    If Len(baseName) = 0 Then baseName = "�Αӈꗗ"
    DxaBuildTimecardSheetName = baseName
    Exit Function

EH:
    DxaBuildTimecardSheetName = "�Αӈꗗ"
End Function

Private Function DxaSanitizeWorksheetName(ByVal value As String) As String
    Dim s As String
    s = DxaNormalizeSpaces(value)
    s = Replace(s, "\", "")
    s = Replace(s, "/", "")
    s = Replace(s, ":", "")
    s = Replace(s, "?", "")
    s = Replace(s, "*", "")
    s = Replace(s, "[", "")
    s = Replace(s, "]", "")
    s = Replace(s, Chr$(34), "")
    DxaSanitizeWorksheetName = Trim$(s)
End Function

Private Function DxaPromptTimecardUserSelection(ByVal candidates As Collection) As String
    On Error GoTo EH

    Dim savedTargetName As String
    savedTargetName = DxaLoadTimecardSavedTargetName()

    Dim savedTargetNames As Collection
    Set savedTargetNames = DxaParseTimecardTargetNames(savedTargetName)

    Dim filterText As String
    Dim usingSavedTarget As Boolean

    If savedTargetNames.Count = 1 Then
        filterText = CStr(savedTargetNames(1))
        savedTargetName = filterText
        usingSavedTarget = True
    ElseIf savedTargetNames.Count > 1 Then
        filterText = DxaPromptTimecardSavedTargetName(savedTargetNames, usingSavedTarget)
        savedTargetName = filterText
        If Len(filterText) = 0 Then Exit Function
    Else
        filterText = InputBox("�擾�Ώێ҂̎����̈ꕔ����͂��Ă��������B" & vbCrLf & _
                              "�󔒂̗L���͖������܂��B�󗓂̏ꍇ�͈ꗗ�̐擪����\�����܂��B", _
                              "DelaxTools �Αӎ擾")
        filterText = Trim$(filterText)
    End If

BuildCandidateList:
    Dim indexes() As Long
    Dim scores() As Double
    Dim count As Long
    ReDim indexes(1 To candidates.Count)
    ReDim scores(1 To candidates.Count)

    Dim i As Long
    For i = 1 To candidates.Count
        Dim rec As Variant
        rec = candidates(i)

        Dim score As Double
        If Len(Trim$(filterText)) = 0 Then
            score = 1#
        Else
            score = DxaTimecardNameMatchScore(CStr(rec(0)), filterText)
        End If

        If score > 0# Then
            count = count + 1
            indexes(count) = i
            scores(count) = score
        End If
    Next

    If count = 0 Then
        If usingSavedTarget Then
            MsgBox "�ۑ��ςݑΏێҖ��Ɉ�v�����₪������܂���ł����B" & vbCrLf & vbCrLf & _
                   "�ۑ��ςݑΏێҖ�: " & savedTargetName & vbCrLf & _
                   "�����̕\�L���ς���Ă���\��������܂��B�ē��͂��Ă��������B", vbExclamation, "DelaxTools"
            filterText = InputBox("�擾�Ώێ҂̎����̈ꕔ����͂��Ă��������B" & vbCrLf & _
                                  "�󔒂̗L���͖������܂��B", _
                                  "DelaxTools �Αӎ擾", savedTargetName)
            filterText = Trim$(filterText)
            usingSavedTarget = False
            If Len(filterText) = 0 Then Exit Function
            GoTo BuildCandidateList
        End If

        MsgBox "���͂��ꂽ�����ɋ߂���₪������܂���ł����B" & vbCrLf & _
               "�󔒂̗L����ꕔ�̕����ōēx�����Ă��������B", vbExclamation, "DelaxTools"
        Exit Function
    End If

    DxaSortTimecardCandidateIndexes indexes, scores, count

    Dim maxShow As Long
    maxShow = count
    If maxShow > 40 Then maxShow = 40

    If maxShow = 1 Then
        rec = candidates(indexes(1))
        Dim confirmText As String
        If usingSavedTarget Then
            confirmText = "�ۑ��ςݑΏێҖ�����A�ȉ��̑Ώێ҂����o���܂����B" & vbCrLf & vbCrLf & _
                          CStr(rec(0)) & vbCrLf & vbCrLf & _
                          "���̑Ώێ҂̋Αӈꗗ���擾���܂����H"
        Else
            confirmText = "�ȉ��̑Ώێ҂̋Αӈꗗ���擾���܂����H" & vbCrLf & vbCrLf & CStr(rec(0))
        End If

        If MsgBox(confirmText, vbQuestion + vbYesNo, "DelaxTools �Αӎ擾") = vbYes Then
            DxaPromptTimecardUserSelection = CStr(rec(1))
        End If
        Exit Function
    End If

    Dim prompt As String
    If usingSavedTarget Then
        prompt = "�ۑ��ςݑΏێҖ��Ɉ�v�����₪��������܂��B" & vbCrLf & _
                 "�ۑ��ςݑΏێҖ�: " & savedTargetName & vbCrLf & _
                 "�擾�Ώێ҂�ԍ��őI�����Ă��������B" & vbCrLf & vbCrLf
    Else
        prompt = "�擾�Ώێ҂�ԍ��őI�����Ă��������B" & vbCrLf & _
                 "���͎����̕�����v�����������ɕ\�����܂��B" & vbCrLf & vbCrLf
    End If

    For i = 1 To maxShow
        rec = candidates(indexes(i))
        prompt = prompt & CStr(i) & ": " & CStr(rec(0)) & vbCrLf
        If Len(prompt) > 1800 Then Exit For
    Next

    Dim choiceText As String
    choiceText = InputBox(prompt, "DelaxTools �Αӎ擾")
    choiceText = Trim$(choiceText)
    If Len(choiceText) = 0 Then Exit Function
    If Not IsNumeric(choiceText) Then
        MsgBox "�ԍ�����͂��Ă��������B", vbExclamation, "DelaxTools"
        Exit Function
    End If

    Dim choiceNo As Long
    choiceNo = CLng(choiceText)
    If choiceNo < 1 Or choiceNo > maxShow Then
        MsgBox "���ꗗ�ɕ\������Ă���ԍ�����͂��Ă��������B", vbExclamation, "DelaxTools"
        Exit Function
    End If

    rec = candidates(indexes(choiceNo))
    DxaPromptTimecardUserSelection = CStr(rec(1))
    Exit Function

EH:
    DxaPromptTimecardUserSelection = ""
End Function

Private Function DxaPromptTimecardSavedTargetName(ByVal savedTargetNames As Collection, ByRef usingSavedTarget As Boolean) As String
    On Error GoTo EH

    usingSavedTarget = False

    If savedTargetNames Is Nothing Then Exit Function
    If savedTargetNames.Count = 0 Then Exit Function
    If savedTargetNames.Count = 1 Then
        DxaPromptTimecardSavedTargetName = CStr(savedTargetNames(1))
        usingSavedTarget = True
        Exit Function
    End If

    Dim prompt As String
    prompt = "�ۑ��ςݑΏێҖ�����������܂��B" & vbCrLf & _
             "����擾����Ώێ҂�ԍ��őI�����Ă��������B" & vbCrLf & _
             "0: ����͂���" & vbCrLf & vbCrLf

    Dim i As Long
    For i = 1 To savedTargetNames.Count
        prompt = prompt & CStr(i) & ": " & CStr(savedTargetNames(i)) & vbCrLf
        If Len(prompt) > 1800 Then Exit For
    Next

    Dim choiceText As String
    choiceText = InputBox(prompt, "DelaxTools �Αӎ擾", "1")
    choiceText = Trim$(choiceText)
    If Len(choiceText) = 0 Then Exit Function
    If Not IsNumeric(choiceText) Then
        MsgBox "�ԍ�����͂��Ă��������B", vbExclamation, "DelaxTools"
        Exit Function
    End If

    Dim choiceNo As Long
    choiceNo = CLng(choiceText)

    If choiceNo = 0 Then
        DxaPromptTimecardSavedTargetName = Trim$(InputBox("�擾�Ώێ҂̎����̈ꕔ����͂��Ă��������B" & vbCrLf & _
                                                         "�󔒂̗L���͖������܂��B", _
                                                         "DelaxTools �Αӎ擾"))
        usingSavedTarget = False
        Exit Function
    End If

    If choiceNo < 1 Or choiceNo > savedTargetNames.Count Then
        MsgBox "�ۑ��ςݑΏێҖ��ꗗ�ɕ\������Ă���ԍ�����͂��Ă��������B", vbExclamation, "DelaxTools"
        Exit Function
    End If

    DxaPromptTimecardSavedTargetName = CStr(savedTargetNames(choiceNo))
    usingSavedTarget = True
    Exit Function

EH:
    DxaPromptTimecardSavedTargetName = ""
    usingSavedTarget = False
End Function


Private Sub DxaSortTimecardCandidateIndexes(ByRef indexes() As Long, ByRef scores() As Double, ByVal count As Long)
    ' ���҂���v�x�̍������ɕ��בւ��܂��B
    ' v155: v154�ŌĂяo���̂ݑ��݂��Ă������߁A�R���p�C���G���[�ɂȂ��Ă����s���֐���ǉ����܂����B
    On Error GoTo EH

    If count <= 1 Then Exit Sub

    Dim i As Long
    Dim j As Long
    Dim tmpIndex As Long
    Dim tmpScore As Double

    For i = 1 To count - 1
        For j = i + 1 To count
            If scores(j) > scores(i) Then
                tmpScore = scores(i)
                scores(i) = scores(j)
                scores(j) = tmpScore

                tmpIndex = indexes(i)
                indexes(i) = indexes(j)
                indexes(j) = tmpIndex
            ElseIf scores(j) = scores(i) And indexes(j) < indexes(i) Then
                tmpIndex = indexes(i)
                indexes(i) = indexes(j)
                indexes(j) = tmpIndex
            End If
        Next
    Next
    Exit Sub

EH:
    ' ���בւ��Ɏ��s�����ꍇ�͌��̏����ő��s���܂��B
End Sub

Private Function DxaTimecardNameMatchScore(ByVal candidateName As String, ByVal filterText As String) As Double
    Dim c As String
    Dim f As String

    c = DxaNormalizeNameForMatch(candidateName)
    f = DxaNormalizeNameForMatch(filterText)

    If Len(f) = 0 Then
        DxaTimecardNameMatchScore = 1#
        Exit Function
    End If

    If c = f Then
        DxaTimecardNameMatchScore = 1000#
        Exit Function
    End If

    If InStr(1, c, f, vbTextCompare) > 0 Then
        DxaTimecardNameMatchScore = 800# + Len(f) / IIf(Len(c) = 0, 1, Len(c))
        Exit Function
    End If

    If InStr(1, f, c, vbTextCompare) > 0 And Len(c) > 0 Then
        DxaTimecardNameMatchScore = 700# + Len(c) / Len(f)
        Exit Function
    End If

    Dim hit As Long
    Dim pos As Long
    Dim i As Long
    For i = 1 To Len(f)
        pos = InStr(1, c, Mid$(f, i, 1), vbTextCompare)
        If pos > 0 Then hit = hit + 1
    Next

    If Len(f) > 0 Then DxaTimecardNameMatchScore = hit / Len(f)
    If DxaTimecardNameMatchScore < 0.5 Then DxaTimecardNameMatchScore = 0#
End Function

Private Function DxaNormalizeNameForMatch(ByVal text As String) As String
    Dim s As String
    s = DxaNormalizeSpaces(text)
    s = Replace(s, " ", "")
    s = Replace(s, vbTab, "")
    s = Replace(s, vbCr, "")
    s = Replace(s, vbLf, "")
    s = LCase$(s)
    DxaNormalizeNameForMatch = s
End Function

Private Function DxaNormalizeName(ByVal text As String) As String
    DxaNormalizeName = DxaNormalizeNameForMatch(text)
End Function

Private Function DxaExtractInputValue(ByVal html As String, ByVal inputName As String) As String
    On Error GoTo EH

    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = False
    re.IgnoreCase = True
    re.Pattern = "<input[^>]*name=[""']" & DxaRegexEscape(inputName) & "[""'][^>]*>"

    Dim m As Object
    If re.Test(html) Then
        Set m = re.Execute(html)(0)
        DxaExtractInputValue = DxaExtractAttributeValue(CStr(m.Value), "value")
    End If
    Exit Function

EH:
    DxaExtractInputValue = ""
End Function

Private Function DxaExtractAttributeValue(ByVal tagHtml As String, ByVal attrName As String) As String
    On Error GoTo EH

    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = False
    re.IgnoreCase = True

    ' Quoted attribute: name="value" / name='value'
    re.Pattern = attrName & "\s*=\s*([""'])(.*?)\1"
    If re.Test(tagHtml) Then
        DxaExtractAttributeValue = DxaHtmlDecodeBasic(CStr(re.Execute(tagHtml)(0).SubMatches(1)))
        Exit Function
    End If

    ' Unquoted attribute: name=value
    re.Pattern = attrName & "\s*=\s*([^\s""'>]+)"
    If re.Test(tagHtml) Then
        DxaExtractAttributeValue = DxaHtmlDecodeBasic(CStr(re.Execute(tagHtml)(0).SubMatches(0)))
        Exit Function
    End If

    DxaExtractAttributeValue = ""
    Exit Function

EH:
    DxaExtractAttributeValue = ""
End Function


Private Function DxaUrlOrigin(ByVal url As String) As String
    On Error GoTo EH

    Dim p As Long
    p = InStr(9, url, "/", vbTextCompare)
    If p > 0 Then
        DxaUrlOrigin = Left$(url, p - 1)
    Else
        DxaUrlOrigin = url
    End If
    Exit Function

EH:
    DxaUrlOrigin = ""
End Function

Private Function DxaHttpRequest(ByVal method As String, ByVal url As String, ByVal body As String, ByRef cookies As String, ByVal contentType As String, Optional ByVal refererUrl As String = "") As String
    On Error GoTo EH

    Dim http As Object
    Set http = CreateObject("WinHttp.WinHttpRequest.5.1")
    http.Option(6) = True
    http.Open method, url, False
    http.SetRequestHeader "User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36 Edg/148.0.0.0"
    http.SetRequestHeader "Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7"
    http.SetRequestHeader "Accept-Language", "ja,en;q=0.9,en-GB;q=0.8,en-US;q=0.7"
    If UCase$(method) = "POST" Then
        http.SetRequestHeader "Cache-Control", "max-age=0"
        http.SetRequestHeader "Upgrade-Insecure-Requests", "1"
        http.SetRequestHeader "Sec-Fetch-Site", "same-origin"
        http.SetRequestHeader "Sec-Fetch-Mode", "navigate"
        http.SetRequestHeader "Sec-Fetch-User", "?1"
        http.SetRequestHeader "Sec-Fetch-Dest", "document"
        http.SetRequestHeader "sec-ch-ua", """Chromium"";v=""148"", ""Microsoft Edge"";v=""148"", ""Not)A;Brand"";v=""99"""
        http.SetRequestHeader "sec-ch-ua-mobile", "?0"
        http.SetRequestHeader "sec-ch-ua-platform", """Windows"""
    Else
        http.SetRequestHeader "Cache-Control", "no-cache"
    End If
    If Len(refererUrl) > 0 Then http.SetRequestHeader "Referer", refererUrl
    If UCase$(method) = "POST" Then
        Dim originUrl As String
        originUrl = DxaUrlOrigin(url)
        If Len(originUrl) > 0 Then http.SetRequestHeader "Origin", originUrl
    End If
    If Len(cookies) > 0 Then http.SetRequestHeader "Cookie", cookies
    If Len(contentType) > 0 Then http.SetRequestHeader "Content-Type", contentType

    If UCase$(method) = "POST" Then
        http.Send body
    Else
        http.Send
    End If

    DxaMergeResponseCookies cookies, http.GetAllResponseHeaders
    DxaHttpRequest = CStr(http.ResponseText)
    Exit Function

EH:
    Err.Raise vbObjectError + 631, "DelaxTools", "Timecard site communication failed." & vbCrLf & Err.Description
End Function

Private Sub DxaMergeResponseCookies(ByRef cookies As String, ByVal headers As String)
    On Error Resume Next

    Dim lines As Variant
    lines = Split(headers, vbCrLf)

    Dim dict As Object
    Set dict = CreateObject("Scripting.Dictionary")

    Dim existing As Variant
    Dim item As Variant
    Dim nameValue As String
    Dim cookieName As String

    If Len(cookies) > 0 Then
        existing = Split(cookies, ";")
        For Each item In existing
            nameValue = Trim$(CStr(item))
            If InStr(1, nameValue, "=", vbTextCompare) > 1 Then
                cookieName = Left$(nameValue, InStr(1, nameValue, "=", vbTextCompare) - 1)
                dict(cookieName) = nameValue
            End If
        Next
    End If

    Dim i As Long
    Dim line As String
    For i = LBound(lines) To UBound(lines)
        line = CStr(lines(i))
        If LCase$(Left$(line, 11)) = "set-cookie:" Then
            nameValue = Trim$(Mid$(line, 12))
            If InStr(1, nameValue, ";", vbTextCompare) > 0 Then nameValue = Left$(nameValue, InStr(1, nameValue, ";", vbTextCompare) - 1)
            If InStr(1, nameValue, "=", vbTextCompare) > 1 Then
                cookieName = Left$(nameValue, InStr(1, nameValue, "=", vbTextCompare) - 1)
                dict(cookieName) = nameValue
            End If
        End If
    Next

    cookies = ""
    Dim key As Variant
    For Each key In dict.Keys
        If Len(cookies) > 0 Then cookies = cookies & "; "
        cookies = cookies & CStr(dict(key))
    Next
End Sub

Private Function DxaFindTimecardUserButtonValue(ByVal html As String, ByVal targetName As String) As String
    ' �݊��p�B���݂͊Ǘ��ꗗ�������\�����đI������������g�p���܂��B
    On Error Resume Next
    Dim candidates As Collection
    Set candidates = DxaParseTimecardUserCandidates(html)

    Dim bestScore As Double
    Dim bestValue As String
    Dim i As Long
    For i = 1 To candidates.Count
        Dim rec As Variant
        rec = candidates(i)
        Dim score As Double
        score = DxaTimecardNameMatchScore(CStr(rec(0)), targetName)
        If score > bestScore Then
            bestScore = score
            bestValue = CStr(rec(1))
        End If
    Next

    If bestScore > 0# Then DxaFindTimecardUserButtonValue = bestValue
End Function

Private Function DxaExtractButtonValue(ByVal html As String, ByVal classOrName As String) As String
    On Error Resume Next

    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = True
    re.Pattern = "<(button|input)[^>]*>"

    Dim ms As Object
    Set ms = re.Execute(html)

    Dim m As Object
    For Each m In ms
        Dim tagHtml As String
        tagHtml = CStr(m.Value)
        If InStr(1, tagHtml, classOrName, vbTextCompare) > 0 Then
            DxaExtractButtonValue = DxaExtractAttributeValue(tagHtml, "value")
            If Len(DxaExtractButtonValue) > 0 Then Exit Function
        End If
    Next
End Function

Private Function DxaExtractFirstButtonValue(ByVal html As String) As String
    On Error Resume Next

    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = True
    re.Pattern = "<(button|input)[^>]*>"

    Dim ms As Object
    Set ms = re.Execute(html)

    Dim m As Object
    For Each m In ms
        Dim tagHtml As String
        tagHtml = CStr(m.Value)
        If InStr(1, tagHtml, "userAttDataBtn", vbTextCompare) > 0 Or InStr(1, tagHtml, "inputUserDataBtn", vbTextCompare) > 0 Then
            DxaExtractFirstButtonValue = DxaExtractAttributeValue(tagHtml, "value")
            If Len(DxaExtractFirstButtonValue) > 0 Then Exit Function
        End If
    Next

    If ms.Count > 0 Then DxaExtractFirstButtonValue = DxaExtractAttributeValue(CStr(ms(0).Value), "value")
End Function

Private Function DxaLooksLikeAttendanceDisplay(ByVal html As String) As Boolean
    DxaLooksLikeAttendanceDisplay = (InStr(1, html, "attendanceTime", vbTextCompare) > 0 And InStr(1, html, "retiredTime", vbTextCompare) > 0) _
                                 Or (InStr(1, html, "�o�Ύ���", vbTextCompare) > 0 And InStr(1, html, "�ދΎ���", vbTextCompare) > 0)
End Function

Private Function DxaResolveUrl(ByVal baseUrl As String, ByVal path As String) As String
    If Len(path) = 0 Then
        DxaResolveUrl = baseUrl
        Exit Function
    End If

    If LCase$(Left$(path, 4)) = "http" Then
        DxaResolveUrl = path
        Exit Function
    End If

    Dim origin As String
    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = False
    re.IgnoreCase = True
    re.Pattern = "^(https?://[^/]+)"

    Dim ms As Object
    Set ms = re.Execute(baseUrl)
    If ms.Count > 0 Then origin = CStr(ms(0).SubMatches(0))

    If Left$(path, 1) = "/" Then
        DxaResolveUrl = origin & path
        Exit Function
    End If

    Dim baseDir As String
    Dim qPos As Long
    qPos = InStr(1, baseUrl, "?", vbTextCompare)
    If qPos > 0 Then baseUrl = Left$(baseUrl, qPos - 1)

    Dim slashPos As Long
    slashPos = InStrRev(baseUrl, "/")
    If slashPos > Len("https://") Then
        baseDir = Left$(baseUrl, slashPos)
        DxaResolveUrl = baseDir & path
    ElseIf Len(origin) > 0 Then
        DxaResolveUrl = origin & "/" & path
    Else
        DxaResolveUrl = path
    End If
End Function
Private Function DxaUrlEncode(ByVal text As String) As String
    On Error GoTo Fallback
    DxaUrlEncode = Application.WorksheetFunction.EncodeURL(text)
    Exit Function
Fallback:
    DxaUrlEncode = Replace$(Replace$(text, " ", "+"), "@", "%40")
End Function

Private Function DxaTimecardEndRoundModeLabel(ByVal mode As Long) As String
    Select Case mode
        Case 1
            DxaTimecardEndRoundModeLabel = "�V�t�g�Ζ��i15���؂�̂āj"
        Case 2
            DxaTimecardEndRoundModeLabel = "�ʏ�Ζ��i17:30�`18:14��17:30�j"
        Case Else
            DxaTimecardEndRoundModeLabel = ""
    End Select
End Function

Private Function DxaRoundTimecardStart(ByVal timeText As String) As String
    Dim totalMinutes As Long
    If Not DxaTimecardTextToMinutes(timeText, totalMinutes) Then
        DxaRoundTimecardStart = timeText
        Exit Function
    End If

    ' �o�Ύ�����15���P�ʂŐ؂�グ��B
    ' �������A����00�̏ꍇ�������̂܂܂ɂ���B
    If totalMinutes Mod 60 = 0 Then
        DxaRoundTimecardStart = DxaMinutesToTimecardText(totalMinutes)
    Else
        DxaRoundTimecardStart = DxaMinutesToTimecardText(((totalMinutes \ 15) + 1) * 15)
    End If
End Function

Private Function DxaRoundTimecardEnd(ByVal timeText As String, ByVal mode As Long) As String
    Dim totalMinutes As Long
    If Not DxaTimecardTextToMinutes(timeText, totalMinutes) Then
        DxaRoundTimecardEnd = timeText
        Exit Function
    End If

    Select Case mode
        Case 2
            ' �v�]�Ή��F17:30�`18:14 �̏ꍇ�� 17:30 �Ƃ��ďo�͂���B
            If totalMinutes >= (17 * 60 + 30) And totalMinutes <= (18 * 60 + 14) Then
                DxaRoundTimecardEnd = "17:30"
            Else
                DxaRoundTimecardEnd = DxaMinutesToTimecardText((totalMinutes \ 15) * 15)
            End If
        Case Else
            ' �ʏ�F15���P�ʂŐ؂�̂Ă�B
            DxaRoundTimecardEnd = DxaMinutesToTimecardText((totalMinutes \ 15) * 15)
    End Select
End Function

Private Function DxaTimecardTextToMinutes(ByVal timeText As String, ByRef totalMinutes As Long) As Boolean
    On Error GoTo EH
    Dim s As String
    s = Trim$(timeText)
    If Len(s) = 0 Then Exit Function

    Dim parts As Variant
    parts = Split(s, ":")
    If UBound(parts) <> 1 Then Exit Function

    Dim h As Long
    Dim m As Long
    h = CLng(parts(0))
    m = CLng(parts(1))

    If h < 0 Or h > 23 Then Exit Function
    If m < 0 Or m > 59 Then Exit Function

    totalMinutes = h * 60 + m
    DxaTimecardTextToMinutes = True
    Exit Function
EH:
    DxaTimecardTextToMinutes = False
End Function

Private Function DxaMinutesToTimecardText(ByVal totalMinutes As Long) As String
    Do While totalMinutes < 0
        totalMinutes = totalMinutes + 24 * 60
    Loop
    totalMinutes = totalMinutes Mod (24 * 60)

    DxaMinutesToTimecardText = Format$(totalMinutes \ 60, "00") & ":" & Format$(totalMinutes Mod 60, "00")
End Function

Private Function DxaTimecardOutputText(ByVal timeText As String) As String
    ' �Αӈꗗ�ւ̏o�͎��́u09:00�v�ł͂Ȃ��u0900�v�̂悤�Ɂu:�v���폜���܂��B
    DxaTimecardOutputText = Replace$(Trim$(CStr(timeText)), ":", "")
End Function

Private Function DxaParseTimecardRecords(ByVal sourceText As String) As Collection
    Dim htmlRecords As Collection
    Set htmlRecords = DxaParseTimecardRecordsFromHtml(sourceText)
    If Not htmlRecords Is Nothing Then
        If htmlRecords.Count > 0 Then
            Set DxaParseTimecardRecords = htmlRecords
            Exit Function
        End If
    End If

    Dim result As New Collection

    Dim y As Long
    Dim m As Long
    Dim hasYm As Boolean
    hasYm = DxaExtractYearMonth(sourceText, y, m)

    Dim normalized As String
    normalized = DxaStripHtmlTags(sourceText)
    normalized = Replace(normalized, vbCrLf, vbLf)
    normalized = Replace(normalized, vbCr, vbLf)

    Dim lines As Variant
    lines = Split(normalized, vbLf)

    Dim reDate As Object
    Set reDate = CreateObject("VBScript.RegExp")
    reDate.Global = False
    reDate.IgnoreCase = True
    reDate.Pattern = "^\s*(\d{1,2})\s*[\(�i]?\s*([���ΐ��؋��y��])?\s*[\)�j]?"

    Dim reTime As Object
    Set reTime = CreateObject("VBScript.RegExp")
    reTime.Global = True
    reTime.IgnoreCase = True
    reTime.Pattern = "\b([0-2]?\d:[0-5]\d)\b"

    Dim i As Long
    For i = LBound(lines) To UBound(lines)
        Dim lineText As String
        lineText = Trim$(CStr(lines(i)))
        If Len(lineText) = 0 Then GoTo ContinueLine

        Dim matches As Object
        Set matches = reDate.Execute(lineText)
        If matches.Count = 0 Then GoTo ContinueLine

        Dim dayNum As Long
        dayNum = CLng(matches(0).SubMatches(0))
        If dayNum < 1 Or dayNum > 31 Then GoTo ContinueLine

        Dim timeMatches As Object
        Set timeMatches = reTime.Execute(lineText)

        Dim startTime As String
        Dim endTime As String
        startTime = ""
        endTime = ""

        If timeMatches.Count >= 1 Then startTime = CStr(timeMatches(0).SubMatches(0))
        If timeMatches.Count >= 2 Then endTime = CStr(timeMatches(1).SubMatches(0))

        Dim dateText As String
        If hasYm Then
            On Error Resume Next
            dateText = Format$(DateSerial(y, m, dayNum), "yyyy/mm/dd") & "�i" & DxaWeekdayJa(DateSerial(y, m, dayNum)) & "�j"
            If Err.Number <> 0 Then
                Err.Clear
                dateText = DxaNormalizeDateText(matches(0).Value)
            End If
            On Error GoTo 0
        Else
            dateText = DxaNormalizeDateText(matches(0).Value)
        End If

        result.Add Array(dateText, startTime, endTime)

ContinueLine:
    Next

    Set DxaParseTimecardRecords = result
End Function

Private Function DxaParseTimecardRecordsFromHtml(ByVal html As String) As Collection
    Dim result As New Collection
    On Error GoTo EH

    If Len(DxaTrimHtml(html)) = 0 Then
        Set DxaParseTimecardRecordsFromHtml = result
        Exit Function
    End If

    Dim y As Long
    Dim m As Long
    Dim hasYm As Boolean
    hasYm = DxaExtractYearMonth(html, y, m)

    Dim rows As Collection
    Set rows = DxaExtractHtmlRowFragments(html)

    Dim seenDays As Object
    Set seenDays = CreateObject("Scripting.Dictionary")

    Dim i As Long
    For i = 1 To rows.Count
        Dim rowHtml As String
        rowHtml = CStr(rows(i))

        Dim cells As Collection
        Set cells = DxaExtractTdCellInfos(rowHtml)
        If cells Is Nothing Then GoTo ContinueRow
        If cells.Count < 1 Then GoTo ContinueRow

        Dim dateRaw As String
        Dim startTime As String
        Dim endTime As String
        dateRaw = ""
        startTime = ""
        endTime = ""

        Dim j As Long
        For j = 1 To cells.Count
            Dim cell As Variant
            cell = cells(j)

            Dim cellText As String
            Dim classText As String
            cellText = CStr(cell(0))
            classText = CStr(cell(1))

            If Len(dateRaw) = 0 Then
                If DxaClassNameContains(classText, "dispdate") Or DxaClassNameContains(classText, "date") Then dateRaw = cellText
            End If
            If Len(startTime) = 0 Then
                If DxaClassNameContains(classText, "attendanceTime") Then startTime = cellText
            End If
            If Len(endTime) = 0 Then
                If DxaClassNameContains(classText, "retiredTime") Then endTime = cellText
            End If
        Next

        ' v152:
        ' ���ۂ�DisplayList��ʂ�HTML��� </tr> ���ȗ������ꍇ������܂��B
        ' �܂��Aclass�������Ɉˑ�����ƒ��o�ł��Ȃ����߁A�Αӕ\�̗�
        ' �u���t / �o�Ύ��� / �ދΎ��ԁv���t�H�[���o�b�N�Ƃ��Ďg�p���܂��B
        If Len(dateRaw) = 0 Then dateRaw = DxaTimecardCellTextAt(cells, 1)
        If Len(startTime) = 0 Then startTime = DxaTimecardCellTextAt(cells, 2)
        If Len(endTime) = 0 Then endTime = DxaTimecardCellTextAt(cells, 3)

        dateRaw = DxaNormalizeSpaces(dateRaw)
        startTime = DxaNormalizeTimeText(startTime)
        endTime = DxaNormalizeTimeText(endTime)

        Dim dayNum As Long
        dayNum = DxaExtractDayNumber(dateRaw)
        If dayNum < 1 Or dayNum > 31 Then GoTo ContinueRow

        Dim dayKey As String
        dayKey = CStr(dayNum)
        If seenDays.Exists(dayKey) Then GoTo ContinueRow

        Dim dateText As String
        If hasYm Then
            On Error Resume Next
            Dim d As Date
            d = DateSerial(y, m, dayNum)
            If Err.Number <> 0 Then
                Err.Clear
                On Error GoTo EH
                GoTo ContinueRow
            End If
            On Error GoTo EH
            dateText = Format$(d, "yyyy/mm/dd") & "�i" & DxaWeekdayJa(d) & "�j"
        Else
            dateText = DxaNormalizeDateText(dateRaw)
        End If

        result.Add Array(dateText, startTime, endTime)
        seenDays(dayKey) = True

ContinueRow:
    Next

    Set DxaParseTimecardRecordsFromHtml = result
    Exit Function
EH:
    Set DxaParseTimecardRecordsFromHtml = result
End Function

Private Function DxaExtractHtmlRowFragments(ByVal html As String) As Collection
    Dim result As New Collection
    On Error GoTo EH

    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = True
    re.Pattern = "<tr\b[^>]*>"

    Dim starts As Object
    Set starts = re.Execute(html)

    Dim i As Long
    For i = 0 To starts.Count - 1
        Dim startPos As Long
        Dim endPos As Long
        startPos = CLng(starts(i).FirstIndex) + 1

        If i < starts.Count - 1 Then
            endPos = CLng(starts(i + 1).FirstIndex) + 1
        Else
            endPos = Len(html) + 1
        End If

        If endPos > startPos Then
            Dim rowHtml As String
            rowHtml = Mid$(html, startPos, endPos - startPos)
            If InStr(1, rowHtml, "<td", vbTextCompare) > 0 Then result.Add rowHtml
        End If
    Next

    Set DxaExtractHtmlRowFragments = result
    Exit Function
EH:
    Set DxaExtractHtmlRowFragments = result
End Function

Private Function DxaExtractTdCellInfos(ByVal rowHtml As String) As Collection
    Dim result As New Collection
    On Error GoTo EH

    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = True
    re.Pattern = "<td\b([^>]*)>([\s\S]*?)</td>"

    Dim ms As Object
    Set ms = re.Execute(rowHtml)

    Dim m As Object
    For Each m In ms
        Dim attrText As String
        Dim innerHtml As String
        Dim cellText As String
        Dim classText As String

        attrText = CStr(m.SubMatches(0))
        innerHtml = CStr(m.SubMatches(1))
        classText = DxaExtractAttributeValue("<td " & attrText & ">", "class")
        cellText = DxaNormalizeSpaces(DxaHtmlDecodeBasic(DxaStripHtmlTags(innerHtml)))

        result.Add Array(cellText, classText)
    Next

    Set DxaExtractTdCellInfos = result
    Exit Function
EH:
    Set DxaExtractTdCellInfos = result
End Function

Private Function DxaTimecardCellTextAt(ByVal cells As Collection, ByVal oneBasedIndex As Long) As String
    On Error GoTo EH
    If cells Is Nothing Then Exit Function
    If oneBasedIndex < 1 Or oneBasedIndex > cells.Count Then Exit Function

    Dim cell As Variant
    cell = cells(oneBasedIndex)
    DxaTimecardCellTextAt = CStr(cell(0))
    Exit Function
EH:
    DxaTimecardCellTextAt = ""
End Function

Private Function DxaClassNameContains(ByVal classText As String, ByVal keyword As String) As Boolean
    DxaClassNameContains = (InStr(1, LCase$(CStr(classText)), LCase$(CStr(keyword)), vbTextCompare) > 0)
End Function

Private Function DxaNormalizeTimeText(ByVal text As String) As String
    On Error GoTo EH

    Dim s As String
    s = DxaNormalizeSpaces(text)
    If Len(s) = 0 Then Exit Function

    Dim re As Object
    Dim ms As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = False
    re.IgnoreCase = True

    re.Pattern = "([0-2]?\d)\s*[:�F]\s*([0-5]\d)"
    If re.Test(s) Then
        Set ms = re.Execute(s)
        DxaNormalizeTimeText = Format$(CLng(ms(0).SubMatches(0)), "00") & ":" & Format$(CLng(ms(0).SubMatches(1)), "00")
        Exit Function
    End If

    re.Pattern = "^\s*([0-2]\d)([0-5]\d)\s*$"
    If re.Test(s) Then
        Set ms = re.Execute(s)
        DxaNormalizeTimeText = Format$(CLng(ms(0).SubMatches(0)), "00") & ":" & Format$(CLng(ms(0).SubMatches(1)), "00")
        Exit Function
    End If

    DxaNormalizeTimeText = ""
    Exit Function
EH:
    DxaNormalizeTimeText = ""
End Function

Private Function DxaExtractTdTextByClass(ByVal rowHtml As String, ByVal className As String) As String
    On Error Resume Next
    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = False
    re.IgnoreCase = True
    re.Pattern = "<td[^>]*class=[""'][^""']*" & DxaRegexEscape(className) & "[^""']*[""'][^>]*>([\s\S]*?)</td>"
    Dim ms As Object
    Set ms = re.Execute(rowHtml)
    If ms.Count > 0 Then DxaExtractTdTextByClass = Trim$(DxaHtmlDecodeBasic(DxaStripHtmlTags(CStr(ms(0).SubMatches(0)))))
End Function

Private Function DxaExtractDayNumber(ByVal text As String) As Long
    On Error Resume Next
    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = False
    re.IgnoreCase = True
    re.Pattern = "(\d{1,2})"
    Dim ms As Object
    Set ms = re.Execute(text)
    If ms.Count > 0 Then DxaExtractDayNumber = CLng(ms(0).SubMatches(0))
End Function

Private Function DxaStripHtmlTags(ByVal html As String) As String
    On Error Resume Next
    Dim s As String
    s = Replace(html, "</td>", vbTab, , , vbTextCompare)
    s = Replace(s, "</tr>", vbLf, , , vbTextCompare)
    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = True
    re.IgnoreCase = True
    re.Pattern = "<[^>]+>"
    s = re.Replace(s, " ")
    DxaStripHtmlTags = DxaHtmlDecodeBasic(s)
End Function

Private Function DxaHtmlDecodeBasic(ByVal text As String) As String
    Dim s As String
    s = CStr(text)
    s = Replace(s, "&nbsp;", " ")
    s = Replace(s, "&amp;", "&")
    s = Replace(s, "&lt;", "<")
    s = Replace(s, "&gt;", ">")
    s = Replace(s, "&quot;", Chr$(34))
    s = Replace(s, "&#39;", "'")
    DxaHtmlDecodeBasic = s
End Function

Private Function DxaNormalizeSpaces(ByVal text As String) As String
    Dim s As String
    s = Replace(CStr(text), ChrW(&H3000), " ")
    s = Trim$(s)
    Do While InStr(s, "  ") > 0
        s = Replace(s, "  ", " ")
    Loop
    DxaNormalizeSpaces = s
End Function

Private Function DxaRegexEscape(ByVal text As String) As String
    Dim s As String
    s = CStr(text)
    s = Replace(s, "\", "\\")
    s = Replace(s, ".", "\.")
    s = Replace(s, "*", "\*")
    s = Replace(s, "+", "\+")
    s = Replace(s, "?", "\?")
    s = Replace(s, "^", "\^")
    s = Replace(s, "$", "\$")
    s = Replace(s, "(", "\(")
    s = Replace(s, ")", "\)")
    s = Replace(s, "[", "\[")
    s = Replace(s, "]", "\]")
    s = Replace(s, "{", "\{")
    s = Replace(s, "}", "\}")
    s = Replace(s, "|", "\|")
    DxaRegexEscape = s
End Function

Private Function DxaExtractYearMonth(ByVal text As String, ByRef y As Long, ByRef m As Long) As Boolean
    On Error GoTo EH
    Dim re As Object
    Set re = CreateObject("VBScript.RegExp")
    re.Global = False
    re.IgnoreCase = True
    re.Pattern = "(20\d{2}|19\d{2})\s*�N\s*(\d{1,2})\s*��"

    Dim ms As Object
    Set ms = re.Execute(text)
    If ms.Count = 0 Then Exit Function

    y = CLng(ms(0).SubMatches(0))
    m = CLng(ms(0).SubMatches(1))
    If m < 1 Or m > 12 Then Exit Function

    DxaExtractYearMonth = True
    Exit Function
EH:
    DxaExtractYearMonth = False
End Function

Private Function DxaNormalizeDateText(ByVal text As String) As String
    Dim s As String
    s = Trim$(text)
    s = Replace(s, " ", "")
    s = Replace(s, "(", "�i")
    s = Replace(s, ")", "�j")
    DxaNormalizeDateText = s
End Function

Private Function DxaWeekdayJa(ByVal d As Date) As String
    DxaWeekdayJa = Mid$("�����ΐ��؋��y", Weekday(d, vbSunday), 1)
End Function



' DelaxTools v114
' �A�N�e�B�u�u�b�N�̊O���f�[�^�A�N�G���A�s�{�b�g�e�[�u���A�������X�V���܂��B
Public Sub DxaRefreshWorkbook(ByVal control As Object)
    On Error GoTo EH

    Dim wb As Workbook
    Dim ws As Worksheet
    Dim pt As PivotTable
    Dim qt As QueryTable
    Dim lo As ListObject
    Dim refreshedPivotCount As Long
    Dim refreshedQueryCount As Long

    If Application.Workbooks.Count = 0 Then
        MsgBox "�X�V�Ώۂ̃u�b�N���J����Ă��܂���B", vbExclamation, "DelaxTools �X�V"
        Exit Sub
    End If

    Set wb = ActiveWorkbook
    If wb Is Nothing Then
        MsgBox "�X�V�Ώۂ̃u�b�N���擾�ł��܂���ł����B", vbExclamation, "DelaxTools �X�V"
        Exit Sub
    End If

    If StrComp(wb.Name, ThisWorkbook.Name, vbTextCompare) = 0 Then
        MsgBox "DelaxTools.xlam�ł͂Ȃ��A�X�V�������u�b�N���A�N�e�B�u�ɂ��Ă�����s���Ă��������B", vbExclamation, "DelaxTools �X�V"
        Exit Sub
    End If

    Application.ScreenUpdating = False
    Application.StatusBar = "DelaxTools: �u�b�N���X�V���Ă��܂�..."

    On Error Resume Next
    wb.RefreshAll
    Application.CalculateUntilAsyncQueriesDone
    On Error GoTo EH

    For Each ws In wb.Worksheets
        For Each qt In ws.QueryTables
            On Error Resume Next
            qt.Refresh BackgroundQuery:=False
            If Err.Number = 0 Then refreshedQueryCount = refreshedQueryCount + 1
            Err.Clear
            On Error GoTo EH
        Next qt

        For Each lo In ws.ListObjects
            If Not lo.QueryTable Is Nothing Then
                On Error Resume Next
                lo.QueryTable.Refresh BackgroundQuery:=False
                If Err.Number = 0 Then refreshedQueryCount = refreshedQueryCount + 1
                Err.Clear
                On Error GoTo EH
            End If
        Next lo

        For Each pt In ws.PivotTables
            On Error Resume Next
            pt.RefreshTable
            If Err.Number = 0 Then refreshedPivotCount = refreshedPivotCount + 1
            Err.Clear
            On Error GoTo EH
        Next pt
    Next ws

    Application.CalculateFull

    Application.StatusBar = False
    Application.ScreenUpdating = True

    MsgBox "�X�V���������܂����B" & vbCrLf & _
           "�Ώۃu�b�N: " & wb.Name & vbCrLf & _
           "�X�V�����N�G��/�e�[�u��: " & refreshedQueryCount & vbCrLf & _
           "�X�V�����s�{�b�g�e�[�u��: " & refreshedPivotCount, _
           vbInformation, "DelaxTools �X�V"
    Exit Sub

EH:
    Application.StatusBar = False
    Application.ScreenUpdating = True
    MsgBox "�X�V���ɃG���[���������܂����B" & vbCrLf & _
           "Err " & Err.Number & ": " & Err.Description, vbExclamation, "DelaxTools �X�V"
End Sub



' DelaxTools v115
' GitHub main�u�����`��VERSION.txt���m�F���A���݂��V�����ꍇ�����m�F�_�C�A���O��\�����ăA�b�v�f�[�g���܂��B
Public Sub DxaCheckDelaxToolsUpdate(ByVal control As Object)
    On Error GoTo EH

    Dim currentVersion As String
    Dim latestVersionRaw As String
    Dim latestVersion As String

    currentVersion = DxaNormalizeVersionText(DxaGetCurrentVersionText())
    latestVersionRaw = DxaGetLatestVersionTextFromGitHub()

    If Len(Trim$(latestVersionRaw)) = 0 Then
        MsgBox "�ŐV�o�[�W�������擾�ł��܂���ł����B" & vbCrLf & _
               "GitHub��VERSION.txt�A�l�b�g���[�N�ڑ��A���|�W�g���z�u���m�F���Ă��������B" & vbCrLf & vbCrLf & _
               "���݂̃o�[�W����: " & currentVersion, _
               vbExclamation, "DelaxTools �A�b�v�f�[�g�m�F"
        Exit Sub
    End If

    latestVersion = DxaNormalizeVersionText(latestVersionRaw)

    If DxaCompareVersionText(currentVersion, latestVersion) >= 0 Then
        MsgBox "DelaxTools�͍ŐV�ł��B" & vbCrLf & vbCrLf & _
               "���݂̃o�[�W����: " & currentVersion & vbCrLf & _
               "�ŐV�̃o�[�W����: " & latestVersion, _
               vbInformation, "DelaxTools �A�b�v�f�[�g�m�F"
        Exit Sub
    End If

    Dim answer As VbMsgBoxResult
    answer = MsgBox("�V����DelaxTools��������܂����B" & vbCrLf & vbCrLf & _
                    "���݂̃o�[�W����: " & currentVersion & vbCrLf & _
                    "�ŐV�̃o�[�W����: " & latestVersion & vbCrLf & vbCrLf & _
                    "�C���X�g�[���[���_�E�����[�h���ăA�b�v�f�[�g���܂����H" & vbCrLf & _
                    "�A�b�v�f�[�g����Excel���I�����܂��B", _
                    vbYesNo + vbQuestion, "DelaxTools �A�b�v�f�[�g�m�F")
    If answer <> vbYes Then Exit Sub

    Dim wb As Workbook
    For Each wb In Application.Workbooks
        If StrComp(wb.Name, ThisWorkbook.Name, vbTextCompare) <> 0 Then
            If wb.Saved = False Then
                MsgBox "�ۑ�����Ă��Ȃ��u�b�N������܂��B" & vbCrLf & _
                       "�A�b�v�f�[�g�ł�Excel���I�����邽�߁A��ɂ��ׂĕۑ����Ă���Ď��s���Ă��������B" & vbCrLf & _
                       "�Ώ�: " & wb.Name, vbExclamation, "DelaxTools �A�b�v�f�[�g�m�F"
                Exit Sub
            End If
        End If
    Next wb

    Dim tempDir As String
    Dim zipPath As String
    Dim psCmd As String
    Dim sh As Object

    tempDir = Environ$("TEMP") & "\DelaxToolsInstaller_" & Format$(Now, "yyyymmdd_hhnnss")
    zipPath = tempDir & "\DelaxToolsInstaller.zip"

    psCmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -Command " & _
            DxaQuoteForCommand("$ErrorActionPreference='Stop'; " & _
            "New-Item -ItemType Directory -Force -Path " & DxaPsQuote(tempDir) & " | Out-Null; " & _
            "$urls=@('https://raw.githubusercontent.com/Chairman-bits/DelaxTools/main/DelaxToolsInstaller.zip','https://github.com/Chairman-bits/DelaxTools/raw/main/DelaxToolsInstaller.zip','https://raw.githubusercontent.com/Chairman-bits/DExcelAssist/main/DelaxToolsInstaller.zip','https://raw.githubusercontent.com/Chairman-bits/DExcelAssist/main/DExcelAssistInstaller.zip'); " & _
            "$ok=$false; $last=''; foreach($u in $urls){ try{ Invoke-WebRequest -Uri $u -OutFile " & DxaPsQuote(zipPath) & " -UseBasicParsing; if(Test-Path " & DxaPsQuote(zipPath) & "){ $ok=$true; break } } catch { $last=$_.Exception.Message } }; if(-not $ok){ throw ('Installer download failed. ' + $last) }; " & _
            "Expand-Archive -Path " & DxaPsQuote(zipPath) & " -DestinationPath " & DxaPsQuote(tempDir) & " -Force; " & _
            "$bat = Get-ChildItem -Path " & DxaPsQuote(tempDir) & " -Recurse -Filter 'DelaxTools.bat' | Select-Object -First 1; " & _
            "if($null -eq $bat){ throw 'DelaxTools.bat was not found.' }; " & _
            "Start-Process -FilePath $bat.FullName -ArgumentList '/install' -WorkingDirectory $bat.DirectoryName")

    Set sh = CreateObject("WScript.Shell")
    sh.Run psCmd, 0, False

    MsgBox "DelaxTools�̃C���X�g�[���[���N�����܂����B" & vbCrLf & _
           "���̂���Excel���I�����܂��B�C���X�g�[���������Excel���ċN�����Ă��������B", _
           vbInformation, "DelaxTools �A�b�v�f�[�g�m�F"

    Application.DisplayAlerts = False
    Application.Quit
    Exit Sub

EH:
    MsgBox "DelaxTools�̃A�b�v�f�[�g�m�F���ɃG���[���������܂����B" & vbCrLf & _
           "Err " & Err.Number & ": " & Err.Description, vbExclamation, "DelaxTools �A�b�v�f�[�g�m�F"
End Sub

' �����{��ID�Ƃ̌݊��p�B���݂̃��{������͌Ăяo���܂���B
Public Sub DxaUpdateDelaxTools(ByVal control As Object)
    DxaCheckDelaxToolsUpdate control
End Sub

Private Function DxaTryHandleSecretInstallerDownloadCommand() As Boolean
    ' v186: KO�Z���ɂ��C���X�g�[���[�擾�����͍폜���܂����B
    DxaTryHandleSecretInstallerDownloadCommand = False
End Function

Private Sub DxaDownloadLatestInstallerZip()
    On Error GoTo EH

    Dim downloadDir As String
    downloadDir = Environ$("USERPROFILE") & "\Downloads"
    If Len(Dir(downloadDir, vbDirectory)) = 0 Then downloadDir = Environ$("TEMP")

    Dim zipPath As String
    zipPath = DxaReleaseCombinePath(downloadDir, "DelaxToolsInstaller_" & Format$(Now, "yyyymmdd_hhnnss") & ".zip")

    Dim cachePath As String
    cachePath = DxaGetInstallerCachePath()
    If Len(cachePath) > 0 Then
        If Dir(cachePath) <> "" Then
            FileCopy cachePath, zipPath
            MsgBox "�C���X�g�[���[���擾���܂����B" & vbCrLf & vbCrLf & _
                   zipPath & vbCrLf & vbCrLf & _
                   "�擾��: ���[�J���L���b�V��", vbInformation, "DelaxTools"
            On Error Resume Next
            CreateObject("WScript.Shell").Run "explorer.exe /select," & DxaQuoteForCommand(zipPath), 1, False
            On Error GoTo 0
            Exit Sub
        End If
    End If

    Dim urls As Variant
    urls = DxaGetInstallerDownloadUrls()

    Dim i As Long
    Dim lastStatus As String
    For i = LBound(urls) To UBound(urls)
        If DxaTryDownloadInstallerFromUrl(CStr(urls(i)), zipPath, lastStatus) Then
            MsgBox "�C���X�g�[���[���_�E�����[�h���܂����B" & vbCrLf & vbCrLf & zipPath, vbInformation, "DelaxTools"
            On Error Resume Next
            CreateObject("WScript.Shell").Run "explorer.exe /select," & DxaQuoteForCommand(zipPath), 1, False
            On Error GoTo 0
            Exit Sub
        End If
    Next i

    MsgBox "�C���X�g�[���[���擾�ł��܂���ł����B" & vbCrLf & _
           "���[�J���L���b�V���������A�܂���GitHub main�u�����`��̔z�u�ɃA�N�Z�X�ł��܂���B" & vbCrLf & vbCrLf & _
           lastStatus, vbExclamation, "DelaxTools"
    Exit Sub

EH:
    MsgBox "�C���X�g�[���[�̎擾�ŃG���[���������܂����B" & vbCrLf & _
           "Err " & Err.Number & ": " & Err.Description, vbExclamation, "DelaxTools"
End Sub

Private Function DxaTryDownloadInstallerFromUrl(ByVal url As String, ByVal zipPath As String, ByRef lastStatus As String) As Boolean
    On Error GoTo EH

    Dim http As Object
    Set http = CreateObject("WinHttp.WinHttpRequest.5.1")
    http.Open "GET", url, False
    http.SetTimeouts 5000, 5000, 30000, 30000
    http.Send

    lastStatus = "HTTP Status: " & CStr(http.Status) & vbCrLf & url

    If CLng(http.Status) <> 200 Then Exit Function

    Dim stream As Object
    Set stream = CreateObject("ADODB.Stream")
    stream.Type = 1
    stream.Open
    stream.Write http.ResponseBody
    stream.SaveToFile zipPath, 2
    stream.Close

    DxaTryDownloadInstallerFromUrl = (Dir(zipPath) <> "")
    Exit Function
EH:
    lastStatus = "Err " & Err.Number & ": " & Err.Description & vbCrLf & url
    DxaTryDownloadInstallerFromUrl = False
End Function

Private Function DxaGetInstallerCachePath() As String
    On Error GoTo Fallback
    Dim sh As Object
    Set sh = CreateObject("WScript.Shell")
    DxaGetInstallerCachePath = CStr(sh.RegRead("HKCU\Software\DelaxTools\InstallerCachePath"))
    If Len(Trim$(DxaGetInstallerCachePath)) > 0 Then Exit Function

Fallback:
    On Error Resume Next
    DxaGetInstallerCachePath = Environ$("APPDATA") & "\DelaxTools\installer_cache\DelaxToolsInstaller.zip"
End Function

Private Function DxaGetInstallerDownloadUrls() As Variant
    DxaGetInstallerDownloadUrls = Array( _
        "https://raw.githubusercontent.com/Chairman-bits/DelaxTools/main/DelaxToolsInstaller.zip", _
        "https://github.com/Chairman-bits/DelaxTools/raw/main/DelaxToolsInstaller.zip")
End Function

Private Function DxaGetInstallerDownloadUrl() As String
    DxaGetInstallerDownloadUrl = "https://raw.githubusercontent.com/Chairman-bits/DelaxTools/main/DelaxToolsInstaller.zip"
End Function

Private Function DxaGetCurrentVersionText() As String
    On Error GoTo Fallback

    Dim sh As Object
    Set sh = CreateObject("WScript.Shell")
    DxaGetCurrentVersionText = Trim$(CStr(sh.RegRead("HKCU\Software\DelaxTools\LocalVersion")))
    If Len(DxaGetCurrentVersionText) > 0 Then Exit Function

Fallback:
    On Error Resume Next
    Dim installRoot As String
    Dim fso As Object
    Dim ts As Object

    installRoot = DxaReadInstallRoot()
    If Len(installRoot) > 0 Then
        Set fso = CreateObject("Scripting.FileSystemObject")
        If fso.FileExists(installRoot & "\VERSION.txt") Then
            Set ts = fso.OpenTextFile(installRoot & "\VERSION.txt", 1, False)
            DxaGetCurrentVersionText = Trim$(CStr(ts.ReadAll))
            ts.Close
        End If
    End If

    If Len(DxaGetCurrentVersionText) = 0 Then DxaGetCurrentVersionText = "v0.0.0"
End Function

Private Function DxaGetLatestVersionTextFromGitHub() As String
    On Error GoTo EH

    Dim urls As Variant
    Dim i As Long
    Dim versionText As String
    Dim lastStatus As String

    urls = DxaGetLatestVersionDownloadUrls()

    For i = LBound(urls) To UBound(urls)
        versionText = vbNullString
        If DxaTryGetLatestVersionFromUrl(CStr(urls(i)), versionText, lastStatus) Then
            DxaGetLatestVersionTextFromGitHub = Trim$(versionText)
            Exit Function
        End If
    Next i

    DxaGetLatestVersionTextFromGitHub = vbNullString
    Exit Function

EH:
    DxaGetLatestVersionTextFromGitHub = vbNullString
End Function

Private Function DxaGetLatestVersionDownloadUrls() As Variant
    DxaGetLatestVersionDownloadUrls = Array( _
        "https://raw.githubusercontent.com/Chairman-bits/DelaxTools/main/VERSION.txt", _
        "https://github.com/Chairman-bits/DelaxTools/raw/main/VERSION.txt", _
        "https://raw.githubusercontent.com/Chairman-bits/DExcelAssist/main/VERSION.txt", _
        "https://github.com/Chairman-bits/DExcelAssist/raw/main/VERSION.txt")
End Function

Private Function DxaTryGetLatestVersionFromUrl(ByVal url As String, ByRef versionText As String, ByRef lastStatus As String) As Boolean
    On Error GoTo EH

    Dim http As Object
    Set http = CreateObject("WinHttp.WinHttpRequest.5.1")
    http.Open "GET", url & "?t=" & Format$(Now, "yyyymmddhhnnss"), False
    http.SetTimeouts 5000, 5000, 10000, 10000
    http.SetRequestHeader "Cache-Control", "no-cache"
    http.SetRequestHeader "Pragma", "no-cache"
    http.SetRequestHeader "User-Agent", "Mozilla/5.0 DelaxToolsUpdateCheck"
    http.Send

    lastStatus = "HTTP Status: " & CStr(http.Status) & vbCrLf & url

    If CLng(http.Status) <> 200 Then Exit Function

    versionText = Trim$(CStr(http.ResponseText))
    versionText = Replace(versionText, ChrW$(&HFEFF), vbNullString)
    versionText = Replace(versionText, vbCr, vbNullString)
    versionText = Split(versionText, vbLf)(0)
    versionText = Trim$(versionText)

    If Not DxaLooksLikeVersionText(versionText) Then Exit Function

    DxaTryGetLatestVersionFromUrl = True
    Exit Function
EH:
    lastStatus = "Err " & Err.Number & ": " & Err.Description & vbCrLf & url
    DxaTryGetLatestVersionFromUrl = False
End Function

Private Function DxaLooksLikeVersionText(ByVal versionText As String) As Boolean
    Dim s As String
    Dim i As Long
    Dim ch As String

    s = Trim$(CStr(versionText))
    If Len(s) = 0 Then Exit Function
    If Len(s) > 30 Then Exit Function

    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        If Not ((ch >= "0" And ch <= "9") Or ch = "." Or ch = "v" Or ch = "V" Or ch = "_" Or ch = "-" Or ch = " ") Then
            Exit Function
        End If
    Next i

    DxaLooksLikeVersionText = True
End Function

Private Function DxaNormalizeVersionText(ByVal versionText As String) As String
    Dim s As String
    Dim i As Long
    Dim ch As String
    Dim result As String
    Dim started As Boolean

    s = Trim$(CStr(versionText))
    s = Replace(s, ChrW$(&HFEFF), vbNullString)
    s = Replace(s, ChrW$(&HFFFD), vbNullString)
    s = Replace(s, "?", vbNullString)

    For i = 1 To Len(s)
        ch = Mid$(s, i, 1)
        If Not started Then
            If ch = "v" Or ch = "V" Or (ch >= "0" And ch <= "9") Then
                started = True
            End If
        End If

        If started Then
            If ch = "v" Or ch = "V" Or ch = "." Or ch = "-" Or ch = "_" Or (ch >= "0" And ch <= "9") Then
                result = result & ch
            ElseIf Len(result) > 0 Then
                Exit For
            End If
        End If
    Next i

    result = Trim$(result)
    If Len(result) = 0 Then result = "v0.0.0"
    DxaNormalizeVersionText = result
End Function

Private Function DxaCompareVersionText(ByVal currentVersion As String, ByVal latestVersion As String) As Long
    Dim i As Long
    Dim a As Long
    Dim b As Long

    For i = 0 To 3
        a = DxaGetVersionPart(currentVersion, i)
        b = DxaGetVersionPart(latestVersion, i)
        If a < b Then
            DxaCompareVersionText = -1
            Exit Function
        ElseIf a > b Then
            DxaCompareVersionText = 1
            Exit Function
        End If
    Next i

    DxaCompareVersionText = 0
End Function

Private Function DxaGetVersionPart(ByVal versionText As String, ByVal index As Long) As Long
    Dim s As String
    Dim parts As Variant

    s = LCase$(DxaNormalizeVersionText(versionText))
    If Left$(s, 1) = "v" Then s = Mid$(s, 2)
    s = Replace(s, "_", "-")
    If InStr(1, s, "-", vbTextCompare) > 0 Then s = Left$(s, InStr(1, s, "-", vbTextCompare) - 1)

    parts = Split(s, ".")
    If index <= UBound(parts) Then
        DxaGetVersionPart = CLng(Val(CStr(parts(index))))
    Else
        DxaGetVersionPart = 0
    End If
End Function

Private Function DxaReadInstallRoot() As String
    On Error GoTo EH
    Dim sh As Object
    Set sh = CreateObject("WScript.Shell")
    DxaReadInstallRoot = CStr(sh.RegRead("HKCU\Software\DelaxTools\InstallRoot"))
    Exit Function
EH:
    DxaReadInstallRoot = vbNullString
End Function

Private Function DxaPsQuote(ByVal value As String) As String
    DxaPsQuote = "'" & Replace(value, "'", "''") & "'"
End Function

Private Function DxaQuoteForCommand(ByVal value As String) As String
    DxaQuoteForCommand = Chr$(34) & Replace(value, Chr$(34), Chr$(34) & Chr$(34)) & Chr$(34)
End Function


' v161: ���݂̃C���X�g�[���ꎮ��z�z�pZIP�Ƃ��ďo�͂��܂��B
' �B���{�^������̂݌Ăяo���z��ł��B�Αӎ擾�����ɂ͉e�����܂���B
Public Sub DxaCreateCurrentInstallerZip(ByVal control As Object)
    On Error GoTo EH

    Dim root As String
    root = DxaGetDelaxToolsInstallRootForRelease()

    If Len(Trim$(root)) = 0 Or Dir(root, vbDirectory) = "" Then
        DxaDownloadLatestInstallerZip
        Exit Sub
    End If

    Dim batPath As String
    batPath = DxaReleaseCombinePath(root, "DelaxTools.bat")
    If Dir(batPath) = "" Then
        DxaDownloadLatestInstallerZip
        Exit Sub
    End If

    Dim tempDir As String
    tempDir = Environ$("TEMP")
    If Len(tempDir) = 0 Then tempDir = root

    Dim stamp As String
    stamp = Format$(Now, "yyyymmdd_hhnnss")

    Dim scriptPath As String
    Dim resultPath As String
    Dim errorPath As String
    scriptPath = DxaReleaseCombinePath(tempDir, "DelaxTools_create_release_" & stamp & ".ps1")
    resultPath = DxaReleaseCombinePath(tempDir, "DelaxTools_create_release_result_" & stamp & ".txt")
    errorPath = DxaReleaseCombinePath(tempDir, "DelaxTools_create_release_error_" & stamp & ".txt")

    DxaReleaseWriteTextFileUtf16 scriptPath, DxaBuildCreateReleasePowerShell(root, resultPath, errorPath)

    Dim command As String
    command = "powershell.exe -NoProfile -ExecutionPolicy Bypass -File " & DxaQuoteForCommand(scriptPath)

    Dim exitCode As Long
    exitCode = CreateObject("WScript.Shell").Run(command, 0, True)

    If exitCode <> 0 Then
        Dim errText As String
        errText = DxaReleaseReadTextFile(errorPath)
        If Len(Trim$(errText)) = 0 Then errText = "PowerShell �̏I���R�[�h: " & CStr(exitCode)
        MsgBox "�z�z�pZIP�̍쐬�Ɏ��s���܂����B" & vbCrLf & vbCrLf & errText, vbExclamation, "DelaxTools"
        Exit Sub
    End If

    Dim outPath As String
    outPath = Trim$(DxaReleaseReadTextFile(resultPath))
    If Len(outPath) = 0 Then
        MsgBox "�z�z�pZIP�͍쐬����܂������A�o�͐���擾�ł��܂���ł����B" & vbCrLf & _
               DxaReleaseCombinePath(root, "_release\main_branch_upload"), vbInformation, "DelaxTools"
        Exit Sub
    End If

    MsgBox "�z�z�pZIP���쐬���܂����B" & vbCrLf & vbCrLf & outPath, vbInformation, "DelaxTools"

    On Error Resume Next
    CreateObject("WScript.Shell").Run "explorer.exe /select," & DxaQuoteForCommand(outPath), 1, False
    On Error GoTo 0
    Exit Sub

EH:
    MsgBox "�z�z�pZIP�̍쐬�ŃG���[���������܂����B" & vbCrLf & Err.Description, vbExclamation, "DelaxTools"
End Sub

Private Function DxaGetDelaxToolsInstallRootForRelease() As String
    On Error Resume Next
    DxaGetDelaxToolsInstallRootForRelease = CStr(CreateObject("WScript.Shell").RegRead("HKCU\Software\DelaxTools\InstallRoot"))
    On Error GoTo 0
End Function

Private Function DxaBuildCreateReleasePowerShell(ByVal root As String, ByVal resultPath As String, ByVal errorPath As String) As String
    Dim ps As String
    ps = "try {" & vbCrLf
    ps = ps & "  $ErrorActionPreference = 'Stop'" & vbCrLf
    ps = ps & "  $root = " & DxaPsQuote(root) & vbCrLf
    ps = ps & "  $resultPath = " & DxaPsQuote(resultPath) & vbCrLf
    ps = ps & "  $errorPath = " & DxaPsQuote(errorPath) & vbCrLf
    ps = ps & "  $versionFile = Join-Path $root 'VERSION.txt'" & vbCrLf
    ps = ps & "  if(Test-Path $versionFile){ $version = (Get-Content -Path $versionFile -Raw).Trim() } else { $version = 'v0.0.0' }" & vbCrLf
    ps = ps & "  if([string]::IsNullOrWhiteSpace($version)){ $version = 'v0.0.0' }" & vbCrLf
    ps = ps & "  if($version -notmatch '^v'){ $version = 'v' + $version }" & vbCrLf
    ps = ps & "  $safeVersion = $version -replace '[^0-9A-Za-z._-]','_'" & vbCrLf
    ps = ps & "  $releaseDir = Join-Path $root '_release'" & vbCrLf
    ps = ps & "  $uploadDir = Join-Path $releaseDir 'main_branch_upload'" & vbCrLf
    ps = ps & "  $stageParent = Join-Path $releaseDir '_stage'" & vbCrLf
    ps = ps & "  $stageRoot = Join-Path $stageParent ('DelaxToolsInstaller_' + $safeVersion)" & vbCrLf
    ps = ps & "  if(Test-Path $releaseDir){ Remove-Item -Path $releaseDir -Recurse -Force -ErrorAction SilentlyContinue }" & vbCrLf
    ps = ps & "  New-Item -ItemType Directory -Force -Path $releaseDir,$uploadDir,$stageRoot | Out-Null" & vbCrLf
    ps = ps & "  $items = @('DelaxTools.bat','README.md','VERSION.txt','payload','tools','licenses')" & vbCrLf
    ps = ps & "  foreach($item in $items){" & vbCrLf
    ps = ps & "    $src = Join-Path $root $item" & vbCrLf
    ps = ps & "    if(Test-Path $src){ Copy-Item -Path $src -Destination (Join-Path $stageRoot $item) -Recurse -Force }" & vbCrLf
    ps = ps & "  }" & vbCrLf
    ps = ps & "  Set-Content -Path (Join-Path $stageRoot 'VERSION.txt') -Value $version -Encoding UTF8" & vbCrLf
    ps = ps & "  $zip = Join-Path $uploadDir 'DelaxToolsInstaller.zip'" & vbCrLf
    ps = ps & "  if(Test-Path $zip){ Remove-Item -Path $zip -Force }" & vbCrLf
    ps = ps & "  Compress-Archive -Path $stageRoot -DestinationPath $zip -Force" & vbCrLf
    ps = ps & "  $versionedZip = Join-Path $uploadDir ('DelaxToolsInstaller_' + $safeVersion + '.zip')" & vbCrLf
    ps = ps & "  Copy-Item -Path $zip -Destination $versionedZip -Force" & vbCrLf
    ps = ps & "  Set-Content -Path $resultPath -Value $zip -Encoding Unicode" & vbCrLf
    ps = ps & "  exit 0" & vbCrLf
    ps = ps & "} catch {" & vbCrLf
    ps = ps & "  try { $_ | Out-String | Set-Content -Path $errorPath -Encoding Unicode } catch {}" & vbCrLf
    ps = ps & "  exit 1" & vbCrLf
    ps = ps & "}" & vbCrLf
    DxaBuildCreateReleasePowerShell = ps
End Function

Private Function DxaReleaseCombinePath(ByVal leftPath As String, ByVal rightPath As String) As String
    If Right$(leftPath, 1) = "\" Or Right$(leftPath, 1) = "/" Then
        DxaReleaseCombinePath = leftPath & rightPath
    Else
        DxaReleaseCombinePath = leftPath & "\" & rightPath
    End If
End Function

Private Sub DxaReleaseWriteTextFileUtf16(ByVal path As String, ByVal text As String)
    Dim fso As Object
    Set fso = CreateObject("Scripting.FileSystemObject")
    Dim ts As Object
    Set ts = fso.CreateTextFile(path, True, True)
    ts.Write text
    ts.Close
End Sub

Private Function DxaReleaseReadTextFile(ByVal path As String) As String
    On Error GoTo EH
    If Dir(path) = "" Then
        DxaReleaseReadTextFile = ""
        Exit Function
    End If
    Dim fso As Object
    Set fso = CreateObject("Scripting.FileSystemObject")
    Dim ts As Object
    Set ts = fso.OpenTextFile(path, 1, False, -1)
    DxaReleaseReadTextFile = ts.ReadAll
    ts.Close
    Exit Function
EH:
    DxaReleaseReadTextFile = ""
End Function

' DelaxTools v172
' v186: �蓮�C���X�g�[���[�擾/�쐬�}�N���͍폜���܂����B



' ============================================================
' DelaxTools v186
' ���{����\������
' Ctrl+Shift+K �� Ctrl+Shift+O �𑱂��ĉ������ꍇ�����ADelaxTools/Backlog�^�u��\��/��\���ɂ��܂��B
' �_�C�A���O�͕\�����܂���B
' ============================================================
Public Sub DxaRibbonLoaded(ByVal ribbon As Object)
    On Error Resume Next
    Set gDxaRibbon = ribbon
    Application.Run "'" & ThisWorkbook.Name & "'!ribbonLoaded", ribbon
End Sub

Public Sub DxaGetDelaxToolsTabVisible(ByVal control As Object, ByRef returnedVal)
    On Error GoTo EH
    returnedVal = DxaIsDelaxToolsRibbonVisible()
    Exit Sub
EH:
    returnedVal = False
End Sub

Public Sub DxaRegisterStealthRibbonHotKey()
    On Error Resume Next
    Application.OnKey "^+k", "DxaStealthRibbonKeyK"
    Application.OnKey "^+K", "DxaStealthRibbonKeyK"
    Application.OnKey "^+o", "DxaStealthRibbonKeyO"
    Application.OnKey "^+O", "DxaStealthRibbonKeyO"
End Sub

Public Sub DxaUnregisterStealthRibbonHotKey()
    On Error Resume Next
    Application.OnKey "^+k"
    Application.OnKey "^+K"
    Application.OnKey "^+o"
    Application.OnKey "^+O"
    gDxaStealthRibbonKeyStage = vbNullString
    gDxaStealthRibbonKeyStageAt = 0
End Sub

Public Sub DxaStealthRibbonKeyK()
    On Error Resume Next
    gDxaStealthRibbonKeyStage = "K"
    gDxaStealthRibbonKeyStageAt = Timer
End Sub

Public Sub DxaStealthRibbonKeyO()
    On Error Resume Next
    If gDxaStealthRibbonKeyStage = "K" Then
        If DxaSecondsSinceTimer(gDxaStealthRibbonKeyStageAt) <= 5 Then
            DxaToggleExcelAssistRibbonByHotKey True
        End If
    End If
    gDxaStealthRibbonKeyStage = vbNullString
    gDxaStealthRibbonKeyStageAt = 0
End Sub

Private Function DxaSecondsSinceTimer(ByVal startValue As Double) As Double
    On Error Resume Next
    If startValue <= 0 Then
        DxaSecondsSinceTimer = 9999
    ElseIf Timer >= startValue Then
        DxaSecondsSinceTimer = Timer - startValue
    Else
        DxaSecondsSinceTimer = (86400# - startValue) + Timer
    End If
End Function

Public Sub DxaToggleExcelAssistRibbonByHotKey(Optional ByVal silent As Variant)
    On Error Resume Next
    Dim nextVisible As Boolean
    nextVisible = Not DxaIsDelaxToolsRibbonVisible()
    DxaSetDelaxToolsRibbonVisible nextVisible

    If Not gDxaRibbon Is Nothing Then
        gDxaRibbon.Invalidate
    End If
End Sub

Private Function DxaIsDelaxToolsRibbonVisible() As Boolean
    On Error GoTo EH
    Dim p As String
    p = DxaDelaxToolsRibbonVisibleFlagPath()
    DxaIsDelaxToolsRibbonVisible = (Dir(p) <> "")
    Exit Function
EH:
    DxaIsDelaxToolsRibbonVisible = False
End Function

Private Sub DxaSetDelaxToolsRibbonVisible(ByVal visible As Boolean)
    On Error GoTo EH
    Dim p As String
    Dim folder As String
    Dim f As Integer

    p = DxaDelaxToolsRibbonVisibleFlagPath()
    folder = Left$(p, InStrRev(p, "\") - 1)
    If Len(Dir(folder, vbDirectory)) = 0 Then MkDir folder

    If visible Then
        f = FreeFile
        Open p For Output As #f
        Print #f, "visible"
        Close #f
    Else
        If Dir(p) <> "" Then Kill p
    End If
    Exit Sub
EH:
    On Error Resume Next
    If f <> 0 Then Close #f
End Sub

Private Function DxaDelaxToolsRibbonVisibleFlagPath() As String
    DxaDelaxToolsRibbonVisibleFlagPath = Environ$("APPDATA") & "\DelaxTools\ribbon_visible.dat"
End Function
